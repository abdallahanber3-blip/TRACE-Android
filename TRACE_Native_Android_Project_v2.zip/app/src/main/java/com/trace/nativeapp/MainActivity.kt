package com.trace.nativeapp

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import org.apache.poi.ss.usermodel.WorkbookFactory
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.*

private val Bg = Color(0xFF07110C)
private val Panel = Color(0xFF101D16)
private val Panel2 = Color(0xFF17271E)
private val Mint = Color(0xFF70F3B4)
private val TextMain = Color(0xFFE8F3EC)
private val Muted = Color(0xFF9BB0A2)
private data class Site(val name:String, val lat:Double?, val lon:Double?, val location:String="", val pci:String="", val tech:String="")

class MainActivity : ComponentActivity() {
    private lateinit var locationManager: LocationManager
    private val sites = mutableStateListOf<Site>()
    private val points = mutableStateListOf<Location>()
    private var currentLocation by mutableStateOf<Location?>(null)
    private var tracking by mutableStateOf(false)
    private var lastLocationAt by mutableLongStateOf(0L)
    private var activePage by mutableStateOf("Home")
    private var search by mutableStateOf("")
    private var statusText by mutableStateOf("Ready")
    private var trackStartedAt by mutableLongStateOf(0L)
    private var trackElapsed by mutableLongStateOf(0L)
    private var gpsListener: LocationListener? = null
    private val prefs by lazy { getSharedPreferences("trace_native", Context.MODE_PRIVATE) }

    private val askLocation = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { grants ->
        if (grants.values.any { it }) startGpsWatch() else statusText = "Location permission is required for GPS."
    }
    private val openExcel = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) importWorkbook(uri)
    }
    private val saveGeoJson = registerForActivityResult(ActivityResultContracts.CreateDocument("application/geo+json")) { uri ->
        if (uri != null) exportGeoJson(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        locationManager = getSystemService(LOCATION_SERVICE) as LocationManager
        restoreTrack()
        restoreSites()
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary=Mint, background=Bg, surface=Panel, onPrimary=Bg, onBackground=TextMain, onSurface=TextMain)) {
                TraceApp()
            }
        }
    }

    @Composable private fun TraceApp() {
        Scaffold(
            containerColor = Bg,
            topBar = { TopAppBarTrace(activePage, sites.size, tracking) },
            bottomBar = {
                NavigationBar(containerColor = Panel, contentColor = TextMain) {
                    listOf("Home","Map","Sites","Drive Test","More").forEach { page ->
                        NavigationBarItem(
                            selected = activePage == page,
                            onClick = { activePage = page },
                            icon = { Icon(when(page) {
                                "Home" -> Icons.Default.Home
                                "Map" -> Icons.Default.Map
                                "Sites" -> Icons.Default.CellTower
                                "Drive Test" -> Icons.Default.Route
                                else -> Icons.Default.MoreHoriz
                            }, null) },
                            label = { Text(page, fontSize = 10.sp) },
                            colors = NavigationBarItemDefaults.colors(selectedIconColor=Mint, selectedTextColor=Mint, indicatorColor=Panel2, unselectedIconColor=Muted, unselectedTextColor=Muted)
                        )
                    }
                }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(horizontal=16.dp)) {
                Spacer(Modifier.height(12.dp))
                when(activePage) {
                    "Home" -> HomePage()
                    "Map" -> MapPage()
                    "Sites" -> SitesPage()
                    "Drive Test" -> DrivePage()
                    else -> MorePage()
                }
            }
        }
    }

    @Composable private fun TopAppBarTrace(page:String, siteCount:Int, isTracking:Boolean) {
        Row(Modifier.fillMaxWidth().background(Bg).padding(horizontal=18.dp, vertical=12.dp), verticalAlignment=Alignment.CenterVertically) {
            Box(Modifier.size(42.dp).clip(RoundedCornerShape(14.dp)).background(Panel2).border(1.dp, Mint.copy(.45f), RoundedCornerShape(14.dp)), contentAlignment=Alignment.Center) {
                Icon(Icons.Default.CellTower, null, tint=Mint, modifier=Modifier.size(25.dp))
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("TRACE", fontSize=22.sp, fontWeight=FontWeight.Black, color=TextMain, letterSpacing=2.sp)
                Text("DRIVE TEST INTELLIGENCE", fontSize=9.sp, color=Muted, letterSpacing=1.4.sp)
            }
            Column(horizontalAlignment=Alignment.End) {
                Row(verticalAlignment=Alignment.CenterVertically) {
                    Box(Modifier.size(7.dp).clip(CircleShape).background(if(isTracking) Mint else Muted))
                    Spacer(Modifier.width(5.dp))
                    Text(if(isTracking) "TRACKING" else "STANDBY", color=if(isTracking) Mint else Muted, fontSize=10.sp, fontWeight=FontWeight.Bold)
                }
                Text("$siteCount sites", color=Muted, fontSize=10.sp)
            }
        }
        HorizontalDivider(color=Mint.copy(.16f))
    }

    @Composable private fun HomePage() {
        Text("CONTROL CENTER", color=Muted, fontSize=11.sp, letterSpacing=2.sp)
        Spacer(Modifier.height(10.dp))
        CardBox {
            Row(verticalAlignment=Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Drive session", fontSize=20.sp, fontWeight=FontWeight.Bold)
                    Text(if(tracking) "Recording GPS route" else "Ready for a new route", color=Muted, fontSize=12.sp)
                }
                Icon(Icons.Default.MyLocation, null, tint=Mint, modifier=Modifier.size(34.dp))
            }
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                Metric("GPS", currentLocation?.let { "±${it.accuracy.toInt()} m" } ?: "Waiting", Modifier.weight(1f))
                Metric("ROUTE", "${points.size} pts", Modifier.weight(1f))
                Metric("SITES", "${sites.size}", Modifier.weight(1f))
            }
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                ButtonTrace("Open Drive Test", Modifier.weight(1f)) { activePage="Drive Test" }
                ButtonTrace("Import Excel", Modifier.weight(1f), outlined=true) { pickExcel() }
            }
        }
        Spacer(Modifier.height(12.dp))
        Text("QUICK ACCESS", color=Muted, fontSize=11.sp, letterSpacing=2.sp)
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement=Arrangement.spacedBy(10.dp)) {
            QuickTile("Map", Icons.Default.Map, Modifier.weight(1f)) { activePage="Map" }
            QuickTile("Sites", Icons.Default.CellTower, Modifier.weight(1f)) { activePage="Sites" }
            QuickTile("Export", Icons.Default.FileDownload, Modifier.weight(1f)) { saveGeoJson.launch("TRACE-route.geojson") }
        }
        Spacer(Modifier.height(12.dp))
        CardBox {
            Text("SYSTEM STATUS", color=Mint, fontWeight=FontWeight.Bold, fontSize=11.sp)
            Spacer(Modifier.height(6.dp))
            Text(statusText, color=TextMain, fontSize=13.sp)
            Text("Track data is saved locally on this device.", color=Muted, fontSize=11.sp)
        }
    }

    @Composable private fun MapPage() {
        Row(verticalAlignment=Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("MAP", fontSize=23.sp, fontWeight=FontWeight.Bold)
                Text("Offline-ready map module", color=Muted, fontSize=12.sp)
            }
            ButtonTrace("GPS", outlined=true) { requestGps() }
        }
        Spacer(Modifier.height(12.dp))
        Box(Modifier.fillMaxWidth().weight(1f).clip(RoundedCornerShape(24.dp)).background(Color(0xFF111B18)).border(1.dp, Mint.copy(.22f), RoundedCornerShape(24.dp))) {
            // Deliberately a native map canvas placeholder; real Egypt street tiles must be bundled separately.
            androidx.compose.foundation.Canvas(Modifier.fillMaxSize()) {
                val step=42.dp.toPx()
                for (x in 0..(size.width/step).toInt()) drawLine(Color(0xFF25352E), androidx.compose.ui.geometry.Offset(x*step,0f), androidx.compose.ui.geometry.Offset(x*step,size.height), 1f)
                for (y in 0..(size.height/step).toInt()) drawLine(Color(0xFF25352E), androidx.compose.ui.geometry.Offset(0f,y*step), androidx.compose.ui.geometry.Offset(size.width,y*step), 1f)
                val path = androidx.compose.ui.graphics.Path()
                points.forEachIndexed { i,p ->
                    val x = (size.width*.5f + (p.longitude-(currentLocation?.longitude ?: p.longitude)).toFloat()*80000).coerceIn(8f,size.width-8f)
                    val y = (size.height*.5f - (p.latitude-(currentLocation?.latitude ?: p.latitude)).toFloat()*80000).coerceIn(8f,size.height-8f)
                    if(i==0) path.moveTo(x,y) else path.lineTo(x,y)
                }
                drawPath(path, Mint, style=androidx.compose.ui.graphics.drawscope.Stroke(width=4f))
            }
            Column(Modifier.align(Alignment.TopStart).padding(14.dp)) {
                Text("TRACE • FIELD MAP", color=Mint, fontSize=10.sp, fontWeight=FontWeight.Bold)
                Text("GPS ${currentLocation?.let { "%.5f, %.5f".format(it.latitude,it.longitude) } ?: "not fixed"}", color=TextMain, fontSize=11.sp)
            }
            Column(Modifier.align(Alignment.BottomCenter).padding(12.dp)) {
                Text("Base map tiles for Egypt are not bundled in this source yet.", color=Muted, fontSize=10.sp)
                ButtonTrace(if(tracking) "Stop recording" else "Start recording", Modifier.fillMaxWidth()) { if(tracking) stopTrack() else startTrack() }
            }
        }
    }

    @Composable private fun SitesPage() {
        Row(verticalAlignment=Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("SITE DATABASE", fontSize=22.sp, fontWeight=FontWeight.Bold)
                Text("${sites.size} loaded records", color=Muted, fontSize=12.sp)
            }
            ButtonTrace("Import", outlined=true) { pickExcel() }
        }
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(value=search, onValueChange={search=it}, modifier=Modifier.fillMaxWidth(), placeholder={Text("Search site, PCI, or area…", color=Muted)}, leadingIcon={Icon(Icons.Default.Search,null,tint=Mint)}, singleLine=true, colors=OutlinedTextFieldDefaults.colors(focusedBorderColor=Mint, unfocusedBorderColor=Muted.copy(.35f), focusedTextColor=TextMain, unfocusedTextColor=TextMain, cursorColor=Mint))
        Spacer(Modifier.height(10.dp))
        if(sites.isEmpty()) {
            CardBox {
                Icon(Icons.Default.TableChart, null, tint=Mint, modifier=Modifier.size(34.dp))
                Text("Import your site Excel", fontSize=18.sp, fontWeight=FontWeight.Bold)
                Text("Choose an .xlsx or .xls file from your phone. The selected file is read locally.", color=Muted, fontSize=12.sp)
                ButtonTrace("Choose Excel file", Modifier.fillMaxWidth()) { pickExcel() }
            }
        } else {
            LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp), contentPadding=PaddingValues(bottom=14.dp)) {
                items(sites.filter { "${it.name} ${it.location} ${it.pci} ${it.tech}".contains(search, true) }) { site ->
                    CardBox {
                        Row(verticalAlignment=Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(site.name, fontWeight=FontWeight.Bold, fontSize=15.sp)
                                Text(listOf(site.location,site.tech,if(site.pci.isNotBlank()) "PCI ${site.pci}" else "").filter{it.isNotBlank()}.joinToString(" • "), color=Muted, fontSize=11.sp)
                                Text("${site.lat ?: "—"}, ${site.lon ?: "—"}", color=Mint, fontSize=11.sp)
                            }
                            Icon(Icons.Default.CellTower, null, tint=Mint)
                        }
                    }
                }
            }
        }
    }

    @Composable private fun DrivePage() {
        Text("LIVE TRACK", color=Muted, fontSize=11.sp, letterSpacing=2.sp)
        Spacer(Modifier.height(10.dp))
        CardBox {
            Row(verticalAlignment=Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(if(tracking) "Recording route" else "Drive session", fontSize=20.sp, fontWeight=FontWeight.Bold)
                    Text(if(tracking) "GPS points are being captured" else "Start when you're ready to drive", color=Muted, fontSize=12.sp)
                }
                Icon(Icons.Default.Route, null, tint=Mint, modifier=Modifier.size(34.dp))
            }
            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                Metric("POINTS", "${points.size}")
                Metric("DISTANCE", "%.2f km".format(routeDistanceKm()))
                Metric("GPS", currentLocation?.let { "${it.accuracy.toInt()} m" } ?: "—")
            }
            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                ButtonTrace(if(tracking) "Stop" else if(points.isNotEmpty()) "Resume" else "Start", Modifier.weight(1f)) { if(tracking) stopTrack() else startTrack() }
                ButtonTrace("Export GeoJSON", Modifier.weight(1f), outlined=true) { saveGeoJson.launch("TRACE-route.geojson") }
            }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                ButtonTrace("Clear route", Modifier.weight(1f), outlined=true) { points.clear(); persistTrack(); statusText="Route cleared." }
                ButtonTrace("Get GPS", Modifier.weight(1f), outlined=true) { requestGps() }
            }
        }
        Spacer(Modifier.height(12.dp))
        CardBox {
            Text("CURRENT FIX", color=Mint, fontWeight=FontWeight.Bold, fontSize=11.sp)
            Text(currentLocation?.let { "Lat %.6f   Lon %.6f".format(it.latitude,it.longitude) } ?: "Waiting for location permission / GPS", fontSize=13.sp)
            Text(currentLocation?.let { "Accuracy ±${it.accuracy.toInt()} m" } ?: statusText, color=Muted, fontSize=11.sp)
        }
        Spacer(Modifier.height(12.dp))
        Text("RECENT POINTS", color=Muted, fontSize=11.sp, letterSpacing=2.sp)
        LazyColumn(verticalArrangement=Arrangement.spacedBy(6.dp), contentPadding=PaddingValues(top=8.dp,bottom=12.dp)) {
            items(points.takeLast(8).reversed()) { p ->
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Panel).padding(10.dp), verticalAlignment=Alignment.CenterVertically) {
                    Box(Modifier.size(25.dp).clip(CircleShape).background(Panel2), contentAlignment=Alignment.Center) { Text("•", color=Mint) }
                    Spacer(Modifier.width(8.dp))
                    Text("%.6f, %.6f".format(p.latitude,p.longitude), modifier=Modifier.weight(1f), fontSize=11.sp)
                    Text("${p.accuracy.toInt()}m", color=Muted, fontSize=10.sp)
                }
            }
        }
    }

    @Composable private fun MorePage() {
        Text("TOOLS & SETTINGS", fontSize=22.sp, fontWeight=FontWeight.Bold)
        Text("Local-first field utilities", color=Muted, fontSize=12.sp)
        Spacer(Modifier.height(12.dp))
        CardBox {
            Text("DATABASE", color=Mint, fontWeight=FontWeight.Bold, fontSize=11.sp)
            Text("Loaded sites: ${sites.size}", fontSize=16.sp)
            ButtonTrace("Import Excel / replace database", Modifier.fillMaxWidth(), outlined=true) { pickExcel() }
        }
        Spacer(Modifier.height(10.dp))
        CardBox {
            Text("TRACK EXPORT", color=Mint, fontWeight=FontWeight.Bold, fontSize=11.sp)
            Text("Exports route points only in GeoJSON LineString format.", color=Muted, fontSize=12.sp)
            ButtonTrace("Save route to phone", Modifier.fillMaxWidth()) { saveGeoJson.launch("TRACE-route.geojson") }
        }
        Spacer(Modifier.height(10.dp))
        CardBox {
            Text("ABOUT TRACE", color=Mint, fontWeight=FontWeight.Bold, fontSize=11.sp)
            Text("Native Android foundation • Version 2.0.0", fontSize=13.sp)
            Text("Offline Egypt street maps require a prepared regional tile package and are not included yet.", color=Muted, fontSize=11.sp)
        }
    }

    @Composable private fun CardBox(content: @Composable ColumnScope.() -> Unit) {
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(Panel).border(1.dp, Mint.copy(.15f), RoundedCornerShape(22.dp)).padding(16.dp), verticalArrangement=Arrangement.spacedBy(8.dp), content=content)
    }
    @Composable private fun Metric(label:String, value:String, modifier:Modifier=Modifier) {
        Column(modifier.clip(RoundedCornerShape(14.dp)).background(Panel2).padding(10.dp)) {
            Text(label, color=Muted, fontSize=9.sp, letterSpacing=1.sp)
            Text(value, color=TextMain, fontWeight=FontWeight.Bold, fontSize=14.sp, maxLines=1)
        }
    }
    @Composable private fun ButtonTrace(label:String, modifier:Modifier=Modifier, outlined:Boolean=false, onClick:()->Unit) {
        if(outlined) OutlinedButton(onClick=onClick, modifier=modifier, shape=RoundedCornerShape(14.dp), border=androidx.compose.foundation.BorderStroke(1.dp,Mint.copy(.55f)), colors=ButtonDefaults.outlinedButtonColors(contentColor=Mint)) { Text(label, fontSize=12.sp) }
        else Button(onClick=onClick, modifier=modifier, shape=RoundedCornerShape(14.dp), colors=ButtonDefaults.buttonColors(containerColor=Mint,contentColor=Bg)) { Text(label, fontWeight=FontWeight.Bold, fontSize=12.sp) }
    }
    @Composable private fun QuickTile(label:String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier:Modifier=Modifier, onClick:()->Unit) {
        Card(onClick=onClick, modifier=modifier, colors=CardDefaults.cardColors(containerColor=Panel), shape=RoundedCornerShape(18.dp)) {
            Column(Modifier.fillMaxWidth().padding(vertical=18.dp), horizontalAlignment=Alignment.CenterHorizontally, verticalArrangement=Arrangement.spacedBy(7.dp)) {
                Icon(icon,null,tint=Mint,modifier=Modifier.size(25.dp)); Text(label,color=TextMain,fontSize=11.sp,fontWeight=FontWeight.SemiBold)
            }
        }
    }

    private fun pickExcel() { openExcel.launch(arrayOf("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet","application/vnd.ms-excel","application/octet-stream")) }
    private fun importWorkbook(uri:Uri) {
        statusText = "Reading Excel…"
        Thread {
            try {
                contentResolver.openInputStream(uri).use { input ->
                    requireNotNull(input) { "Could not open selected file" }.use { stream ->
                        val workbook = WorkbookFactory.create(stream)
                        val sheet = workbook.getSheetAt(0)
                        val header = sheet.getRow(0) ?: error("First sheet has no header row")
                        val headers = (0 until header.lastCellNum).associateBy { header.getCell(it)?.toString()?.trim()?.lowercase(Locale.ROOT) ?: "" }
                        fun col(vararg candidates:String) = candidates.firstNotNullOfOrNull { c -> headers.entries.firstOrNull { it.key.contains(c) }?.value }
                        val nameCol=col("site name","site","cai","ncai","name")
                        val latCol=col("latitude","lat")
                        val lonCol=col("longitude","lon","long")
                        val locCol=col("city","area","location","region")
                        val pciCol=col("pci")
                        val techCol=col("technology","tech","rat")
                        if(nameCol==null) error("Couldn't find a Site Name / Site / CAI column.")
                        val parsed= mutableListOf<Site>()
                        for(r in 1..sheet.lastRowNum) {
                            val row=sheet.getRow(r) ?: continue
                            fun cell(i:Int?) = i?.let { row.getCell(it)?.toString()?.trim() }.orEmpty()
                            val name=cell(nameCol)
                            if(name.isBlank()) continue
                            val lat=cell(latCol).replace(",","").toDoubleOrNull()
                            val lon=cell(lonCol).replace(",","").toDoubleOrNull()
                            parsed += Site(name,lat,lon,cell(locCol),cell(pciCol),cell(techCol))
                        }
                        workbook.close()
                        runOnUiThread {
                            sites.clear()
                            sites.addAll(parsed.distinctBy { it.name.trim().uppercase(Locale.ROOT) })
                            persistSites()
                            statusText="Imported ${sites.size} sites from Excel."
                            Toast.makeText(this,"Imported ${sites.size} sites",Toast.LENGTH_LONG).show()
                        }
                    }
                }
            } catch(e:Exception) {
                runOnUiThread { statusText="Excel import failed: ${e.message ?: "unknown error"}"; Toast.makeText(this,statusText,Toast.LENGTH_LONG).show() }
            }
        }.start()
    }

    private fun requestGps() {
        val fine=ContextCompat.checkSelfPermission(this,Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED
        val coarse=ContextCompat.checkSelfPermission(this,Manifest.permission.ACCESS_COARSE_LOCATION)==PackageManager.PERMISSION_GRANTED
        if(!fine && !coarse) askLocation.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION))
        else startGpsWatch()
    }
    private fun startGpsWatch() {
        try {
            val listener=object:LocationListener {
                override fun onLocationChanged(location:Location) {
                    currentLocation=location
                    if(tracking && location.accuracy <= 50f) {
                        val previous=points.lastOrNull()
                        val accept=previous==null || (previous.distanceTo(location)>=4f && previous.distanceTo(location)/max(1f,(location.time-previous.time)/1000f) <= 55f)
                        if(accept) { points.add(location); persistTrack() }
                    }
                    lastLocationAt=System.currentTimeMillis()
                }
                @Deprecated("Deprecated in Java") override fun onStatusChanged(provider:String?,status:Int,extras:Bundle?) {}
                override fun onProviderEnabled(provider:String) {}
                override fun onProviderDisabled(provider:String) { statusText="GPS provider disabled." }
            }
            gpsListener?.let { runCatching { locationManager.removeUpdates(it) } }
            gpsListener=listener
            val providers=locationManager.getProviders(true)
            val provider=when { providers.contains(LocationManager.GPS_PROVIDER)->LocationManager.GPS_PROVIDER; providers.contains(LocationManager.NETWORK_PROVIDER)->LocationManager.NETWORK_PROVIDER; else -> null }
            if(provider==null) { statusText="Enable device location."; return }
            locationManager.requestLocationUpdates(provider,1500L,0f,listener,mainLooper)
            locationManager.getLastKnownLocation(provider)?.let { currentLocation=it }
            statusText="GPS listener active."
        } catch(e:SecurityException) { statusText="Location permission denied." }
        catch(e:Exception) { statusText="GPS error: ${e.message}" }
    }
    private fun startTrack() {
        requestGps()
        tracking=true
        if(trackStartedAt==0L) trackStartedAt=System.currentTimeMillis()
        statusText="Live Track started."
        persistTrack()
    }
    private fun stopTrack() {
        tracking=false
        trackStartedAt=0L
        statusText="Track paused. Resume to continue the same route."
        persistTrack()
    }
    private fun persistSites() {
        val arr = JSONArray()
        sites.forEach { site ->
            arr.put(JSONObject()
                .put("name", site.name)
                .put("lat", site.lat ?: JSONObject.NULL)
                .put("lon", site.lon ?: JSONObject.NULL)
                .put("location", site.location)
                .put("pci", site.pci)
                .put("tech", site.tech))
        }
        prefs.edit().putString("site_records", arr.toString()).apply()
    }

    private fun restoreSites() {
        val saved = prefs.getString("site_records", null) ?: return
        try {
            val arr = JSONArray(saved)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val lat = if (o.isNull("lat")) null else o.optDouble("lat")
                val lon = if (o.isNull("lon")) null else o.optDouble("lon")
                sites.add(Site(o.optString("name"), lat, lon, o.optString("location"), o.optString("pci"), o.optString("tech")))
            }
            statusText = "Restored ${sites.size} sites from local storage."
        } catch (_: Exception) {
            prefs.edit().remove("site_records").apply()
            statusText = "Saved site data could not be read. Import the Excel file again."
        }
    }

    private fun persistTrack() {
        val arr=JSONArray()
        points.forEach { p -> arr.put(JSONObject().put("lat",p.latitude).put("lon",p.longitude).put("accuracy",p.accuracy).put("time",p.time)) }
        prefs.edit().putString("route_points",arr.toString()).putLong("route_saved_at",System.currentTimeMillis()).putBoolean("tracking",tracking).apply()
    }
    private fun restoreTrack() {
        val saved=prefs.getString("route_points",null) ?: return
        try {
            val arr=JSONArray(saved)
            val savedAt=prefs.getLong("route_saved_at",0L)
            if(System.currentTimeMillis()-savedAt > 2*60*60*1000L) {
                prefs.edit().remove("route_points").remove("route_saved_at").putBoolean("tracking",false).apply()
                return
            }
            for(i in 0 until arr.length()) {
                val o=arr.getJSONObject(i)
                val l=Location("restored")
                l.latitude=o.getDouble("lat"); l.longitude=o.getDouble("lon"); l.accuracy=o.optDouble("accuracy",0.0).toFloat(); l.time=o.optLong("time")
                points.add(l)
            }
        } catch(_:Exception) { prefs.edit().remove("route_points").apply() }
    }
    private fun routeDistanceKm():Double {
        var sum=0.0
        for(i in 1 until points.size) sum += points[i-1].distanceTo(points[i])
        return sum/1000.0
    }
    private fun exportGeoJson(uri:Uri) {
        try {
            val coordinates=JSONArray()
            points.forEach { p -> coordinates.put(JSONArray().put(p.longitude).put(p.latitude)) }
            val props=JSONObject().put("name","TRACE route").put("pointCount",points.size).put("exportedAt",SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX",Locale.US).format(Date()))
            val feature=JSONObject().put("type","Feature").put("properties",props)
                .put("geometry", if(points.size>=2) JSONObject().put("type","LineString").put("coordinates",coordinates) else JSONObject().put("type","MultiPoint").put("coordinates",coordinates))
            val collection=JSONObject().put("type","FeatureCollection").put("features",JSONArray().put(feature))
            contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(collection.toString(2)) }
            Toast.makeText(this,"GeoJSON route saved.",Toast.LENGTH_LONG).show()
        } catch(e:Exception) { Toast.makeText(this,"Export failed: ${e.message}",Toast.LENGTH_LONG).show() }
    }
    override fun onDestroy() {
        gpsListener?.let { runCatching { locationManager.removeUpdates(it) } }
        super.onDestroy()
    }
}
