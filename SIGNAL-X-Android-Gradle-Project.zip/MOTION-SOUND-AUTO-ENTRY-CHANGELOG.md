# Motion & Sound Auto-Entry Update — 2026

- Changed the launch intro from tap-to-enter to an automatic entry after ~1.8 seconds.
- Kept an optional Skip Intro action for immediate entry.
- Added a lightweight progress sweep and accessible status text.
- Respects `prefers-reduced-motion` with a shorter timing path.
- Preserved `enter()`'s map invalidate/resize step after the overlay is removed.
- Updated Android launcher icons, PWA icons/manifests and native deep-graphite safe-area colors.
- Did not rewrite map/GPS/drive-test controller logic in this change.
