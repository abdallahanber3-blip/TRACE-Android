# SIGNAL X WebView bridge is accessed from JavaScript. Keep public bridge methods if minification is enabled.
