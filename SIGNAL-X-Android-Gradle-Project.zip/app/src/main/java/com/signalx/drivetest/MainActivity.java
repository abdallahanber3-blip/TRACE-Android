package com.signalx.drivetest;

import android.Manifest;
import android.app.Activity;
import android.content.ContentResolver;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.DocumentsContract;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.webkit.GeolocationPermissions;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebSettings;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.webkit.WebViewAssetLoader;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import androidx.webkit.WebViewClientCompat;

import java.io.OutputStream;
import java.io.IOException;
import java.util.Locale;
import android.util.Base64;

public class MainActivity extends Activity {
    private static final String APP_URL = "https://appassets.androidplatform.net/assets/www/index.html";
    private static final int REQUEST_LOCATION = 4101;
    private static final int REQUEST_IMPORT_FILE = 4102;
    private static final int REQUEST_SAVE_FILE = 4103;

    private WebView webView;
    private FrameLayout rootLayout;
    private WebViewAssetLoader assetLoader;
    private ValueCallback<Uri[]> uploadCallback;
    private GeolocationPermissions.Callback geolocationCallback;
    private String geolocationOrigin;
    private byte[] pendingSaveBytes;
    private String pendingSaveName;
    private String pendingSaveMime = "application/geo+json";

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        configureSystemBars();

        assetLoader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(8, 23, 14));
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        webView.setVerticalScrollBarEnabled(false);
        webView.setHorizontalScrollBarEnabled(false);
        webView.setWebViewClient(new WebViewClientCompat() {
            @Override
            public android.webkit.WebResourceResponse shouldInterceptRequest(
                    WebView view, WebResourceRequest request) {
                return assetLoader.shouldInterceptRequest(request.getUrl());
            }
        });

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setGeolocationEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setMediaPlaybackRequiresUserGesture(true);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        }

        webView.addJavascriptInterface(new SignalXBridge(), "SignalXAndroid");
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onGeolocationPermissionsShowPrompt(
                    String origin, GeolocationPermissions.Callback callback) {
                if (hasLocationPermission()) {
                    callback.invoke(origin, true, false);
                } else {
                    geolocationOrigin = origin;
                    geolocationCallback = callback;
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        requestPermissions(new String[]{
                                Manifest.permission.ACCESS_FINE_LOCATION,
                                Manifest.permission.ACCESS_COARSE_LOCATION
                        }, REQUEST_LOCATION);
                    } else {
                        callback.invoke(origin, false, false);
                    }
                }
            }

            @Override
            public boolean onShowFileChooser(
                    WebView view,
                    ValueCallback<Uri[]> filePathCallback,
                    FileChooserParams fileChooserParams) {
                if (uploadCallback != null) {
                    uploadCallback.onReceiveValue(null);
                }
                uploadCallback = filePathCallback;
                try {
                    // Do not apply an EXTRA_MIME_TYPES whitelist here. This WebView file
                    // chooser is shared by the Excel and GeoJSON inputs. Android document
                    // providers label .xlsx/.xls inconsistently (spreadsheet MIME, ZIP, or
                    // octet-stream); a restrictive MIME whitelist makes valid Excel files
                    // disappear from the phone's picker.
                    Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("*/*");
                    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    try {
                        startActivityForResult(intent, REQUEST_IMPORT_FILE);
                    } catch (Exception openDocumentError) {
                        // Fallback for file providers/devices that do not expose ACTION_OPEN_DOCUMENT.
                        Intent fallback = new Intent(Intent.ACTION_GET_CONTENT);
                        fallback.addCategory(Intent.CATEGORY_OPENABLE);
                        fallback.setType("*/*");
                        fallback.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        startActivityForResult(fallback, REQUEST_IMPORT_FILE);
                    }
                    return true;
                } catch (Exception e) {
                    ValueCallback<Uri[]> failedCallback = uploadCallback;
                    uploadCallback = null;
                    if (failedCallback != null) failedCallback.onReceiveValue(null);
                    Toast.makeText(MainActivity.this,
                            "Unable to open file picker", Toast.LENGTH_LONG).show();
                    return true;
                }
            }
        });

        // Keep the WebView itself below the status bar/camera cutout. Applying padding
        // to a WebView is not sufficient for CSS fixed-position headers: they can still
        // render in the WebView's full viewport behind the punch-hole/status area.
        // A native root with inset-driven WebView margins makes the usable viewport
        // start below the camera/signal row on every device size.
        rootLayout = new FrameLayout(this);
        rootLayout.setBackgroundColor(Color.rgb(8, 23, 14));
        FrameLayout.LayoutParams webParams = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT);
        rootLayout.addView(webView, webParams);
        configureEdgeToEdgeInsets(rootLayout, webView);
        setContentView(rootLayout);
        ViewCompat.requestApplyInsets(rootLayout);
        webView.loadUrl(APP_URL);
    }

    private void configureSystemBars() {
        Window window = getWindow();
        WindowCompat.setDecorFitsSystemWindows(window, false);
        window.setStatusBarColor(Color.TRANSPARENT);
        window.setNavigationBarColor(Color.TRANSPARENT);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            window.setNavigationBarContrastEnforced(false);
            window.setStatusBarContrastEnforced(false);
        }
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        WindowInsetsControllerCompat controller =
                WindowCompat.getInsetsController(window, window.getDecorView());
        controller.setAppearanceLightStatusBars(false);
        controller.setAppearanceLightNavigationBars(false);
    }

    private int dp(float value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private void configureEdgeToEdgeInsets(FrameLayout root, WebView target) {
        ViewCompat.setOnApplyWindowInsetsListener(root, (view, insets) -> {
            // Reserve the Android status bar + display cutout as real native space.
            // Use margins (not WebView padding) so CSS position:fixed controls cannot
            // slide underneath a camera punch-hole or the notification icons.
            int safeTypes = WindowInsetsCompat.Type.systemBars()
                    | WindowInsetsCompat.Type.displayCutout();
            Insets safe = insets.getInsets(safeTypes);
            int topGap = dp(16); // extra visual breathing room below the status/camera area
            int imeBottom = insets.isVisible(WindowInsetsCompat.Type.ime())
                    ? insets.getInsets(WindowInsetsCompat.Type.ime()).bottom : 0;
            int bottom = Math.max(safe.bottom, imeBottom);

            android.view.ViewGroup.LayoutParams raw = target.getLayoutParams();
            if (raw instanceof FrameLayout.LayoutParams) {
                FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) raw;
                int wantedTop = safe.top + topGap;
                if (lp.leftMargin != safe.left || lp.topMargin != wantedTop
                        || lp.rightMargin != safe.right || lp.bottomMargin != bottom) {
                    lp.leftMargin = safe.left;
                    lp.topMargin = wantedTop;
                    lp.rightMargin = safe.right;
                    lp.bottomMargin = bottom;
                    target.setLayoutParams(lp);
                }
            }
            // We have applied the insets to the WebView's outer geometry ourselves.
            // Consuming them prevents the WebView from adding a second, inconsistent inset.
            return WindowInsetsCompat.CONSUMED;
        });
    }

    private void setNativeTheme(String theme) {
        boolean light = "light".equalsIgnoreCase(theme);
        runOnUiThread(() -> {
            WindowInsetsControllerCompat controller =
                    WindowCompat.getInsetsController(getWindow(), webView);
            controller.setAppearanceLightStatusBars(light);
            controller.setAppearanceLightNavigationBars(light);
            // Match the exposed safe-area padding to the selected app theme.
            int safeAreaColor = light ? Color.rgb(238, 244, 239) : Color.rgb(8, 23, 14);
            if (rootLayout != null) rootLayout.setBackgroundColor(safeAreaColor);
            if (webView != null) webView.setBackgroundColor(safeAreaColor);
        });
    }

    private boolean hasLocationPermission() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return true;
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                || checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_LOCATION && geolocationCallback != null) {
            boolean granted = hasLocationPermission();
            geolocationCallback.invoke(geolocationOrigin, granted, false);
            geolocationCallback = null;
            geolocationOrigin = null;
            if (!granted) {
                Toast.makeText(this, "Location permission is needed for GPS tracking.", Toast.LENGTH_LONG).show();
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_IMPORT_FILE) {
            if (uploadCallback != null) {
                Uri uri = (resultCode == RESULT_OK && data != null) ? data.getData() : null;
                uploadCallback.onReceiveValue(uri == null ? null : new Uri[]{uri});
                uploadCallback = null;
            }
            return;
        }
        if (requestCode == REQUEST_SAVE_FILE) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null && pendingSaveBytes != null) {
                try (OutputStream out = getContentResolver().openOutputStream(data.getData())) {
                    if (out == null) throw new IOException("Could not open destination");
                    out.write(pendingSaveBytes);
                    out.flush();
                    Toast.makeText(this, "GeoJSON exported successfully.", Toast.LENGTH_LONG).show();
                } catch (Exception e) {
                    Toast.makeText(this, "Could not save GeoJSON file.", Toast.LENGTH_LONG).show();
                }
            }
            pendingSaveBytes = null;
            pendingSaveName = null;
        }
    }

    private void requestSave(String fileName, String mimeType, String base64) {
        try {
            byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
            if (bytes.length == 0) {
                runOnUiThread(() -> Toast.makeText(this, "Export file is empty.", Toast.LENGTH_LONG).show());
                return;
            }
            runOnUiThread(() -> {
                pendingSaveBytes = bytes;
                pendingSaveName = sanitizeFileName(fileName);
                pendingSaveMime = (mimeType == null || mimeType.isEmpty()) ? "application/geo+json" : mimeType;
                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType(pendingSaveMime);
                intent.putExtra(Intent.EXTRA_TITLE, pendingSaveName);
                try {
                    startActivityForResult(intent, REQUEST_SAVE_FILE);
                } catch (Exception e) {
                    pendingSaveBytes = null;
                    Toast.makeText(this, "Unable to open save dialog.", Toast.LENGTH_LONG).show();
                }
            });
        } catch (Exception e) {
            runOnUiThread(() -> Toast.makeText(this, "Could not prepare GeoJSON export.", Toast.LENGTH_LONG).show());
        }
    }

    private String sanitizeFileName(String name) {
        String out = (name == null || name.trim().isEmpty()) ? "signal-x-track.geojson" : name.trim();
        out = out.replaceAll("[\\\\/:*?\"<>|]", "_");
        if (!out.toLowerCase().endsWith(".geojson") && !out.toLowerCase().endsWith(".json")) {
            out += ".geojson";
        }
        return out;
    }

    public class SignalXBridge {
        @JavascriptInterface
        public void saveBase64(String filename, String mimeType, String data) {
            requestSave(filename, mimeType, data);
        }

        @JavascriptInterface
        public String getPlatform() {
            return "android";
        }

        @JavascriptInterface
        public void openGoogleMapsDirections(double latitude, double longitude) {
            if (!Double.isFinite(latitude) || !Double.isFinite(longitude)
                    || Math.abs(latitude) > 90d || Math.abs(longitude) > 180d) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this,
                        "Site coordinates are invalid.", Toast.LENGTH_LONG).show());
                return;
            }
            runOnUiThread(() -> {
                String destination = String.format(Locale.US, "%.7f,%.7f", latitude, longitude);
                // Prefer the installed Google Maps app, which can directly start driving directions.
                Intent navigationIntent = new Intent(Intent.ACTION_VIEW,
                        Uri.parse("google.navigation:q=" + destination + "&mode=d"));
                navigationIntent.setPackage("com.google.android.apps.maps");
                try {
                    startActivity(navigationIntent);
                    return;
                } catch (Exception mapsUnavailable) {
                    // Fall back to the standard Google Maps directions URL. ACTION_VIEW leaves
                    // the WebView and lets Android route it to Google Maps or a browser.
                }
                String mapsUrl = "https://www.google.com/maps/dir/?api=1&destination="
                        + Uri.encode(destination) + "&travelmode=driving";
                Intent webDirections = new Intent(Intent.ACTION_VIEW, Uri.parse(mapsUrl));
                try {
                    startActivity(webDirections);
                } catch (Exception noExternalHandler) {
                    Toast.makeText(MainActivity.this,
                            "Could not open Google Maps. Check that a browser or Maps is installed.",
                            Toast.LENGTH_LONG).show();
                }
            });
        }

        @JavascriptInterface
        public void setTheme(String theme) {
            setNativeTheme(theme);
        }
    }

    @Override
    protected void onPause() {
        if (webView != null) webView.onPause();
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (webView != null) webView.onResume();
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.loadUrl("about:blank");
            webView.removeJavascriptInterface("SignalXAndroid");
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
