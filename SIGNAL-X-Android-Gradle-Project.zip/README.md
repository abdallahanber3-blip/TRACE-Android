# SIGNAL X Android Project

Android WebView application package based on the approved SIGNAL X V68 app UI. This package provides an actual Android Gradle project for GitHub Actions; it is not just a PWA zip.

## Included

- `settings.gradle.kts` at the project root (the file missing in the failed build logs).
- Android application module with Internet access and runtime GPS permission handling.
- Secure local WebView asset origin (`https://appassets.androidplatform.net/...`) via AndroidX WebKit.
- Native file picker for Import GeoJSON.
- Native Save dialog for exported GeoJSON files.
- Main app HTML with SIGNAL X startup screen and synthesized tap feedback.
- GitHub Actions workflow at `.github/workflows/build-apk.yml` for building a debug APK.

## Use with GitHub

1. Download and extract this project archive on your computer.
2. In the `abdallahanber3-blip/TRACE-Android` repository, replace the previous broken build setup with the **contents of this folder** at repository root.
3. Ensure `settings.gradle.kts`, `build.gradle.kts`, `gradle.properties`, `app/`, and `.github/workflows/build-apk.yml` are present at the repository root. Do not upload this outer ZIP as the only repository file.
4. Remove the old root project ZIP from the repository so the old workflow does not pick the wrong archive.
5. Open **Actions → Build SIGNAL X APK** and run it (or push to `main`).
6. Download the `SIGNAL-X-debug-APK` artifact from the successful workflow run.

## Local build

Install JDK 17, Android SDK platform 35, and Gradle 8.9, then run:

```bash
gradle assembleDebug
```

The APK output path is `app/build/outputs/apk/debug/app-debug.apk`.

## Notes

- The artifact built by this workflow is a debug APK for testing and direct installation. A production/release APK requires a release signing keystore.
- GPS requires the user to grant location permission in Android.
- Map tiles, Leaflet/CDN assets, and the connected network database remain dependent on their existing external sources; this package does not rewrite those sources or change the dark-map filter.
- The original approved HTML reference is kept under `reference/`.
