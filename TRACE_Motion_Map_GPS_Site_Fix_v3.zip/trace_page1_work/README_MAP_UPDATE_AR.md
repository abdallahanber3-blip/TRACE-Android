# TRACE Motion — Map Update v2

## What changed
- Replaced the decorative Compose Canvas grid with an actual OSMDroid map view.
- Default map tiles use CartoDB Dark Matter (online tile access required); Light Street switches to OpenStreetMap tiles.
- Only sites explicitly added from Search are rendered as map markers.
- Duplicate prevention remains based on normalized site name.
- Selecting a marker opens the Site Information card below the map and centers the map on that site's coordinates.
- The map starts on an Egypt-wide view when no site is selected.
- Clearing map sites removes the displayed markers without deleting the imported 4G/5G databases.
- Site details show available city, technology, bands, PCI, and coordinates.

## Important limitations
- Map tiles are online; offline Egypt tiles are not bundled.
- Markers require valid latitude and longitude from the imported database.
- Sector polygons/azimuth overlays are not drawn in this update because the current data model does not reliably parse per-sector azimuth coordinates. PCI is included in the selected marker's info when available; sector geometry must be added only after validating the Excel columns.
- The project has not been built with Gradle in this environment. Run the included GitHub Actions workflow and share the logs if it fails.
