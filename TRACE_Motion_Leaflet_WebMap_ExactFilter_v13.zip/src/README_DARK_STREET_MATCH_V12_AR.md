# إصلاح الخريطة بطريقة الموقع - V13

تم استبدال عرض الخريطة داخل صفحة الخريطة في Android من osmdroid إلى WebView مع Leaflet.

- نفس بلاطات OpenStreetMap المستخدمة في الموقع.
- نفس CSS حرفيًا: `invert(.88) hue-rotate(180deg) brightness(.72) contrast(.92) saturate(.62)`.
- الفلتر يطبق على `.leaflet-tile.trace-dark-tiles` فقط، وليس على علامات السايتات أو القطاعات.
- اختيار Light Street وSatellite موجود.
- يتم تمرير السايتات المختارة وبيانات Azimuth وPCI إلى Leaflet عبر JavaScript bridge.

ملاحظة: يحتاج الإنترنت لتحميل Leaflet وخرائط OSM/Esri. لم يتم اختبار APK فعليًا في بيئة التعديل لعدم توفر Gradle/Android SDK هنا.
