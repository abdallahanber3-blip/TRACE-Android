# SIGNAL X Android Project — v1.1.16

Screenshot-driven UI corrections. Open app/src/main/assets/www/index.html as the WebView entry point. See RELEASE-NOTES-v1.1.16.md.
