# TRACE Motion Dark Street fix v8

- Removed the CARTO dark tile endpoint that returned API KEY REQUIRED.
- Dark Street now loads standard OpenStreetMap raster tiles and applies a local Android color-matrix dark treatment; no style API key is required.
- Light Street uses the same OSM tiles without the dark filter.
- Satellite remains Esri World Imagery.

Note: This patch was inspected and packaged, but not built with Gradle or tested on a physical Android device in this environment. OSM tiles require network access and must follow OpenStreetMap tile usage policy.
