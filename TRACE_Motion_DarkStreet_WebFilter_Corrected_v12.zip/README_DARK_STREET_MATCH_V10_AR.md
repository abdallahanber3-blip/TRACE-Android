# TRACE Motion — Dark Street Match v10

- Dark Street now uses standard OpenStreetMap raster tiles instead of CARTO's dark endpoint.
- A custom `TilesOverlay` applies an Android `ColorMatrixColorFilter` only while drawing raster tiles; native markers and sector polygons are drawn outside this layer and keep their own colors.
- Light Street and Satellite keep separate tile sources.

Important: Android's ColorMatrix is an approximation of the website's chained CSS filters (`invert(.88) hue-rotate(180deg) brightness(.72) contrast(.92) saturate(.62)`), not a pixel-perfect CSS renderer. Build and device testing are still required before treating this as verified.
