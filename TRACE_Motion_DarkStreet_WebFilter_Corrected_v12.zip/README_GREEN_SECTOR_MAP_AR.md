# TRACE Motion — Green Sector Map Pass 2

Changes in this pass:
- Replaced the blue/cyan UI accents with the muted sage/olive green palette shown in the reference screenshot.
- Added an optional Azimuth/Bearing/Direction Excel column parser.
- Added geographic sector wedge rendering for the selected site when a valid azimuth exists: 110 m radius and 64° width (±32°), matching the web site's base geometry.
- Sector overlays are cleared/rebuilt with map overlays to avoid duplicates.

Limitations: sectors require a valid Azimuth/Bearing/Direction value in the imported workbook. Only source code was patched; APK build and on-device visual validation were not available in this environment.
