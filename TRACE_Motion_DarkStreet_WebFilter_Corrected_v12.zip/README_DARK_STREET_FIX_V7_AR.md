# TRACE Motion — Dark Street Fix v7

- Dark Street now points to CARTO's public `dark_all` tile endpoint using an explicit `z/x/y.png` URL builder (instead of OSM light tiles or a malformed URL).
- Light Street remains OpenStreetMap.
- Satellite remains Esri World Imagery.
- This source needs internet access. If CARTO denies access or the network blocks tiles, verify the exact tile URL and HTTP response on-device; this package was not built or device-tested in this environment.
