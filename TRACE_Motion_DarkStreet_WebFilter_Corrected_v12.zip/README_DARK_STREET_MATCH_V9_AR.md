# TRACE Motion — Dark Street Match v9

- Dark Street now uses an explicit CARTO raster URL builder (`z/x/y.png`) with multiple hostnames.
- Removed the whole-MapView ColorMatrix filter, because it also recolored native site markers, PCI labels, and sector polygons.
- Light Street remains on OpenStreetMap tiles.
- Satellite remains on Esri World Imagery.

Build/device verification: not performed in this environment. Dark tile loading still requires internet access and depends on the tile service being reachable from the device.
