# SIGNAL X Android — Network Intelligence · Tower Motion Edition

## Version 1.1.6 — Page Banners + Site Copy

- Removed the repeated application logo/wordmark from internal Home, Map and Sites page headers. Each internal page now has a descriptive page banner; Site Planner and Settings use the same system.
- Page banners switch between English and Arabic and adapt to Dark/Light mode.
- Tightened the approved Obsidian, Graphite, Amber and Ivory palette across the application. Green and red remain semantic status colors.
- Added a copy icon beside each site in nearby group chips and each To-do row. Copy is isolated from task completion and grouping.
- Preserved the existing Android launcher icon, startup identity, navigation, map, database, and drive-test handlers.

A complete Android Studio / Gradle WebView project for SIGNAL X 2026 using the approved Tower Motion brand identity. It includes the current app HTML, amber/ivory telecom tower launcher icon, Android GPS permission handling, Excel/GeoJSON file picker support, GeoJSON Save As, Google Maps handoff, Site Planner Show in Map preview, and a GitHub Actions workflow for a debug APK.

## Version 1.1.5 — Approved Brand + Show in Map

- Added a standalone **SITE PLANNER** page to the bottom navigation.
- Accepts one site name or bulk-pasted site names (new lines, commas, semicolons, or `|`).
- Resolves entered names against the app's existing 4G and 5G records and uses their stored coordinates; it does not import a second database.
- Groups pending sites in selectable group sizes from 2 to 7 using straight-line geographic distance (Haversine), with average and maximum within-group distance summaries and pair-distance details.
- Includes a persistent To-do checklist. Completed sites stay saved and are excluded from all subsequent grouping calculations. Re-entered names and CAI/NCAI aliases are deduplicated.
- The **Clear** action removes only the Site Planner list after confirmation; it does not alter the original 4G/5G databases, the map, or other app data.
- Each generated group now has an explicit **Show in Map** action. The action opens the map and displays numbered amber pins in its own temporary layer; a Planner-only Clear control removes that preview without touching normal map selections or drive-test layers.
- Site Planner state is saved locally on the device with `localStorage`; the map remains untouched until the user taps **Show in Map**. That explicit action creates a separate temporary numbered-pin layer, and its own **Clear** control removes only that layer.

## Carried forward from version 1.1.3

- **Android keyboard layout:** the fixed bottom navigation now hides while the Android IME is visible and returns when it closes.
- **Search suggestions layout:** Suggested Sites now flows beneath the search/filter controls instead of using an absolute overlay, so it cannot cover the input; the results panel has a bounded, scrollable height on phones.

- The app's launch intro now remains visible for about **2.4 seconds**, then fades to the workspace automatically. A 12-second CSS-only hide fallback remains armed only until startup JavaScript initializes; the overlay stays click-through outside `Skip intro`, so it cannot trap app interaction. Reduced-motion devices use a shorter intro.
- Added a 2.4-second progress sweep and an auto-hide failsafe, with a restrained, lightweight glass finish across buttons, cards and map controls.
- Reworked Site Information sector cards into compact rows: sector number badge plus compact PCI/Azimuth (or Azimuth/Band) metrics, eliminating oversized per-sector radar diagrams.
- Updated web icons and Android launcher icons to the approved SIGNAL X Tower Motion mark.
- Matched the native Android launch/safe-area color to the approved Obsidian/Amber palette.
- The accepted V68-derived app functionality and map control handlers are carried in `app/src/main/assets/www/index.html`; the untouched baseline reference remains in `reference/`.
- Sounds are synthesized in the page (no separate audio files), with a louder compressed master mix, a persistent 50–160% volume slider (default 120%), first-gesture audio unlock, global event delegation for app/map controls, and a Test Sound button in Settings. Android device media volume still controls the final loudness.

- **CAI/NCAI de-duplication:** selected-site state now uses the same canonical physical-site key as the map. `Cai0639` and `NCAI0639` cannot remain as two active entries; restored session state is also normalized before map rendering. The first selected display name is retained for readability.
- **Developer attribution:** launch screen, shared app header, Settings and footer identify **Developed by Eng. Abdallah Ali · 2026**.
- **Liquid-glass polish:** added restrained glass layering, inset highlights, background saturation/blur and smoother touch-state reflections to the data tiles, search/selected-site cards, map controls and Site Information actions without animating the Leaflet map container.
- **Startup intro corrected:** the intro now remains visible for roughly 2.4 seconds and transitions out smoothly; its fail-safe is delayed to 12 seconds so it no longer hides before the intended animation. `Skip intro` still enters immediately, and the overlay remains click-through elsewhere.
- **Louder, adjustable UI sounds:** raised tone envelopes and master output with compression, expanded the per-control click path, and added a persistent 50–160% sound-level slider (default 120%) and Test Sound control. Click tones fire on buttons, links, navigation, map chrome and action controls—not on free map dragging or typing.

## Option A — use the existing ZIP-extracting GitHub workflow

If your current repository has a pre-existing workflow that watches for the root file named `SIGNAL-X-Android-Gradle-Project.zip` and extracts it before building:

1. Upload this archive to the repository root using that exact filename: `SIGNAL-X-Android-Gradle-Project.zip`.
2. Remove older root-level project ZIPs so the old workflow cannot select the wrong version.
3. Let the existing workflow run, then open **Actions** and download the APK artifact from the successful run.

Important: the workflow inside this archive is not activated just by uploading the archive as one file; the repository's pre-existing workflow is what extracts and builds it.

## Option B — make this the actual repository source

For a normal standalone GitHub project (recommended for a new repo):

1. Extract this archive locally.
2. Upload the **contents** of the extracted folder to the repository root, preserving `.github/`, `app/`, `reference/`, `build.gradle.kts`, `settings.gradle.kts`, and `gradle.properties`.
3. Set the default branch to `main` or `master`, then open **Actions → Build SIGNAL X APK**. It runs on push or can be started with **Run workflow**.
4. Download the `SIGNAL-X-debug-APK` artifact.

Do not upload the ZIP alone for Option B; GitHub Actions only discovers workflow files that exist in the repository under `.github/workflows/`.

## Local build

Requirements: JDK 17, Android SDK platform 35, Build Tools 35.0.0, Gradle 8.9 or compatible.

From the repository root:

```bash
gradle --no-daemon clean assembleDebug
```

Output: `app/build/outputs/apk/debug/app-debug.apk`.

The provided APK workflow creates a **debug APK** for device testing. A Play Store/release build needs a release signing key and release configuration.

## Functional notes / honest test status

- GPS requires the user to grant Android location permission. If permission is denied, location-dependent features cannot locate the device.
- Map tiles, CDN libraries and external network data still require a working internet connection.
- The launcher auto-entry change was checked in source and the launch timer logic was reviewed; this environment cannot install and test the APK on a physical Android device. Verify GPS, Excel file selection, map tiles, Drive Test start/stop and sounds on the target phone after the GitHub build.
- To return to the previous stable UI, use `reference/SIGNAL-X-V68-APPROVED-REVIEWED-CLEANUP.html` as the rollback source.

## Version 1.1.6 validation note

- The page-banner and Site Planner copy changes passed syntax checks for all 30 inline JavaScript blocks and CSS parsing for all 17 style blocks.
- The Android and PWA ZIP archives passed ZIP integrity checks.
- A full in-browser runtime pass, APK build, and physical Android handset test were not completed in this environment. The build requires JDK 17, Android SDK platform 35, and Gradle 8.9 or a compatible toolchain.

## Version 1.1.5 validation note

The updated HTML assets passed inline JavaScript syntax checks and CSS parsing. The Android project files and launcher resources were reviewed, but a compiled APK is not included because this workspace has no installed Gradle executable or Android SDK. Build the debug APK through the included GitHub Actions workflow or a local Android/Gradle toolchain.


## Approved identity

See `SIGNAL-X-Brand-Guidelines-v1.1.5.md` for the consolidated logo, color, typography, iconography, UI and motion rules. The `app/src/main/assets/www/brand/` folder contains horizontal and vertical logo lockups for dark and light backgrounds in SVG and PNG.


- Tower Motion logo: telecommunications tower, amber signal waves and coverage curve; wordmark SIGNAL X with amber X; tagline NETWORK INTELLIGENCE.
- Palette: Obsidian `#101316`, Graphite `#272D33`, Electric Amber `#FFB84D`, Warm Ivory `#F4F1EA`, Success `#22C55E`, Error `#EF4444`.
- Typography: Sora (titles), Inter (English UI), IBM Plex Sans Arabic (Arabic UI), IBM Plex Mono (technical values).
- App/PWA icon now uses the tower-and-waves mark without wordmark text.
