# SIGNAL X signing setup

The Android app must be signed with the same private key for every update. GitHub runners are temporary machines, so their default debug key is not stable. This project blocks the build when the persistent key is not configured.

## Required GitHub Actions secrets

Add these repository secrets under **Settings → Secrets and variables → Actions**:

- `SIGNALX_KEYSTORE_BASE64` — Base64 contents of the private `.jks` file.
- `SIGNALX_KEYSTORE_PASSWORD` — keystore password.
- `SIGNALX_KEY_ALIAS` — `signalx-upload`.
- `SIGNALX_KEY_PASSWORD` — key password.

Do not paste any password or private key into a commit, issue, discussion, or chat. Keep a secure offline backup of the `.jks` file and both passwords. Losing the key prevents future in-place updates.

## First install / migration warning

The older workflow generated debug APKs on fresh GitHub runners. If the APK currently installed on a phone was signed by one of those temporary keys, this new persistent key may not match it. Android can then require a one-time uninstall/reinstall to switch signing identities. Do not uninstall until any data you need has been exported. Once the app and future builds use this persistent key and the same package ID, subsequent updates can install over the existing app.

## Build

After all four secrets are saved, run **Actions → Build update-compatible SIGNAL X APK → Run workflow**. The workflow verifies both the package ID and APK signature before publishing the artifact.
