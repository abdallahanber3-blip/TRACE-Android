$ErrorActionPreference = "Stop"
$keyPath = Join-Path (Get-Location) "signalx-upload-key.jks"
if (Test-Path $keyPath) { throw "Key already exists at $keyPath. Do not overwrite it." }
Write-Host "Creating your private SIGNAL X update-signing key. Keep this file and its passwords safe."
Write-Host "Use this same key for every future update. Losing it prevents in-place updates."
& keytool -genkeypair -v -keystore $keyPath -storetype JKS -alias signalx-upload -keyalg RSA -keysize 3072 -validity 10000
if ($LASTEXITCODE -ne 0) { throw "keytool failed." }
$b64 = [Convert]::ToBase64String([IO.File]::ReadAllBytes($keyPath))
Set-Clipboard -Value $b64
Write-Host "Created: $keyPath"
Write-Host "Base64 keystore value copied to clipboard for GitHub secret SIGNALX_KEYSTORE_BASE64."
Write-Host "Now add the key alias (default: signalx-upload), keystore password and key password as GitHub Actions secrets."
Write-Host "Do NOT commit this .jks file to GitHub. Store an offline backup in a safe place."
