#!/usr/bin/env bash
set -euo pipefail
KEY_PATH="$(pwd)/signalx-upload-key.jks"
if [[ -e "$KEY_PATH" ]]; then echo "Refusing to overwrite $KEY_PATH" >&2; exit 1; fi
keytool -genkeypair -v -keystore "$KEY_PATH" -storetype JKS -alias signalx-upload -keyalg RSA -keysize 3072 -validity 10000
base64 -w0 "$KEY_PATH" | (command -v xclip >/dev/null && xclip -selection clipboard || cat)
echo
echo "Created $KEY_PATH. Add the base64 value and passwords to GitHub Actions secrets. Never commit the key file."
