/* SIGNAL X PWA shell v1.1.28. External map tiles/CDNs are not cached. */
const CACHE_NAME = 'signal-x-shell-v128';
const SHELL = ['./index.html', './manifest.webmanifest', './icons/signal-x-icon.svg', './icons/signal-x-maskable.svg'];
self.addEventListener('install', event => {
  event.waitUntil((async () => {
    const cache = await caches.open(CACHE_NAME);
    await cache.addAll(SHELL);
    await self.skipWaiting();
  })());
});
self.addEventListener('activate', event => {
  event.waitUntil((async () => {
    const names = await caches.keys();
    await Promise.all(names.filter(name => name.startsWith('signal-x-shell-') && name !== CACHE_NAME).map(name => caches.delete(name)));
    await self.clients.claim();
  })());
});
self.addEventListener('fetch', event => {
  const request = event.request;
  if (request.method !== 'GET') return;
  const url = new URL(request.url);
  if (url.origin !== self.location.origin) return;
  if (request.mode === 'navigate') {
    event.respondWith((async () => {
      const cache = await caches.open(CACHE_NAME);
      try {
        const response = await fetch(request);
        if (response && response.ok) cache.put(new URL('./index.html', self.registration.scope).href, response.clone());
        return response;
      } catch (_) {
        return (await cache.match(new URL('./index.html', self.registration.scope).href)) || Response.error();
      }
    })());
  }
});
