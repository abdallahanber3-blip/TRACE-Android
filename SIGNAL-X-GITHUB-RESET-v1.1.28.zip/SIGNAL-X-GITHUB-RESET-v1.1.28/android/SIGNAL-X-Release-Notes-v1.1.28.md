# SIGNAL X v1.1.28 — Update-ready signing foundation

- Android `versionCode` advanced to 28 and `versionName` to `1.1.28`.
- Kept the existing GitHub debug APK effective application id (`com.signalx.drivetest.debug`) to avoid an unnecessary package-id change.
- Added a persistent CI signing configuration driven by GitHub Actions secrets.
- GitHub Actions now refuses to create an APK with a runner-generated temporary debug key.
- Added signing-key setup scripts and a setup guide.
- Confirmed the app keeps the same WebView origin and storage database names; startup does not clear WebView storage or IndexedDB.
- Bumped the PWA shell cache version to v128. This updates static assets only; it does not delete user data.

## Compatibility warning

This establishes a stable signing identity for future builds once configured. It cannot retroactively sign with the private key used by an APK already installed on a device. If the current installation was signed by a previous ephemeral GitHub Actions debug key, the first migration to the persistent key may still require a one-time reinstall. Reuse the old signing key if it exists; do not uninstall the current app before checking.

## Build

Configure the four GitHub Actions secrets documented in `SIGNING-KEY-SETUP.md`, then run the workflow. APK generation is not included in this source package because the private signing key must remain under the owner's control.
