# SIGNAL X v1.1.28

- Established a persistent GitHub Actions signing configuration.
- Retained package identity `com.signalx.drivetest.debug`.
- Set Android `versionCode` to 28 and `versionName` to `1.1.28`.
- Kept the canonical UI in `web/index.html` and syncs it into Android assets during each build.
- Build fails safely when signing secrets are missing; it never emits a misleading temporary-key APK.
- Preserves the WebView storage origin and existing IndexedDB data unless the app is uninstalled or storage is cleared.
