SIGNAL X Web / PWA v1.1.16 — Field UI Reorganization. Open index.html. See RELEASE-NOTES-v1.1.16.md.
