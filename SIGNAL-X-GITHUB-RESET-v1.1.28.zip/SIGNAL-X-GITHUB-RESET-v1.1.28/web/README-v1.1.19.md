# SIGNAL X Web / PWA v1.1.19

Planner map preview visual fix. See RELEASE-NOTES-v1.1.19.md.
