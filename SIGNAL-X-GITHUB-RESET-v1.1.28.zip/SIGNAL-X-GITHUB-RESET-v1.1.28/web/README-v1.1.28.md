SIGNAL X v1.1.28 web/PWA shell. The PWA cache was advanced to v128. Native Android in-place update signing is configured in the Android project; see android/SIGNING-KEY-SETUP.md.
