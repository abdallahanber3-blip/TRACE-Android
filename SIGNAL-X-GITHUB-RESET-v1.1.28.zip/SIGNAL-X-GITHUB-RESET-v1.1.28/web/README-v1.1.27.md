SIGNAL X v1.1.27 — Five Equal Navigation Tabs. Serve this folder over HTTPS or localhost for PWA features. Open index.html for the standalone app shell. See SIGNAL-X-Release-Notes-v1.1.27.md.
