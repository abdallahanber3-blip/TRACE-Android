SIGNAL X Web / PWA v1.1.17 — Field UI Reorganization. Open index.html. See RELEASE-NOTES-v1.1.17.md.
