# SIGNAL X Web / PWA — v1.1.15

Serve this folder over HTTP/HTTPS or open it in the Android WebView wrapper. The current design system is embedded in `index.html`. The service-worker cache was bumped for this release.

See `RELEASE-NOTES-v1.1.15.md`.
