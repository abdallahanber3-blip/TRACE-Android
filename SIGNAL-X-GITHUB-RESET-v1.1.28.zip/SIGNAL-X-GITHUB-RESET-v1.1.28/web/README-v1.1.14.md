# SIGNAL X Web / PWA — v1.1.14

Serve this folder over HTTP/HTTPS (or use the included Android project). Open `index.html` for the app. For service-worker cache updates, install/reload the new shell.

See `RELEASE-NOTES-v1.1.14.md`.
