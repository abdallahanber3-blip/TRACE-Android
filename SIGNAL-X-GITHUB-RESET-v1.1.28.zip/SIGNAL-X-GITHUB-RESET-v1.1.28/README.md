# SIGNAL X — Android + Web source

Version: **1.1.28**  
Android package: **`com.signalx.drivetest.debug`**  
Android `versionCode`: **28**

## Project layout

- `android/` — native Android WebView wrapper, Gradle project, icons, app assets, Java source, and signing instructions.
- `web/` — canonical web/PWA source, manifest, service worker, styles, and icons.
- `.github/workflows/build-apk.yml` — builds and verifies the signed Android APK.

The `web/index.html` file is the canonical UI. Every Android build copies it into `android/app/src/main/assets/www/index.html` before Gradle builds the APK, so the Android and web versions do not drift.

## Build an update APK

1. Configure the four repository Actions secrets described in [`android/SIGNING-KEY-SETUP.md`](android/SIGNING-KEY-SETUP.md).
2. Open **Actions → Build update-compatible SIGNAL X APK → Run workflow**.
3. Download the artifact named `SIGNAL-X-update-ready-APK-v1.1.28`.

The workflow deliberately stops if any signing secret is missing. It will not fall back to a temporary GitHub runner debug key.

## Update and data rules

- Keep the same application ID and signing keystore for every future build.
- Increase `versionCode` for every release.
- Do not delete WebView storage, IndexedDB databases, or local app files during app startup.
- A normal in-place Android update preserves app-private data. Uninstalling the app or clearing its storage does not.
- Keep the `.jks` file and passwords private and backed up. Never commit signing material to this repository.
