PRIVATE SIGNAL X SIGNING KIT — KEEP THIS OUT OF THE PUBLIC GITHUB REPOSITORY

This kit contains the one persistent Android app-signing key and the values needed by the repository's GitHub Actions workflow.

1. Open the GitHub repository in a browser and go to Settings > Secrets and variables > Actions.
2. Create one repository secret for each file in GITHUB_SECRETS. The file name (without .txt) is the exact secret name; the file contents are its value.
3. Save the kit in a secure private backup. Never upload this ZIP, the .jks file, or the secret values to the public repository.
4. Once the four secrets are added, run the GitHub Actions workflow named “Build update-compatible SIGNAL X APK”.

The key alias in this kit is signalx-upload. Use this exact keystore for every future version. Do not create a replacement key. If this key is lost, future APKs cannot update the app installation signed with it.

The current old installation may have been signed by a temporary GitHub runner key. The first change to this persistent key may require a one-time reinstall. After the persistent key is in use, future in-place updates retain app-private data as long as the package ID is unchanged.
