# SIGNAL X — PWA build for GitHub Pages

This package wraps the approved SIGNAL X V68 maintenance HTML as an installable, mobile-first Progressive Web App. The original HTML is preserved unchanged in `reference/`.

## Included

- `index.html` — approved V68 app plus app-shell polish (startup screen, translucent bottom navigation, subtle tap tick, PWA registration).
- `manifest.webmanifest` — app name, standalone display, theme colors, icons.
- `sw.js` — small app-shell service worker. External map tiles, Leaflet/CDN libraries, GPS and data services are intentionally not cached/intercepted.
- `icons/` — SIGNAL X app icons.
- `reference/` — untouched approved V68 source for rollback.

## Publish on GitHub Pages

1. Create or open the repository where you want to host SIGNAL X.
2. Upload the contents of this package to the repository root (so `index.html` and `manifest.webmanifest` are at the root of the Pages source folder).
3. In GitHub, open **Settings → Pages** and select the desired branch and `/ (root)` folder.
4. Wait for the Pages deployment to finish, then open the HTTPS Pages URL on Android Chrome.
5. Use Chrome's **Install app** / **Add to Home screen** option to install SIGNAL X.

GitHub Pages must serve the app over HTTPS for service-worker/PWA installation. If you publish under a repository path, all local links are relative and the package is designed for that path.

## Notes

- Existing map, site database, GPS and drive-test logic was retained from the approved V68 HTML.
- Tap ticks are synthesized with Web Audio; no extra sound file is required. Browsers only permit playback after a user gesture.
- The splash screen is a brief in-app brand screen; Android may also use the manifest icon/theme when launching the installed app.
- The service worker caches only the local shell and does not promise offline maps or offline GPS. Map tile/CDN requests remain network-dependent.
- No Excel/site database is embedded or added to GitHub beyond what was already part of the approved HTML.
