# SIGNAL X Android Project — Mobile ZIP Upload

This archive is designed for the existing `Build TRACE APK` GitHub Actions workflow in `abdallahanber3-blip/TRACE-Android`, which extracts a ZIP from the repository root.

## Phone upload method (keep the ZIP intact)

1. In the GitHub repository, remove the older Android project ZIP from the repository root first.
2. Upload this archive to the repository root with the exact filename `SIGNAL-X-Android-Gradle-Project.zip`.
3. Make sure this is the **only `.zip` file in the repository root**. The current workflow chooses the first root-level ZIP it finds, so older ZIPs can make it build the wrong archive.
4. Wait for the `Build TRACE APK` workflow to run. This archive deliberately includes `app/build.gradle` (Groovy DSL), because the existing workflow checks that exact path and tries to add AndroidX Core there.
5. If the workflow succeeds, open **Actions → Build TRACE APK → Artifacts** and download `SIGNAL-X-debug-APK` (or the artifact name shown by the workflow).

## What is inside

- `settings.gradle.kts` and root `build.gradle.kts`
- `app/build.gradle` (Groovy DSL compatible with the current workflow)
- Android WebView application with GPS permission flow
- GeoJSON file picker and Save As support
- Approved SIGNAL X V68 HTML assets under `app/src/main/assets/www/`
- Reference copy of the approved HTML
- A standalone, improved workflow for future direct-project builds under `.github/workflows/build-apk.yml`

## Important

Uploading this ZIP as one file does not automatically put the workflow contained inside the ZIP into `.github/workflows` in GitHub. The already-existing workflow in the repository is what runs and extracts this ZIP. This is why the ZIP was made compatible with that workflow.

The build runner must have JDK 17, Android SDK platform 35, Build Tools 35.0.0, and Gradle 8.9 or compatible. A debug APK is for testing and installation; a release APK should be signed with a release keystore.

## Excel upload fix

The Android WebView file chooser intentionally opens all file types instead of restricting by MIME type. Some Android file providers report `.xlsx`/`.xls` as spreadsheet MIME types, ZIP, or `application/octet-stream`; the older whitelist omitted Excel MIME types and prevented valid workbooks from appearing. The HTML file inputs still specify the expected Excel extensions, and the workbook reader validates the selected content.


## Mobile layout polish (2026-10)
- Android WebView respects system bars plus display cutouts and adds an 8dp top breathing gap.
- WebView background follows Light/Dark so the system safe-area gap stays visually consistent.
- Home Site Location was rebuilt as a themed card with clear hierarchy, responsive coordinates, and balanced Copy/Directions actions.
