# SIGNAL X — Industrial Pro visual refresh

This version is based on the approved V68 stable baseline. It is a visual-only redesign.

## Visual changes
- Matte charcoal / restrained lime-and-green palette with matching light theme.
- Unified typography, cards, borders, spacing, radii, inputs, chips, and action buttons.
- Cleaner SIGNAL X header and more compact NR/LTE data source cards.
- Refined search filters and selected-site location card.
- Map-first screen with quieter tool buttons, calmer panels, and reduced excess glow.
- Unified Site Intelligence and Settings appearance.
- Simplified translucent bottom navigation with clearer active state.
- Reduced motion and responsive spacing for small phones.

## Scope / safety
No new drive-test features were added. Existing map layers and tile filters, site and PCI rendering, search logic, workbook parsing, GPS behavior, GeoJSON handling, Android bridge, splash flow, and app navigation logic were preserved. The original approved HTML reference remains unchanged under `reference/`.

The Android project has not been built into an APK or device-tested as part of this visual refresh.


## Glass-Motion visual refinement
- Unified previously mismatched Quick Fly / site chooser / map layer / network data center / All Sites menus to the lime-glass material.
- Added translucent light and dark theme treatments with readable contrast.
- Added restrained entrance and touch-feedback motion; respects `prefers-reduced-motion`.
- Visual-only update: app handlers, site parsing, map tile URLs, layers and Android bridge retained.
