# SIGNAL X 1.1.3 — Android keyboard and search layout fix

- Added native IME visibility tracking with `WindowInsetsCompat.Type.ime()`.
- The WebView receives an `sx-ime-open` class update when the Android keyboard opens/closes.
- The fixed bottom navigation is hidden while the keyboard is visible and restored after it closes.
- Suggested Sites is positioned in normal document flow below the search/filter row, rather than as an absolutely-positioned overlay.
- Suggestions are height-limited and internally scrollable on small screens.
- Search, filter, result selection, and site-data logic were not changed.

Validation in this workspace: source structure and JavaScript syntax are checked; a device/Gradle APK build is not available in this environment.
