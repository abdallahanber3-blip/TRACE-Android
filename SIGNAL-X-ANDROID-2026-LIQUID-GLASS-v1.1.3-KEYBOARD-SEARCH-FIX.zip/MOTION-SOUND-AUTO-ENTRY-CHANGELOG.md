# Motion & Sound Auto-Entry Update — 2026

- Changed the launch intro from tap-to-enter to an automatic entry after ~1.8 seconds.
- Kept an optional Skip Intro action for immediate entry.
- Added a lightweight progress sweep and accessible status text.
- Respects `prefers-reduced-motion` with a shorter timing path.
- Preserved `enter()`'s map invalidate/resize step after the overlay is removed.
- Updated Android launcher icons, PWA icons/manifests and native deep-graphite safe-area colors.
- Did not rewrite map/GPS/drive-test controller logic in this change.

## Field fixes (2026-10-19)
- Site Information sector scatter/cards redesigned as compact rows with a clear number badge and smaller engineering-value cells; original data grouping and copy actions retained.
- Intro auto-enter shortened to ~720 ms, with CSS-only failsafe hide at 1.6 s; page controls remain pass-through while the non-blocking intro is visible.
- Replaced container-scoped sound events with capture-phase delegated sounds for buttons, links, map controls, toggles, file selection and other interactive controls.
- Raised synthesized sound envelope levels with a master boost and dynamics compressor; added Settings → Test Sound. Sounds remain user-muteable and are unlocked on the first genuine user gesture.

- Android app metadata bumped to versionName `1.1.1` / versionCode `3` so the debug build can update a previously installed `1.1.0-debug` build.


## Version 1.1.2 follow-up
- Canonical CAI/NCAI de-duplication now cleans both active queue state and restored session state, and map rendering starts from the cleaned site list.
- Added Developed by Eng. Abdallah Ali · 2026 attribution to splash, page brand and Settings/footer.
- Increased launch intro display to about 2.4 seconds with a 12-second CSS failsafe.
- Added restrained Liquid Glass surfaces and touch feedback.
- Raised synthesized UI sound output; a persistent 50–160% volume slider defaults to 120%, with a Test Sound button.
