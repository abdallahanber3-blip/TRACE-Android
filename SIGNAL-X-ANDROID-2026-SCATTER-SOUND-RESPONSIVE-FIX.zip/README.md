# SIGNAL X Android — 2026 Motion, Sound & Field Fix Edition

A complete Android Studio / Gradle WebView project for SIGNAL X 2026. It contains the current Motion & Sound app HTML, the new cyan/blue/violet X launcher icon, Android GPS permission handling, the Excel/GeoJSON file picker path, GeoJSON Save As support, app-to-Google-Maps handoff, and a GitHub Actions workflow that builds a debug APK.

## Version 1.1.1 — what's changed in this package

- The app's launch intro now opens automatically after about **0.72 seconds**, with a CSS-only hide failsafe at 1.6 seconds and pass-through behavior so it cannot trap app interaction. `Skip intro` is optional; no tap is required to enter the workspace. Reduced-motion devices use a shorter intro.
- Added a short progress sweep on the launch screen plus an auto-hide failsafe, and retained synthesized UI feedback with stronger output and broader control coverage.
- Reworked Site Information sector cards into compact rows: sector number badge plus compact PCI/Azimuth (or Azimuth/Band) metrics, eliminating oversized per-sector radar diagrams.
- Updated web icons and Android launcher icons to the new SIGNAL X 2026 mark.
- Matched the native Android launch/safe-area color to the new graphite/cyan palette.
- The accepted V68-derived app functionality and map control handlers are carried in `app/src/main/assets/www/index.html`; the untouched baseline reference remains in `reference/`.
- Sounds are synthesized in the page (no separate audio files), with a louder compressed master mix, first-gesture audio unlock, global event delegation for app/map controls, and a Test Sound button in Settings. Android device media volume still controls the final loudness.

## Option A — use the existing ZIP-extracting GitHub workflow

If your current repository has a pre-existing workflow that watches for the root file named `SIGNAL-X-Android-Gradle-Project.zip` and extracts it before building:

1. Upload this archive to the repository root using that exact filename: `SIGNAL-X-Android-Gradle-Project.zip`.
2. Remove older root-level project ZIPs so the old workflow cannot select the wrong version.
3. Let the existing workflow run, then open **Actions** and download the APK artifact from the successful run.

Important: the workflow inside this archive is not activated just by uploading the archive as one file; the repository's pre-existing workflow is what extracts and builds it.

## Option B — make this the actual repository source

For a normal standalone GitHub project (recommended for a new repo):

1. Extract this archive locally.
2. Upload the **contents** of the extracted folder to the repository root, preserving `.github/`, `app/`, `reference/`, `build.gradle.kts`, `settings.gradle.kts`, and `gradle.properties`.
3. Set the default branch to `main` or `master`, then open **Actions → Build SIGNAL X APK**. It runs on push or can be started with **Run workflow**.
4. Download the `SIGNAL-X-debug-APK` artifact.

Do not upload the ZIP alone for Option B; GitHub Actions only discovers workflow files that exist in the repository under `.github/workflows/`.

## Local build

Requirements: JDK 17, Android SDK platform 35, Build Tools 35.0.0, Gradle 8.9 or compatible.

From the repository root:

```bash
gradle --no-daemon clean assembleDebug
```

Output: `app/build/outputs/apk/debug/app-debug.apk`.

The provided APK workflow creates a **debug APK** for device testing. A Play Store/release build needs a release signing key and release configuration.

## Functional notes / honest test status

- GPS requires the user to grant Android location permission. If permission is denied, location-dependent features cannot locate the device.
- Map tiles, CDN libraries and external network data still require a working internet connection.
- The launcher auto-entry change was checked in source and the launch timer logic was reviewed; this environment cannot install and test the APK on a physical Android device. Verify GPS, Excel file selection, map tiles, Drive Test start/stop and sounds on the target phone after the GitHub build.
- To return to the previous stable UI, use `reference/SIGNAL-X-V68-APPROVED-REVIEWED-CLEANUP.html` as the rollback source.
