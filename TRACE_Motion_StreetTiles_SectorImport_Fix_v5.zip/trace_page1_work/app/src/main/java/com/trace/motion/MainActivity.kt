package com.trace.motion

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.unit.IntSize
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import android.util.Xml
import org.xmlpull.v1.XmlPullParser
import java.io.ByteArrayInputStream
import java.util.zip.ZipInputStream
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.*
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.XYTileSource
import org.osmdroid.tileprovider.tilesource.OnlineTileSourceBase
import org.osmdroid.util.MapTileIndex
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.Polygon

private val Bg = Color(0xFF07100C)
private val Panel = Color(0xFF111C15)
private val Panel2 = Color(0xFF24372A)
private val Ice = Color(0xFFB7D1B0)
private val Cyan = Color(0xFF70F0B2)
private val IceWhite = Color(0xFFE3EDE1)
private val Muted = Color(0xFF9AAA9B)
private val Purple = Color(0xFF9DBB91)
private data class Site(val name:String, val lat:Double?, val lon:Double?, val city:String="", val pci:String="", val tech:String="", val bands:String="", val sector:String="", val source:String="", val azimuth:Double?=null)
private data class ParsedResult(val records:List<Site>, val message:String)

class MainActivity : ComponentActivity() {
    private val sites4g = mutableStateListOf<Site>()
    private val sites5g = mutableStateListOf<Site>()
    private val routePoints = mutableStateListOf<Location>()
    private var activePage by mutableStateOf("Search")
    private var selectedSite by mutableStateOf<Site?>(null)
    private val mapSites = mutableStateListOf<Site>()
    private var selectedMapSite by mutableStateOf<Site?>(null)
    private var mapCanvasSize by mutableStateOf(IntSize.Zero)
    private var cachedAllSites by mutableStateOf<List<Site>>(emptyList())
    private var query by mutableStateOf("")
    private var filterTech by mutableStateOf("All")
    private var status by mutableStateOf("Import your 4G and 5G Excel files to begin.")
    private var mapStyle by mutableStateOf("Dark Street")
    private var language by mutableStateOf("English")
    private var showSectors by mutableStateOf(true)
    private var showPci by mutableStateOf(true)
    private var showSites by mutableStateOf(true)
    private var tracking by mutableStateOf(false)
    private var currentLocation by mutableStateOf<Location?>(null)
    private lateinit var locationManager: LocationManager
    private var locationListener: LocationListener? = null
    private val prefs by lazy { getSharedPreferences("trace_motion", Context.MODE_PRIVATE) }
    private val allSites: List<Site> get() = cachedAllSites

    private fun refreshAllSites() {
        // Merge only when a database changes, never on every keystroke or recomposition.
        cachedAllSites = mergeSiteLists(sites4g.toList(), sites5g.toList())
    }

    private fun mergeSiteLists(fourG: List<Site>, fiveG: List<Site>): List<Site> =
        (fiveG + fourG).groupBy { siteKey(it.name) }.values.map { group ->
            // TRACE website rule: when NR exists for a physical site, prefer its radio identity
            // rather than mixing 4G PCI/bands into the same displayed site. Keep the original
            // 4G and 5G databases separately available in Search/Settings.
            val nr = group.filter { it.source.equals("5G", true) || it.tech.contains("NR", true) || it.tech.contains("5G", true) }
            val chosen = if (nr.isNotEmpty()) nr else group
            val first = chosen.first()
            first.copy(
                tech = chosen.map { it.tech }.filter { it.isNotBlank() }.distinct().joinToString(" + ").ifBlank { first.source },
                pci = chosen.map { it.pci }.filter { it.isNotBlank() }.distinct().joinToString(" / "),
                bands = chosen.map { it.bands }.filter { it.isNotBlank() }.distinct().joinToString(" / "),
                source = chosen.map { it.source }.filter { it.isNotBlank() }.distinct().joinToString(" + "),
                city = chosen.firstOrNull { it.city.isNotBlank() }?.city ?: group.firstOrNull { it.city.isNotBlank() }?.city.orEmpty(),
                lat = chosen.firstOrNull { it.lat != null }?.lat ?: group.firstOrNull { it.lat != null }?.lat,
                lon = chosen.firstOrNull { it.lon != null }?.lon ?: group.firstOrNull { it.lon != null }?.lon
            )
        }

    private val choose4g = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if(uri!=null) importExcel(uri,"4G") }
    private val choose5g = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if(uri!=null) importExcel(uri,"5G") }
    private val saveGeoJson = registerForActivityResult(ActivityResultContracts.CreateDocument("application/geo+json")) { uri -> if(uri!=null) exportRoute(uri) }
    private val askLocation = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { grants -> if(grants.values.any{it}) startGps() else status="Location permission denied." }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        locationManager = getSystemService(LOCATION_SERVICE) as LocationManager
        restoreData()
        setContent {
            MaterialTheme(colorScheme=darkColorScheme(primary=Ice, secondary=Cyan, background=Bg, surface=Panel, onPrimary=Bg, onBackground=IceWhite, onSurface=IceWhite)) { TraceRoot() }
        }
    }

    @Composable private fun TraceRoot() {
        Scaffold(containerColor=Bg, topBar={ Header() }, bottomBar={ BottomNav() }) { insets ->
            Column(Modifier.fillMaxSize().padding(insets).padding(horizontal=14.dp)) {
                Spacer(Modifier.height(8.dp))
                when {
                    selectedSite != null -> SiteInformation(selectedSite!!)
                    activePage=="Search" -> SearchPage()
                    activePage=="Map" -> MapPage()
                    activePage=="Analytics" -> AnalyticsPage()
                    else -> SettingsPage()
                }
            }
        }
    }

    @Composable private fun Header() {
        val pulse by rememberInfiniteTransition(label="logoPulse").animateFloat(initialValue=.55f,targetValue=1f,animationSpec=infiniteRepeatable(tween(1500,easing=FastOutSlowInEasing),RepeatMode.Reverse),label="pulse")
        Row(Modifier.fillMaxWidth().background(Bg).padding(horizontal=16.dp, vertical=11.dp), verticalAlignment=Alignment.CenterVertically) {
            Box(Modifier.size(46.dp).clip(RoundedCornerShape(15.dp)).background(Panel).border(1.dp,Ice.copy(alpha=pulse),RoundedCornerShape(15.dp)),contentAlignment=Alignment.Center) {
                Icon(Icons.Default.DirectionsCar,null,tint=Ice,modifier=Modifier.size(25.dp))
                Icon(Icons.Default.WifiTethering,null,tint=Cyan.copy(alpha=.9f),modifier=Modifier.size(13.dp).align(Alignment.TopEnd).padding(1.dp))
            }
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text("TRACE",fontSize=24.sp,fontWeight=FontWeight.Black,color=IceWhite,letterSpacing=2.sp)
                Text("MOTION  •  5G DRIVE TEST INTELLIGENCE",fontSize=8.sp,color=Ice,letterSpacing=1.sp)
            }
            Column(horizontalAlignment=Alignment.End) {
                Row(verticalAlignment=Alignment.CenterVertically) { Box(Modifier.size(6.dp).clip(CircleShape).background(if(tracking) Cyan else Muted)); Spacer(Modifier.width(5.dp)); Text(if(tracking) "TRACKING" else "READY",fontSize=9.sp,color=if(tracking) Cyan else Muted,fontWeight=FontWeight.Bold) }
                Text("${allSites.size} sites",fontSize=10.sp,color=Muted)
            }
        }
        HorizontalDivider(color=Ice.copy(.16f))
    }

    @Composable private fun BottomNav() {
        NavigationBar(containerColor=Panel,contentColor=IceWhite) {
            listOf("Search","Map","Analytics","Settings").forEach { page ->
                NavigationBarItem(selected=activePage==page && selectedSite==null,onClick={selectedSite=null;activePage=page},icon={Icon(when(page){"Search"->Icons.Default.Search;"Map"->Icons.Default.Map;"Analytics"->Icons.Default.QueryStats;else->Icons.Default.Settings},null)},label={Text(page,fontSize=10.sp)},colors=NavigationBarItemDefaults.colors(selectedIconColor=Ice,selectedTextColor=Ice,indicatorColor=Panel2,unselectedIconColor=Muted,unselectedTextColor=Muted))
            }
        }
    }

    @Composable private fun SearchPage() {
        var visibleResults by remember { mutableStateOf<List<Site>>(emptyList()) }
        var totalMatches by remember { mutableIntStateOf(0) }
        val databaseSnapshot = allSites
        LaunchedEffect(query, filterTech, databaseSnapshot) {
            delay(180)
            val result = withContext(Dispatchers.Default) { filterSites(query, filterTech, databaseSnapshot) }
            totalMatches = result.size
            visibleResults = result.take(100)
        }
        Column(Modifier.fillMaxSize()) {
            Text("SITE DATABASE",color=Muted,fontSize=10.sp,letterSpacing=2.sp)
            Spacer(Modifier.height(7.dp))
            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                ExcelTile("4G DATABASE",sites4g.size,Modifier.weight(1f),{choose4g.launch(excelMimeTypes())},if(sites4g.isEmpty()) "Import 4G Excel" else "Replace 4G Excel")
                ExcelTile("5G DATABASE",sites5g.size,Modifier.weight(1f),{choose5g.launch(excelMimeTypes())},if(sites5g.isEmpty()) "Import 5G Excel" else "Replace 5G Excel")
            }
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(
                value=query,
                onValueChange={query=it},
                modifier=Modifier.fillMaxWidth(),
                singleLine=true,
                placeholder={Text("Search site, CAI / NCAI, city, PCI, band…",color=Muted,fontSize=12.sp)},
                leadingIcon={Icon(Icons.Default.Search,null,tint=Ice)},
                trailingIcon={if(query.isNotBlank()) IconButton(onClick={query=""}){Icon(Icons.Default.Close,null,tint=Muted)} else Icon(Icons.Default.FilterAlt,null,tint=Ice)},
                shape=RoundedCornerShape(15.dp),
                colors=OutlinedTextFieldDefaults.colors(focusedBorderColor=Ice,unfocusedBorderColor=Ice.copy(.38f),focusedTextColor=IceWhite,unfocusedTextColor=IceWhite,cursorColor=Cyan)
            )
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement=Arrangement.spacedBy(7.dp),verticalAlignment=Alignment.CenterVertically) {
                listOf("All","4G","5G").forEach { tech ->
                    FilterChip(selected=filterTech==tech,onClick={filterTech=tech},label={Text(tech)},colors=FilterChipDefaults.filterChipColors(selectedContainerColor=Ice,selectedLabelColor=Bg,containerColor=Panel,labelColor=IceWhite))
                }
                Spacer(Modifier.weight(1f))
                Text("$totalMatches results",color=Muted,fontSize=11.sp)
            }
            Spacer(Modifier.height(7.dp))
            when {
                allSites.isEmpty() -> CardBox {
                    LogoMark(Modifier.align(Alignment.CenterHorizontally).size(66.dp))
                    Text("Import your site databases",fontSize=17.sp,fontWeight=FontWeight.Bold,color=IceWhite)
                    Text("4G and 5G stay in separate databases. Importing one updates only that technology; search combines both databases without deleting the other.",fontSize=12.sp,color=Muted)
                    ButtonTrace("Import 4G Excel",Modifier.fillMaxWidth()){choose4g.launch(excelMimeTypes())}
                    ButtonTrace("Import 5G Excel",Modifier.fillMaxWidth(),outlined=true){choose5g.launch(excelMimeTypes())}
                }
                visibleResults.isEmpty() -> CardBox {
                    Icon(Icons.Default.SearchOff,null,tint=Ice,modifier=Modifier.size(30.dp))
                    Text(if(query.isBlank()) "No sites match this filter" else "No matching sites",fontSize=16.sp,fontWeight=FontWeight.Bold,color=IceWhite)
                    Text("Try another site name, CAI/NCAI, city, PCI or band, or switch the technology filter.",fontSize=12.sp,color=Muted)
                    ButtonTrace("Clear search and filters",Modifier.fillMaxWidth(),outlined=true){query="";filterTech="All"}
                }
                else -> LazyColumn(modifier=Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(8.dp),contentPadding=PaddingValues(bottom=12.dp)) {
                    items(visibleResults,key={it.name+it.source+it.lat.toString()+it.lon.toString()}) { site -> SiteRow(site,{selectedSite=site}) {
                        if (mapSites.none { siteKey(it.name)==siteKey(site.name) }) mapSites.add(site)
                        selectedMapSite=site
                        selectedSite=null
                        activePage="Map"
                    } }
                    if (totalMatches > visibleResults.size) item { Text("Showing first ${visibleResults.size} of $totalMatches results. Refine your search to narrow the list.",color=Muted,fontSize=10.sp) }
                }
            }
            if(status.isNotBlank()) {
                Spacer(Modifier.height(4.dp))
                Text(status,color=Muted,fontSize=9.sp,maxLines=2)
            }
        }
    }

    @Composable private fun ExcelTile(title:String,count:Int,modifier:Modifier,onClick:()->Unit,buttonLabel:String) {
        Column(modifier.clip(RoundedCornerShape(17.dp)).background(Panel).border(1.dp,Ice.copy(.25f),RoundedCornerShape(17.dp)).padding(11.dp),verticalArrangement=Arrangement.spacedBy(7.dp)) {
            Row(verticalAlignment=Alignment.CenterVertically) { Icon(Icons.Default.TableView,null,tint=Ice,modifier=Modifier.size(20.dp)); Spacer(Modifier.width(6.dp)); Text(title,fontSize=10.sp,color=IceWhite,fontWeight=FontWeight.Bold) }
            Text("$count sites loaded",fontSize=11.sp,color=Muted)
            ButtonTrace(buttonLabel,Modifier.fillMaxWidth()){onClick()}
        }
    }

    @Composable private fun SiteRow(site:Site,onClick:()->Unit,onAddToMap:()->Unit) {
        Column(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Panel)
                .border(1.dp,Ice.copy(.22f),RoundedCornerShape(16.dp)).clickable{onClick()}.padding(12.dp),
            verticalArrangement=Arrangement.spacedBy(6.dp)
        ) {
            Row(verticalAlignment=Alignment.CenterVertically) {
                Box(Modifier.size(38.dp).clip(RoundedCornerShape(11.dp)).background(Panel2),contentAlignment=Alignment.Center) {
                    Icon(Icons.Default.CellTower,null,tint=Ice)
                }
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(2.dp)) {
                    Text(site.name,fontWeight=FontWeight.Bold,color=IceWhite,fontSize=14.sp,maxLines=1)
                    Text(site.city.ifBlank { "City not available" },fontSize=11.sp,color=Muted,maxLines=1)
                }
                Surface(color=Ice.copy(.14f),shape=RoundedCornerShape(8.dp)) {
                    Text(site.tech.ifBlank { site.source.ifBlank { "Network" } },modifier=Modifier.padding(horizontal=8.dp,vertical=5.dp),fontSize=10.sp,color=Ice,fontWeight=FontWeight.Bold,maxLines=1)
                }
                Spacer(Modifier.width(4.dp))
                Icon(Icons.Default.ChevronRight,null,tint=Ice)
            }
            HorizontalDivider(color=Ice.copy(.12f))
            Row(verticalAlignment=Alignment.Top,horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Default.SettingsInputAntenna,null,tint=Cyan,modifier=Modifier.size(15.dp))
                Column(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(2.dp)) {
                    Text("BANDS",fontSize=8.sp,color=Muted,fontWeight=FontWeight.Bold,letterSpacing=1.sp)
                    Text(site.bands.ifBlank { "Not available in Excel" },fontSize=11.sp,color=IceWhite,maxLines=2)
                }
                Column(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(2.dp)) {
                    Text("PCI",fontSize=8.sp,color=Muted,fontWeight=FontWeight.Bold,letterSpacing=1.sp)
                    Text(site.pci.ifBlank { "Not available in Excel" },fontSize=11.sp,color=IceWhite,maxLines=2)
                }
            }
            if(site.lat!=null && site.lon!=null) {
                Row(verticalAlignment=Alignment.CenterVertically) {
                    Icon(Icons.Default.LocationOn,null,tint=Ice,modifier=Modifier.size(13.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("${fmt(site.lat)}, ${fmt(site.lon)}",fontSize=9.sp,color=Muted)
                }
            }
            ButtonTrace(if(mapSites.any { siteKey(it.name)==siteKey(site.name) }) "Added to Map" else "Add to Map", Modifier.fillMaxWidth(), outlined=mapSites.any { siteKey(it.name)==siteKey(site.name) }) { onAddToMap() }
        }
    }

    @Composable private fun MapPage() {
        val context = this@MainActivity
        val mapView = remember {
            Configuration.getInstance().userAgentValue = "TRACE-Motion-Android/1.0 (com.trace.motion)"
            Configuration.getInstance().load(context, context.getSharedPreferences("osmdroid", Context.MODE_PRIVATE))
            Configuration.getInstance().tileFileSystemCacheMaxBytes = 128L * 1024L * 1024L
            Configuration.getInstance().tileFileSystemCacheTrimBytes = 96L * 1024L * 1024L
            MapView(context).apply {
                setMultiTouchControls(true)
                setTileSource(object : OnlineTileSourceBase("TRACE Dark Street", 0, 19, 256, ".png", arrayOf("https://a.basemaps.cartocdn.com/dark_all/", "https://b.basemaps.cartocdn.com/dark_all/", "https://c.basemaps.cartocdn.com/dark_all/")) {
                    override fun getTileURLString(tileIndex: Long): String = baseUrl + MapTileIndex.getZoom(tileIndex) + "/" + MapTileIndex.getX(tileIndex) + "/" + MapTileIndex.getY(tileIndex) + ".png"
                })
                controller.setZoom(6.0)
                controller.setCenter(GeoPoint(26.8206, 30.8025)) // Egypt overview until a site is selected.
            }
        }
        var lastCenteredSite by remember { mutableStateOf("") }
        var gpsRequested by remember { mutableStateOf(false) }
        var lastTileStyle by remember { mutableStateOf("") }
        DisposableEffect(mapView) {
            onDispose { mapView.onDetach() }
        }
        LaunchedEffect(selectedMapSite?.name, selectedMapSite?.lat, selectedMapSite?.lon) {
            val site = selectedMapSite
            if (site?.lat != null && site.lon != null && site.lat.isFinite() && site.lon.isFinite() && site.lat in -90.0..90.0 && site.lon in -180.0..180.0) {
                delay(250)
                mapView.controller.setCenter(GeoPoint(site.lat, site.lon))
                mapView.controller.setZoom(15.0)
                lastCenteredSite = siteKey(site.name)
                mapView.invalidate()
            }
        }
        LaunchedEffect(currentLocation, gpsRequested) {
            val loc = currentLocation
            if (gpsRequested && loc != null) {
                mapView.controller.animateTo(GeoPoint(loc.latitude, loc.longitude))
                mapView.controller.setZoom(16.0)
                gpsRequested = false
                mapView.invalidate()
            }
        }
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment=Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("FIELD MAP",fontSize=22.sp,fontWeight=FontWeight.Bold,color=IceWhite)
                    Text("Dark Street • ${mapSites.size} manually added sites",color=Muted,fontSize=11.sp)
                }
                IconButton(onClick={gpsRequested=true; requestGps(); currentLocation?.let { mapView.controller.animateTo(GeoPoint(it.latitude,it.longitude)); mapView.controller.setZoom(16.0); gpsRequested=false }}) { Icon(Icons.Default.MyLocation,null,tint=Ice) }
            }
            Box(Modifier.fillMaxWidth().weight(1f, fill=false).heightIn(min=380.dp, max=620.dp).clip(RoundedCornerShape(22.dp)).background(Color(0xFF081622)).border(1.dp,Ice.copy(.25f),RoundedCornerShape(22.dp))) {
                AndroidView(
                    factory = { mapView },
                    modifier = Modifier.fillMaxSize(),
                    update = { map ->
                        val desiredStyle = when (mapStyle) { "Light Street" -> "Light Street"; "Satellite" -> "Satellite"; else -> "Dark Street" }
                        if (lastTileStyle != desiredStyle) {
                            val tileSource = when (desiredStyle) {
                                "Light Street" -> object : OnlineTileSourceBase("TRACE Light Street",0,19,256,".png",arrayOf("https://a.tile.openstreetmap.org/", "https://b.tile.openstreetmap.org/", "https://c.tile.openstreetmap.org/")) {
                                    override fun getTileURLString(tileIndex: Long): String = baseUrl + MapTileIndex.getZoom(tileIndex) + "/" + MapTileIndex.getX(tileIndex) + "/" + MapTileIndex.getY(tileIndex) + ".png"
                                }
                                "Satellite" -> object : OnlineTileSourceBase("TRACE Satellite",0,19,256,".jpg",arrayOf("https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/")) {
                                    override fun getTileURLString(tileIndex: Long): String = baseUrl + MapTileIndex.getZoom(tileIndex) + "/" + MapTileIndex.getY(tileIndex) + "/" + MapTileIndex.getX(tileIndex)
                                }
                                else -> object : OnlineTileSourceBase("TRACE Dark Street",0,19,256,".png",arrayOf("https://a.basemaps.cartocdn.com/dark_all/", "https://b.basemaps.cartocdn.com/dark_all/", "https://c.basemaps.cartocdn.com/dark_all/")) {
                                    override fun getTileURLString(tileIndex: Long): String = baseUrl + MapTileIndex.getZoom(tileIndex) + "/" + MapTileIndex.getX(tileIndex) + "/" + MapTileIndex.getY(tileIndex) + ".png"
                                }
                            }
                            map.setTileSource(tileSource)
                            lastTileStyle = desiredStyle
                        }
                        map.overlays.removeAll { it is Marker || it is Polygon }
                        mapSites.forEach { site ->
                            if (site.lat != null && site.lon != null && site.lat in -90.0..90.0 && site.lon in -180.0..180.0) {
                                // Web parity: sector wedges use real geographic bearings, 110 m radius and +/-32 degrees.
                                val isSelected = selectedMapSite?.let { siteKey(it.name) == siteKey(site.name) } == true
                                if (showSectors && isSelected && site.azimuth != null) {
                                    val bearings = listOf(-32.0, -24.0, -16.0, -8.0, 0.0, 8.0, 16.0, 24.0, 32.0)
                                    val points = mutableListOf<GeoPoint>()
                                    points.add(GeoPoint(site.lat, site.lon))
                                    bearings.forEach { delta ->
                                        val bearing = Math.toRadians((site.azimuth!! + delta + 360.0) % 360.0)
                                        val distance = 110.0
                                        val lat1 = Math.toRadians(site.lat)
                                        val lon1 = Math.toRadians(site.lon)
                                        val angular = distance / 6371000.0
                                        val lat2 = asin(sin(lat1) * cos(angular) + cos(lat1) * sin(angular) * cos(bearing))
                                        val lon2 = lon1 + atan2(sin(bearing) * sin(angular) * cos(lat1), cos(angular) - sin(lat1) * sin(lat2))
                                        points.add(GeoPoint(Math.toDegrees(lat2), Math.toDegrees(lon2)))
                                    }
                                    points.add(GeoPoint(site.lat, site.lon))
                                    val wedge = Polygon(map).apply {
                                        setPoints(points)
                                        fillPaint.color = android.graphics.Color.argb(68, 155, 190, 143)
                                        outlinePaint.color = android.graphics.Color.rgb(183, 209, 176)
                                        outlinePaint.strokeWidth = 4f
                                        title = "${site.sector.ifBlank { "Sector" }} • PCI ${site.pci.ifBlank { "—" }}"
                                    }
                                    map.overlays.add(wedge)
                                }
                                val marker = Marker(map).apply {
                                    position = GeoPoint(site.lat, site.lon)
                                    title = site.name
                                    snippet = buildString {
                                        if (site.city.isNotBlank()) append(site.city)
                                        if (site.tech.isNotBlank()) { if (isNotEmpty()) append(" • "); append(site.tech) }
                                        if (site.pci.isNotBlank() && selectedMapSite?.let { siteKey(it.name) == siteKey(site.name) } == true) { if (isNotEmpty()) append(" • "); append("PCI ${site.pci}") }
                                    }
                                    setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
                                    icon = android.graphics.drawable.GradientDrawable().apply {
                                        shape = android.graphics.drawable.GradientDrawable.OVAL
                                        setColor(android.graphics.Color.rgb(183,209,176))
                                        setStroke(if (selectedMapSite?.let { siteKey(it.name)==siteKey(site.name) } == true) 5 else 2, android.graphics.Color.WHITE)
                                        setSize(30,30)
                                    }
                                    setOnMarkerClickListener { tapped, _ ->
                                        selectedMapSite = site
                                        tapped.showInfoWindow()
                                        map.controller.animateTo(tapped.position)
                                        map.invalidate()
                                        true
                                    }
                                }
                                map.overlays.add(marker)
                            }
                        }
                        currentLocation?.let { loc ->
                            if (loc.latitude.isFinite() && loc.longitude.isFinite() && loc.latitude in -90.0..90.0 && loc.longitude in -180.0..180.0) {
                                val userMarker = Marker(map).apply {
                                    position = GeoPoint(loc.latitude, loc.longitude)
                                    title = "My Location"
                                    snippet = "Accuracy: ${loc.accuracy.toInt()} m"
                                    setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
                                    icon = android.graphics.drawable.GradientDrawable().apply {
                                        shape = android.graphics.drawable.GradientDrawable.OVAL
                                        setColor(android.graphics.Color.rgb(0,229,255))
                                        setStroke(4, android.graphics.Color.WHITE)
                                        setSize(28,28)
                                    }
                                }
                                map.overlays.add(userMarker)
                            }
                        }
                        val selected = selectedMapSite
                        if (selected != null && selected.lat != null && selected.lon != null && selected.lat.isFinite() && selected.lon.isFinite() && selected.lat in -90.0..90.0 && selected.lon in -180.0..180.0 && lastCenteredSite != siteKey(selected.name)) {
                            map.controller.animateTo(GeoPoint(selected.lat, selected.lon))
                            map.controller.setZoom(max(map.zoomLevelDouble, 14.0))
                            lastCenteredSite = siteKey(selected.name)
                        }
                        map.invalidate()
                    }
                )
                Column(Modifier.align(Alignment.TopEnd).padding(9.dp),verticalArrangement=Arrangement.spacedBy(7.dp)) {
                    MapAction(Icons.Default.Layers,"Layers") {
                        mapStyle = when (mapStyle) { "Dark Street" -> "Satellite"; "Satellite" -> "Light Street"; else -> "Dark Street" }
                        prefs.edit().putString("mapStyle", mapStyle).apply()
                    }
                    MapAction(Icons.Default.MyLocation,"GPS") {
                        gpsRequested = true
                        requestGps()
                        currentLocation?.let { mapView.controller.animateTo(GeoPoint(it.latitude,it.longitude)); mapView.controller.setZoom(16.0); gpsRequested = false }
                    }
                    MapAction(Icons.Default.Search,"Search") { activePage="Search" }
                }
                Column(Modifier.align(Alignment.BottomStart).padding(10.dp),verticalArrangement=Arrangement.spacedBy(4.dp)) {
                    Text("TRACE • MOTION",color=Ice,fontSize=10.sp,fontWeight=FontWeight.Bold,modifier=Modifier.clip(RoundedCornerShape(8.dp)).background(Panel.copy(alpha=.94f)).padding(horizontal=8.dp, vertical=5.dp))
                    if (mapSites.isEmpty()) Text("No sites on map — add one from Search",color=IceWhite,fontSize=10.sp,modifier=Modifier.clip(RoundedCornerShape(8.dp)).background(Panel.copy(alpha=.94f)).padding(8.dp))
                }
            }
            CardBox {
                Row(verticalAlignment=Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("SELECTED SITES",color=Ice,fontWeight=FontWeight.Bold,fontSize=12.sp)
                        Text(if(mapSites.isEmpty()) "No sites added yet. Search and tap Add to Map." else mapSites.joinToString(" • ") { it.name },color=Muted,fontSize=11.sp,maxLines=2)
                    }
                    if (mapSites.isNotEmpty()) TextButton(onClick={mapSites.clear();selectedMapSite=null;lastCenteredSite="";mapView.controller.setZoom(6.0);mapView.controller.setCenter(GeoPoint(26.8206,30.8025))}) { Text("Clear",color=Ice) }
                }
                ButtonTrace("Open site search",Modifier.fillMaxWidth()){activePage="Search"}
            }
            selectedMapSite?.let { site ->
                CardBox {
                    Row(verticalAlignment=Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("SITE INFORMATION",color=Ice,fontSize=11.sp,fontWeight=FontWeight.Bold)
                            Text(site.name,color=IceWhite,fontSize=18.sp,fontWeight=FontWeight.Bold)
                            Text("${site.city.ifBlank { "City not available" }} • ${site.tech.ifBlank { site.source.ifBlank { "Network" } }}",color=Muted,fontSize=11.sp)
                        }
                        IconButton(onClick={selectedMapSite=null;mapView.invalidate()}) { Icon(Icons.Default.Close,"Close site information",tint=Muted) }
                    }
                    Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                        Column(Modifier.weight(1f)) { Text("BANDS",color=Muted,fontSize=9.sp);Text(site.bands.ifBlank { "Not available in database" },color=IceWhite,fontSize=12.sp) }
                        Column(Modifier.weight(1f)) { Text("PCI",color=Muted,fontSize=9.sp);Text(site.pci.ifBlank { "Not available in database" },color=IceWhite,fontSize=12.sp) }
                    }
                    Text("Latitude: ${site.lat?.let { String.format(Locale.US,"%.6f",it) } ?: "Not available"}   Longitude: ${site.lon?.let { String.format(Locale.US,"%.6f",it) } ?: "Not available"}",color=Muted,fontSize=10.sp)
                    Text("Sectors are shown only when valid sector/azimuth data exists in the imported database.",color=Muted,fontSize=10.sp)
                    ButtonTrace("Full Site Information",Modifier.fillMaxWidth()){selectedSite=site}
                }
            }
        }
    }

    @Composable private fun MapAction(icon:androidx.compose.ui.graphics.vector.ImageVector,label:String,onClick:()->Unit) {
        IconButton(onClick=onClick,modifier=Modifier.size(42.dp).clip(RoundedCornerShape(12.dp)).background(Panel).border(1.dp,Ice.copy(.3f),RoundedCornerShape(12.dp))){Icon(icon,label,tint=Ice)}
    }

    @Composable private fun SiteInformation(site:Site) {
        Row(verticalAlignment=Alignment.CenterVertically) { IconButton(onClick={selectedSite=null}){Icon(Icons.Default.ArrowBack,null,tint=Ice)}; Column(Modifier.weight(1f)){Text(site.name,fontSize=22.sp,fontWeight=FontWeight.Bold);Text("${site.city} • ${site.tech.ifBlank{"Network"}}",color=Muted,fontSize=11.sp)}; Icon(Icons.Default.LocationOn,null,tint=Ice) }
        LazyColumn(verticalArrangement=Arrangement.spacedBy(10.dp),contentPadding=PaddingValues(bottom=14.dp)) {
            item { CardBox { Text("SITE LOCATION",color=Ice,fontSize=11.sp,fontWeight=FontWeight.Bold); Text("Latitude",color=Muted,fontSize=10.sp);Text(site.lat?.let{String.format(Locale.US,"%.6f",it)}?:"Not found",color=IceWhite);Text("Longitude",color=Muted,fontSize=10.sp);Text(site.lon?.let{String.format(Locale.US,"%.6f",it)}?:"Not found",color=IceWhite);Text("City / Area",color=Muted,fontSize=10.sp);Text(site.city.ifBlank{"—"},color=IceWhite);ButtonTrace("Show on Map",Modifier.fillMaxWidth()){if(mapSites.none{siteKey(it.name)==siteKey(site.name)}) mapSites.add(site);selectedMapSite=site;selectedSite=null;activePage="Map"} } }
            item { CardBox { Text("NETWORK INFORMATION",color=Ice,fontWeight=FontWeight.Bold,fontSize=12.sp); InfoLine("Technology",site.tech.ifBlank{"—"});InfoLine("Source database",site.source.ifBlank{"—"});InfoLine("PCI",site.pci.ifBlank{"—"});InfoLine("Bands",site.bands.ifBlank{"Not detected in file"});InfoLine("Sector",site.sector.ifBlank{"Not detected in file"}) } }
            item { CardBox { Text("SITE ACTIONS",color=Ice,fontWeight=FontWeight.Bold,fontSize=12.sp); ButtonTrace("Copy coordinates",Modifier.fillMaxWidth()){ val coords="${site.lat?:""}, ${site.lon?:""}"; val cm=getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager;cm.setPrimaryClip(android.content.ClipData.newPlainText("coordinates",coords));Toast.makeText(this@MainActivity,"Coordinates copied",Toast.LENGTH_SHORT).show() }; ButtonTrace("Back to search",Modifier.fillMaxWidth(),outlined=true){selectedSite=null;activePage="Search"} } }
        }
    }
    @Composable private fun InfoLine(label:String,value:String) { Row(Modifier.fillMaxWidth().padding(vertical=3.dp),verticalAlignment=Alignment.CenterVertically){Text(label,color=Muted,fontSize=11.sp,modifier=Modifier.weight(1f));Text(value,color=IceWhite,fontSize=11.sp,fontWeight=FontWeight.Medium)};HorizontalDivider(color=Ice.copy(.1f)) }

    @Composable private fun AnalyticsPage() {
        Text("NETWORK ANALYTICS",fontSize=22.sp,fontWeight=FontWeight.Bold)
        Text("Summary of the currently imported databases",color=Muted,fontSize=11.sp)
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) { MetricCard("TOTAL SITES","${allSites.size}",Modifier.weight(1f));MetricCard("4G SITES","${sites4g.size}",Modifier.weight(1f));MetricCard("5G SITES","${sites5g.size}",Modifier.weight(1f)) }
        Spacer(Modifier.height(10.dp))
        CardBox {
            Text("DATABASE HEALTH",color=Ice,fontWeight=FontWeight.Bold,fontSize=12.sp)
            AnalyticsBar("4G database",sites4g.size,allSites.size,Ice)
            AnalyticsBar("5G database",sites5g.size,allSites.size,Cyan)
            AnalyticsBar("Sites with coordinates",allSites.count{it.lat!=null&&it.lon!=null},allSites.size,Purple)
        }
        Spacer(Modifier.height(10.dp))
        CardBox {
            Text("TOP TECHNOLOGY / BANDS",color=Ice,fontWeight=FontWeight.Bold,fontSize=12.sp)
            val bandCounts=allSites.flatMap{it.bands.split(Regex("[,;/| ]+")).filter{b->b.isNotBlank()}}.groupingBy{it.uppercase(Locale.ROOT)}.eachCount().entries.sortedByDescending{it.value}.take(7)
            if(bandCounts.isEmpty()) Text("Band details will appear when the imported Excel contains band columns.",color=Muted,fontSize=11.sp) else bandCounts.forEach{AnalyticsBar(it.key,it.value,bandCounts.maxOf{b->b.value},Ice)}
        }
        Spacer(Modifier.height(10.dp))
        CardBox { Text("DRIVE TEST EXPORT",color=Ice,fontWeight=FontWeight.Bold,fontSize=12.sp);Text("${routePoints.size} recorded route points • ${"%.2f".format(routeDistanceKm())} km",color=Muted,fontSize=12.sp);ButtonTrace("Export route GeoJSON",Modifier.fillMaxWidth()){saveGeoJson.launch("TRACE-route.geojson")} }
    }
    @Composable private fun MetricCard(label:String,value:String,modifier:Modifier) { Column(modifier.clip(RoundedCornerShape(15.dp)).background(Panel).border(1.dp,Ice.copy(.18f),RoundedCornerShape(15.dp)).padding(12.dp)){Text(label,color=Muted,fontSize=8.sp);Text(value,color=IceWhite,fontSize=21.sp,fontWeight=FontWeight.Bold)} }
    @Composable private fun AnalyticsBar(label:String,value:Int,total:Int,color:Color) { Column(Modifier.fillMaxWidth().padding(vertical=4.dp)){Row{Text(label,color=IceWhite,fontSize=11.sp,modifier=Modifier.weight(1f));Text(value.toString(),color=color,fontSize=11.sp,fontWeight=FontWeight.Bold)};Box(Modifier.fillMaxWidth().height(7.dp).clip(CircleShape).background(Panel2)){Box(Modifier.fillMaxWidth(if(total>0)(value.toFloat()/total).coerceIn(0f,1f)else 0f).fillMaxHeight().clip(CircleShape).background(color))}} }

    @Composable private fun SettingsPage() {
        Text("SETTINGS",fontSize=22.sp,fontWeight=FontWeight.Bold);Text("Personalize TRACE Motion",color=Muted,fontSize=11.sp);Spacer(Modifier.height(10.dp))
        LazyColumn(verticalArrangement=Arrangement.spacedBy(10.dp),contentPadding=PaddingValues(bottom=12.dp)) {
            item { CardBox { Text("LANGUAGE",color=Ice,fontSize=11.sp,fontWeight=FontWeight.Bold);Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){ButtonTrace("English",Modifier.weight(1f),outlined=language!="English"){language="English";prefs.edit().putString("language",language).apply()};ButtonTrace("العربية",Modifier.weight(1f),outlined=language!="العربية"){language="العربية";prefs.edit().putString("language",language).apply()}};Text("Language preference saved locally; full translation coverage is still being implemented.",color=Muted,fontSize=10.sp) } }
            item { CardBox { Text("MAP STYLE",color=Ice,fontSize=11.sp,fontWeight=FontWeight.Bold);listOf("Dark Street","Light Street","Satellite").forEach { style -> Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(if(mapStyle==style)Panel2 else Color.Transparent).clickable{mapStyle=style;prefs.edit().putString("mapStyle",style).apply()}.padding(10.dp),verticalAlignment=Alignment.CenterVertically){Icon(if(style=="Satellite")Icons.Default.SatelliteAlt else Icons.Default.Map,null,tint=if(mapStyle==style)Ice else Muted);Spacer(Modifier.width(10.dp));Text(style,modifier=Modifier.weight(1f),color=IceWhite);RadioButton(selected=mapStyle==style,onClick={mapStyle=style;prefs.edit().putString("mapStyle",style).apply()},colors=RadioButtonDefaults.colors(selectedColor=Ice))} } } }
            item { CardBox { Text("MAP OVERLAYS",color=Ice,fontSize=11.sp,fontWeight=FontWeight.Bold);SettingToggle("Show site markers",showSites){showSites=it;prefs.edit().putBoolean("showSites",it).apply()};SettingToggle("Show sectors",showSectors){showSectors=it;prefs.edit().putBoolean("showSectors",it).apply()};SettingToggle("Show PCI numbers",showPci){showPci=it;prefs.edit().putBoolean("showPci",it).apply()} } }
            item { CardBox { Text("TRACE MOTION",color=Ice,fontSize=11.sp,fontWeight=FontWeight.Bold);Text("Sage Green • Dark Street • Balanced layout",color=IceWhite,fontSize=12.sp);Text("4G and 5G Excel files remain separate on this device. Offline Egypt map tiles are not bundled in this starter build.",color=Muted,fontSize=11.sp);ButtonTrace("Export route GeoJSON",Modifier.fillMaxWidth()){saveGeoJson.launch("TRACE-route.geojson")} } }
        }
    }
    @Composable private fun SettingToggle(label:String,value:Boolean,onChange:(Boolean)->Unit) { Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Text(label,modifier=Modifier.weight(1f),color=IceWhite,fontSize=12.sp);Switch(checked=value,onCheckedChange=onChange,colors=SwitchDefaults.colors(checkedThumbColor=Bg,checkedTrackColor=Ice))} }

    @Composable private fun LogoMark(modifier:Modifier=Modifier) {
        val transition= rememberInfiniteTransition(label="scan"); val phase by transition.animateFloat(0f,1f,infiniteRepeatable(tween(1600,easing=LinearEasing)),label="phase")
        Canvas(modifier) { val c=Offset(size.width*.5f,size.height*.43f); for(i in 1..3){val radius=size.minDimension*(.13f+i*.12f);drawArc(Ice.copy(alpha=(.65f-i*.12f).coerceIn(.1f,1f)),180f,180f,false,topLeft=Offset(c.x-radius,c.y-radius),size=androidx.compose.ui.geometry.Size(radius*2,radius*2),style=Stroke(width=2.dp.toPx()))}; val path=Path().apply{moveTo(size.width*.14f,size.height*.78f);cubicTo(size.width*.34f,size.height*.72f,size.width*.45f,size.height*.88f,size.width*.65f,size.height*.75f);lineTo(size.width*.86f,size.height*.65f)};drawPath(path,Cyan,style=Stroke(width=3.dp.toPx()));drawCircle(Ice,radius=4.dp.toPx(),center=Offset(size.width*(.15f+.7f*phase),size.height*(.78f-.1f*phase))) }
    }
    @Composable private fun CardBox(content:@Composable ColumnScope.()->Unit) { Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(19.dp)).background(Panel).border(1.dp,Ice.copy(.16f),RoundedCornerShape(19.dp)).padding(14.dp),verticalArrangement=Arrangement.spacedBy(8.dp),content=content) }
    @Composable private fun ButtonTrace(label:String,modifier:Modifier=Modifier,outlined:Boolean=false,onClick:()->Unit) { if(outlined) OutlinedButton(onClick=onClick,modifier=modifier,shape=RoundedCornerShape(13.dp),border=androidx.compose.foundation.BorderStroke(1.dp,Ice.copy(.65f)),colors=ButtonDefaults.outlinedButtonColors(contentColor=Ice)){Text(label,fontSize=11.sp)} else Button(onClick=onClick,modifier=modifier,shape=RoundedCornerShape(13.dp),colors=ButtonDefaults.buttonColors(containerColor=Ice,contentColor=Bg)){Text(label,fontSize=11.sp,fontWeight=FontWeight.Bold)} }

    private fun excelMimeTypes()=arrayOf("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet","application/vnd.ms-excel","application/octet-stream")
    private fun filterSites(q:String, tech:String, source:List<Site>):List<Site> {
        val needle=q.trim()
        return source.asSequence()
            .filter { tech=="All" || it.source.contains(tech,true) || it.tech.contains(tech,true) }
            .filter { needle.isBlank() || "${it.name} ${it.city} ${it.pci} ${it.tech} ${it.bands} ${it.sector}".contains(needle,true) }
            .sortedBy { it.name }
            .toList()
    }
    private fun importExcel(uri:Uri,source:String) {
        status="Reading $source Excel…"
        Thread {
            try {
                val parsed = contentResolver.openInputStream(uri)?.use { input -> parseXlsx(input, source) }
                    ?: error("Android could not open the selected file. Choose it again from Downloads or Files.")
                if (parsed.records.isEmpty()) error("No site rows found. Check that the first worksheet has a header row and data rows.")
                val fourGSnapshot = if (source=="4G") parsed.records else sites4g.toList()
                val fiveGSnapshot = if (source=="5G") parsed.records else sites5g.toList()
                val mergedSnapshot = mergeSiteLists(fourGSnapshot, fiveGSnapshot)
                persistSiteFile(source, parsed.records)
                runOnUiThread {
                    val target = if(source=="4G") sites4g else sites5g
                    target.clear()
                    target.addAll(parsed.records)
                    cachedAllSites = mergedSnapshot
                    persistData()
                    status="${parsed.message} ${allSites.size} unique sites available in combined search."
                    Toast.makeText(this,status,Toast.LENGTH_LONG).show()
                }
            } catch(e:Exception) {
                runOnUiThread {
                    status="$source import failed: ${e.message ?: e.javaClass.simpleName}"
                    Toast.makeText(this,status,Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    /** Android-native .xlsx reader. Avoids Apache POI's Android-incompatible XML/desktop dependencies. */
    private fun parseXlsx(input: java.io.InputStream, source: String): ParsedResult {
        val entries = HashMap<String, ByteArray>()
        var totalUncompressed = 0L
        ZipInputStream(input).use { zip ->
            while (true) {
                val entry = zip.nextEntry ?: break
                if (!entry.isDirectory) {
                    val name = entry.name.replace('\\', '/')
                    val needed = name == "xl/workbook.xml" || name == "xl/_rels/workbook.xml.rels" ||
                        name == "xl/sharedStrings.xml" || name.matches(Regex("xl/worksheets/sheet[0-9]+\\.xml"))
                    if (needed) {
                        val bytes = zip.readBytes()
                        totalUncompressed += bytes.size
                        require(bytes.size <= 48 * 1024 * 1024) { "Excel XML part is too large to safely import on this device" }
                        require(totalUncompressed <= 96L * 1024 * 1024) { "Excel workbook is too large for safe import; split the database into smaller files" }
                        entries[name] = bytes
                    } else {
                        // Drain skipped ZIP entries without retaining them in memory.
                        val buffer = ByteArray(8192)
                        while (zip.read(buffer) >= 0) { }
                    }
                }
                zip.closeEntry()
            }
        }
        require(entries.containsKey("xl/workbook.xml")) { "This file is not a valid .xlsx workbook. Please select an .xlsx file, not .xls or CSV." }

        fun parserFor(bytes: ByteArray): XmlPullParser = Xml.newPullParser().apply {
            setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false)
            setInput(ByteArrayInputStream(bytes), "UTF-8")
        }
        fun attr(parser: XmlPullParser, name: String): String? {
            for (i in 0 until parser.attributeCount) {
                val n = parser.getAttributeName(i)
                if (n == name || n.endsWith(":$name")) return parser.getAttributeValue(i)
            }
            return null
        }
        val shared = mutableListOf<String>()
        entries["xl/sharedStrings.xml"]?.let { bytes ->
            val p = parserFor(bytes)
            var inSi = false
            val text = StringBuilder()
            while (p.eventType != XmlPullParser.END_DOCUMENT) {
                when (p.eventType) {
                    XmlPullParser.START_TAG -> when (p.name) {
                        "si" -> { inSi = true; text.setLength(0) }
                        "t" -> if (inSi) text.append(p.nextText())
                    }
                    XmlPullParser.END_TAG -> if (p.name == "si") { shared.add(text.toString()); inSi = false }
                }
                p.next()
            }
        }

        var target = "xl/worksheets/sheet1.xml"
        val workbookParser = parserFor(entries.getValue("xl/workbook.xml"))
        var firstRelId: String? = null
        while (workbookParser.eventType != XmlPullParser.END_DOCUMENT) {
            if (workbookParser.eventType == XmlPullParser.START_TAG && workbookParser.name == "sheet") {
                firstRelId = attr(workbookParser, "id")
                if (firstRelId != null) break
            }
            workbookParser.next()
        }
        if (firstRelId != null) {
            entries["xl/_rels/workbook.xml.rels"]?.let { bytes ->
                val rp = parserFor(bytes)
                while (rp.eventType != XmlPullParser.END_DOCUMENT) {
                    if (rp.eventType == XmlPullParser.START_TAG && rp.name == "Relationship" && attr(rp,"Id") == firstRelId) {
                        val raw = attr(rp,"Target")
                        if (!raw.isNullOrBlank()) target = if (raw.startsWith("/")) raw.removePrefix("/") else "xl/" + raw.removePrefix("./")
                        break
                    }
                    rp.next()
                }
            }
        }
        val sheetBytes = entries[target] ?: entries[target.removePrefix("xl/")] ?: error("Could not find the first worksheet in this Excel file")
        // Parse one worksheet row at a time. Do not keep a second copy of every Excel cell in RAM.
        val sheetParser = parserFor(sheetBytes)
        var row: MutableList<String>? = null
        var cellRef = "A1"
        var cellType = ""
        var cellText = StringBuilder()
        var inCell = false
        var headers: List<String>? = null
        var nameCol: Int? = null
        var latCol: Int? = null
        var lonCol: Int? = null
        var cityCol: Int? = null
        var pciCol: Int? = null
        var techCol: Int? = null
        var bandCol: Int? = null
        var sectorCol: Int? = null
        var azimuthCol: Int? = null
        val out = ArrayList<Site>()
        val seen = HashSet<String>()

        fun findCol(headerList: List<String>, vararg candidates: String): Int? = candidates.firstNotNullOfOrNull { candidate ->
            val n = normalize(candidate)
            headerList.indexOfFirst { it.contains(n) }.takeIf { it >= 0 }
        }
        fun value(values: List<String>, index: Int?): String = index?.let { values.getOrNull(it).orEmpty() }.orEmpty()
        fun consumeRow(values: List<String>) {
            if (values.none { it.isNotBlank() }) return
            if (headers == null) {
                val normalized = values.map { normalize(it) }
                headers = normalized
                nameCol = findCol(normalized, "site name", "site id", "cai", "ncai", "site", "name")
                    ?: error("No site name / CAI / NCAI column found in the first worksheet headers")
                latCol = findCol(normalized, "latitude", "lat")
                lonCol = findCol(normalized, "longitude", "lon", "long")
                cityCol = findCol(normalized, "city", "area", "location", "region", "governorate")
                pciCol = findCol(normalized, "pci")
                techCol = findCol(normalized, "technology", "tech", "rat", "system")
                bandCol = findCol(normalized, "bands", "band", "frequency")
                sectorCol = findCol(normalized, "sector id", "sectorid", "sector")
                azimuthCol = findCol(normalized, "azimuth", "azimuth angle", "antenna azimuth", "bearing", "direction", "azm", "asm")
                return
            }
            val name = value(values, nameCol).trim()
            if (name.isBlank()) return
            val lat = value(values,latCol).replace(",", "").toDoubleOrNull()?.takeIf { it in -90.0..90.0 }
            val lon = value(values,lonCol).replace(",", "").toDoubleOrNull()?.takeIf { it in -180.0..180.0 }
            val azimuthRaw = value(values,azimuthCol).trim().replace("°", "").replace(",", ".")
            val azimuth = Regex("[-+]?[0-9]+(?:\\.[0-9]+)?").find(azimuthRaw)?.value?.toDoubleOrNull()
                ?.takeIf { it.isFinite() }?.let { ((it % 360.0) + 360.0) % 360.0 }
            val site = Site(name,lat,lon,value(values,cityCol),value(values,pciCol),value(values,techCol).ifBlank { source },value(values,bandCol),value(values,sectorCol),source,azimuth)
            // Keep distinct cell/sector rows for the same physical site; only dedupe exact sector records.
            val key = listOf(site.name.trim().uppercase(Locale.ROOT), site.lat, site.lon,
                site.sector.trim().uppercase(Locale.ROOT), site.pci.trim(), site.azimuth, site.bands.trim().uppercase(Locale.ROOT)).joinToString("|")
            if (seen.add(key)) out.add(site)
        }

        while (sheetParser.eventType != XmlPullParser.END_DOCUMENT) {
            when (sheetParser.eventType) {
                XmlPullParser.START_TAG -> when (sheetParser.name) {
                    "row" -> row = mutableListOf()
                    "c" -> { inCell = true; cellRef = attr(sheetParser,"r") ?: "A1"; cellType = attr(sheetParser,"t") ?: ""; cellText = StringBuilder() }
                    "v", "t" -> if (inCell) cellText.append(sheetParser.nextText())
                }
                XmlPullParser.END_TAG -> when (sheetParser.name) {
                    "c" -> {
                        val letters = cellRef.takeWhile { it.isLetter() }.uppercase(Locale.ROOT)
                        var colIndex = 0
                        for (ch in letters) colIndex = colIndex * 26 + (ch - 'A' + 1)
                        colIndex = (colIndex - 1).coerceAtLeast(0)
                        val cellValue = when (cellType) {
                            "s" -> cellText.toString().toIntOrNull()?.let { shared.getOrNull(it) }.orEmpty()
                            "inlineStr", "str" -> cellText.toString()
                            "b" -> if (cellText.toString()=="1") "TRUE" else "FALSE"
                            else -> cellText.toString()
                        }
                        row?.let { current ->
                            // Guard against malformed spreadsheets with absurd cell references.
                            if (colIndex < 512) {
                                while (current.size <= colIndex) current.add("")
                                current[colIndex] = cellValue.trim()
                            }
                        }
                        inCell = false
                    }
                    "row" -> { row?.let { consumeRow(it) }; row = null }
                }
            }
            sheetParser.next()
        }
        require(headers != null) { "The first worksheet is empty" }
        require(out.isNotEmpty()) { "No site rows found after the header row" }
        return ParsedResult(out,"Imported ${out.size} $source rows from .xlsx.")
    }

    private fun normalize(value:String)=value.lowercase(Locale.ROOT).replace(Regex("[^a-z0-9]"),"")
    private fun siteKey(value:String):String {
        val key = normalize(value)
        return key.replaceFirst(Regex("^(ncai|cai)"), "").ifBlank { key }
    }
    private fun sitesToJson(list: List<Site>): JSONArray = JSONArray().apply {
        list.forEach { site ->
            put(JSONObject()
                .put("name", site.name)
                .put("lat", site.lat ?: JSONObject.NULL)
                .put("lon", site.lon ?: JSONObject.NULL)
                .put("city", site.city)
                .put("pci", site.pci)
                .put("tech", site.tech)
                .put("bands", site.bands)
                .put("sector", site.sector)
                .put("source", site.source)
                .put("azimuth", site.azimuth ?: JSONObject.NULL))
        }
    }
    private fun persistSiteFile(source: String, records: List<Site>) {
        val fileName = if (source=="4G") "trace_sites_4g.json" else "trace_sites_5g.json"
        openFileOutput(fileName, Context.MODE_PRIVATE).bufferedWriter().use { it.write(sitesToJson(records).toString()) }
    }

    private fun persistData() {
        // Large database files are written once, on the import worker thread; settings stay small.
        prefs.edit()
            .putString("mapStyle", mapStyle)
            .putString("language", language)
            .putBoolean("showSites", showSites)
            .putBoolean("showPci", showPci)
            .putBoolean("showSectors", showSectors)
            .apply()
    }
    private fun restoreData() {
        fun restoreFile(fileName: String, target: MutableList<Site>) {
            try {
                val file = java.io.File(filesDir, fileName)
                if (!file.exists()) return
                val arr = JSONArray(file.readText())
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    target.add(Site(o.optString("name"), if(o.isNull("lat")) null else o.optDouble("lat"), if(o.isNull("lon")) null else o.optDouble("lon"), o.optString("city"), o.optString("pci"), o.optString("tech"), o.optString("bands"), o.optString("sector"), o.optString("source"), if(o.isNull("azimuth")) null else o.optDouble("azimuth")))
                }
            } catch (_: Exception) { }
        }
        // One-time migration from the previous version's SharedPreferences storage.
        restoreFile("trace_sites_4g.json", sites4g)
        restoreFile("trace_sites_5g.json", sites5g)
        if (sites4g.isEmpty()) restoreLegacy("sites4g", sites4g)
        if (sites5g.isEmpty()) restoreLegacy("sites5g", sites5g)
        refreshAllSites()
        mapStyle=prefs.getString("mapStyle","Dark Street")?:"Dark Street"
        language=prefs.getString("language","English")?:"English"
        showSites=prefs.getBoolean("showSites",true)
        showPci=prefs.getBoolean("showPci",true)
        showSectors=prefs.getBoolean("showSectors",true)
        try { val arr=JSONArray(prefs.getString("route", "[]")); for(i in 0 until arr.length()) { val o=arr.getJSONObject(i); val l=Location("saved"); l.latitude=o.getDouble("lat"); l.longitude=o.getDouble("lon"); l.accuracy=o.optDouble("accuracy",0.0).toFloat(); l.time=o.optLong("time"); routePoints.add(l) } } catch (_:Exception) { }
    }
    private fun restoreLegacy(key: String, target: MutableList<Site>) {
        try {
            val raw=prefs.getString(key,null)?:return
            val arr=JSONArray(raw)
            for(i in 0 until arr.length()) { val o=arr.getJSONObject(i); target.add(Site(o.optString("name"),if(o.isNull("lat"))null else o.optDouble("lat"),if(o.isNull("lon"))null else o.optDouble("lon"),o.optString("city"),o.optString("pci"),o.optString("tech"),o.optString("bands"),o.optString("sector"),o.optString("source"),if(o.isNull("azimuth")) null else o.optDouble("azimuth"))) }
            if (target.isNotEmpty()) {
                val fileName=if(key=="sites4g") "trace_sites_4g.json" else "trace_sites_5g.json"
                openFileOutput(fileName, Context.MODE_PRIVATE).bufferedWriter().use { it.write(sitesToJson(target).toString()) }
            }
        } catch (_:Exception) { }
    }

    private fun requestGps(){val fine=ContextCompat.checkSelfPermission(this,Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED;val coarse=ContextCompat.checkSelfPermission(this,Manifest.permission.ACCESS_COARSE_LOCATION)==PackageManager.PERMISSION_GRANTED;if(!fine&&!coarse)askLocation.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION))else startGps()}
    private fun startGps(){try{val listener=object:LocationListener{override fun onLocationChanged(location:Location){val previous=currentLocation;if(previous==null||previous.distanceTo(location)>=8f||previous.accuracy-location.accuracy>=10f) currentLocation=location;if(tracking&&location.accuracy<=50f){val prev=routePoints.lastOrNull();if(prev==null||prev.distanceTo(location)>=4f){routePoints.add(location);saveRoute()}}};override fun onProviderEnabled(provider:String){};override fun onProviderDisabled(provider:String){status="GPS provider disabled."}};locationListener?.let{runCatching{locationManager.removeUpdates(it)}};locationListener=listener;val hasFine=ContextCompat.checkSelfPermission(this,Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED;val provider=if(hasFine&&locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER))LocationManager.GPS_PROVIDER else LocationManager.NETWORK_PROVIDER;locationManager.requestLocationUpdates(provider,2000L,5f,listener,mainLooper);locationManager.getLastKnownLocation(provider)?.let{currentLocation=it};status="GPS active. Waiting for a fresh location if no recent fix is available."}catch(e:SecurityException){status="Location permission denied."}catch(e:Exception){status="GPS error: ${e.message}"}}
    private fun saveRoute(){val arr=JSONArray();routePoints.forEach{arr.put(JSONObject().put("lat",it.latitude).put("lon",it.longitude).put("accuracy",it.accuracy).put("time",it.time))};prefs.edit().putString("route",arr.toString()).apply()}
    private fun exportRoute(uri:Uri){try{val coords=JSONArray();routePoints.forEach{coords.put(JSONArray().put(it.longitude).put(it.latitude))};val geom=if(routePoints.size>=2)JSONObject().put("type","LineString").put("coordinates",coords)else JSONObject().put("type","MultiPoint").put("coordinates",coords);val feature=JSONObject().put("type","Feature").put("properties",JSONObject().put("name","TRACE Motion route").put("points",routePoints.size).put("exportedAt",SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX",Locale.US).format(Date()))).put("geometry",geom);val collection=JSONObject().put("type","FeatureCollection").put("features",JSONArray().put(feature));contentResolver.openOutputStream(uri)?.bufferedWriter()?.use{it.write(collection.toString(2))};Toast.makeText(this,"Route GeoJSON saved",Toast.LENGTH_LONG).show()}catch(e:Exception){Toast.makeText(this,"Export failed: ${e.message}",Toast.LENGTH_LONG).show()}}
    private fun routeDistanceKm():Double{var d=0.0;for(i in 1 until routePoints.size)d+=routePoints[i-1].distanceTo(routePoints[i]);return d/1000.0}
    private fun fmt(value:Double)=String.format(Locale.US,"%.5f",value)
    override fun onDestroy(){locationListener?.let{runCatching{locationManager.removeUpdates(it)}};super.onDestroy()}
}
