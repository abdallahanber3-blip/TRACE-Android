# SIGNAL X Android — fresh Home rebuild

This Android Studio project contains the SIGNAL X mobile app in a WebView and the existing Android background location service source.

## Home redesign
- The accumulated Home-specific styling patches have been removed and replaced by one clean Home stylesheet.
- New Home order: SIGNAL X header → NR 5G and LTE 4G Excel cards → Search and technology filters → separate Selected Sites card → Site Location card.
- The old Data Center card is hidden from the Home UI; the existing workbook pickers, IndexedDB persistence, parsing, search, map, PCI/sector, and tracking logic are retained.
- 2G/3G filter buttons are hidden visually only; the underlying data processing remains unchanged.
- NR/LTE cards show a green check when the app detects loaded workbook data.
- The four bottom navigation destinations remain Home, Map, Sites, and Settings.

## External Excel files
The workbooks are not embedded in this project. Users select them through Android's file picker; existing parsing and local persistence remain in the HTML app.

## Build APK
1. Open `trace-motion-android` in Android Studio.
2. Allow Gradle sync to download the configured Android Gradle Plugin/build tools.
3. Use **Build → Build Bundle(s) / APK(s) → Build APK(s)**.

This ZIP is Android Studio source, not a prebuilt APK. This environment did not have the Android SDK/Gradle build toolchain available, so an APK was not built or device-tested here.

## Preserve and test functionality
The original source backup is included as `TRACE-V109-original.html`. Before field use, test NR and LTE workbook import/reopen, site search and selection, NR-first map drawing, LTE fallback, PCI/sectors, GPS, Quick Fly, Nearest Site, Live Track, language switching, and Android background tracking on the target device.
