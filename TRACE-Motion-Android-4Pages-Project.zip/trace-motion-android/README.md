# TRACE Motion Android — source project

This project packages the supplied TRACE V109 mobile HTML app in an Android WebView and adds a native Android foreground location service for recording GPS fixes while the screen is off.

## Preserved from TRACE V109

- Original mobile HTML/CSS/JS interface, search, map controls, site information, sector/PCI display, Quick Fly, GPS controls, and NR-first map source selection.
- Separate external NR workbook and 4G map-only workbook upload flows. The workbooks are **not embedded in the project**; TRACE reads the selected files and persists parsed records in WebView IndexedDB on the device.
- Existing NR priority with 4G map-only fallback behavior. The original HTML also contains the fixed-database/fallback logic.
- WebView DOM storage and a stable HTTPS-like local origin for IndexedDB/localStorage persistence.

## Android additions

- `BackgroundTrackService`: foreground location service declared with `foregroundServiceType="location"`; starts from the Live Track START action, continues receiving location fixes while the Activity is backgrounded/screen is off, persists background fixes in app-private storage, and exposes an ongoing notification.
- GPS accuracy filter (up to 45 m) and 3 m stationary-noise filter for background points.
- On returning to TRACE, background fixes are shown as a dashed green segment on the existing Leaflet map.
- `EXPORT BACKGROUND GEOJSON` action saves the background-only segment using Android's document picker.
- Android runtime permission prompts for location and notifications; the service must be started while the app is visible.

## Build an installable APK

1. Install Android Studio with Android SDK Platform 35 and a compatible JDK (JDK 17 is recommended for Android Gradle Plugin 8.7.x).
2. Open this folder (`trace-motion-android`) in Android Studio.
3. Allow Gradle sync to download Android Gradle Plugin 8.7.3 and required build tools.
4. Connect an Android phone with USB debugging enabled, or create an emulator.
5. For an installable debug APK, select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
6. Android Studio writes the debug APK under `app/build/outputs/apk/debug/` (file name includes `.debug`). Use **Build → Generate Signed Bundle / APK** for a signed release APK.

Command-line build after Android SDK and Gradle are installed:

```bash
gradle assembleDebug
```

## Important validation status

This environment did not have Android SDK / `android.jar`, Gradle, or a Gradle wrapper installed, so an APK could not be compiled or installed here. This is a source-project handoff, **not a claim that an APK has been built or device-tested**. The Android project must be compiled and tested on a real phone before treating it as production-ready.

## Required real-device test checklist

- [ ] App launches and all external libraries/tiles load with internet access.
- [ ] NR workbook can be selected from Android's file picker, parsed, and restored after force-closing/reopening the app.
- [ ] Separate 4G location workbook can be selected and restored independently.
- [ ] A site with NR draws NR only; a site without NR uses the configured 4G/2G fallback rules in the supplied HTML.
- [ ] GPS permission denial and later permission grant are handled without crashing.
- [ ] START shows the ongoing notification; while the screen is locked, background points continue to be recorded.
- [ ] STOP ends location recording but preserves the recorded points; CLEAR removes the native background segment.
- [ ] Returning from screen-off shows the dashed green background segment without disrupting the original page's track.
- [ ] GeoJSON export opens Android's save dialog and produces a valid FeatureCollection.
- [ ] Test battery optimization / vendor-specific background restrictions on the target phone; Android vendors may throttle location even with a foreground service.
- [ ] Verify performance, memory use, route quality, and map behavior during an actual drive before field use.

## Current technical limitations to verify

- The original HTML references Leaflet, SheetJS, icons, fonts, map tiles, and road-matching services from external internet hosts. Those dependencies are not bundled here, so the app is not fully offline-capable yet.
- The background native line is intentionally separate from the existing foreground JavaScript track. It records only while the Activity is backgrounded to avoid duplicating the foreground line.
- The HTML's existing foreground tracking still relies on browser geolocation and its current road-matching behavior; device-level route matching and OEM battery behavior require real-world testing.
