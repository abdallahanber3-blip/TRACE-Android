package com.trace.motion;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.os.PowerManager;
import android.os.Looper;
import android.provider.Settings;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class BackgroundTrackService extends Service implements LocationListener {
    public static final String ACTION_START = "com.trace.motion.TRACK_START";
    public static final String ACTION_STOP = "com.trace.motion.TRACK_STOP";
    public static final String ACTION_BACKGROUND = "com.trace.motion.TRACK_BACKGROUND";
    public static final String ACTION_FOREGROUND = "com.trace.motion.TRACK_FOREGROUND";
    private static final String CHANNEL_ID = "trace_live_track";
    private static final int NOTIFICATION_ID = 4817;
    private static final String TAG = "TRACETrackService";

    private LocationManager locationManager;
    private PowerManager.WakeLock wakeLock;
    private final ExecutorService diskExecutor = Executors.newSingleThreadExecutor();
    private volatile boolean active = false;
    private volatile boolean appInBackground = false;
    private volatile int pointCount = 0;

    @Override public void onCreate() {
        super.onCreate();
        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
        appInBackground = getSharedPreferences("trace_track_service", MODE_PRIVATE).getBoolean("app_in_background", false);
        createNotificationChannel();
        pointCount = readPoints().length();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? ACTION_START : intent.getAction();
        if (ACTION_STOP.equals(action)) {
            active = false;
            appInBackground = false;
            getSharedPreferences("trace_track_service", MODE_PRIVATE).edit().putBoolean("app_in_background", false).apply();
            removeLocationUpdates();
            releaseWakeLock();
            stopForeground(STOP_FOREGROUND_REMOVE);
            stopSelf();
            return START_NOT_STICKY;
        }
        if (ACTION_BACKGROUND.equals(action)) {
            if (!active) {
                active = true;
                startForeground(NOTIFICATION_ID, buildNotification("Starting background location…"));
                requestLocationUpdates();
            }
            appInBackground = true;
            getSharedPreferences("trace_track_service", MODE_PRIVATE).edit().putBoolean("app_in_background", true).apply();
            acquireWakeLock();
            updateNotification("Recording while screen is off · " + pointCount + " fixes");
            return START_STICKY;
        }
        if (ACTION_FOREGROUND.equals(action)) {
            if (!active) {
                active = true;
                startForeground(NOTIFICATION_ID, buildNotification("Live Track ready"));
                requestLocationUpdates();
            }
            appInBackground = false;
            getSharedPreferences("trace_track_service", MODE_PRIVATE).edit().putBoolean("app_in_background", false).apply();
            releaseWakeLock();
            updateNotification("Live Track ready · " + pointCount + " background fixes");
            return START_STICKY;
        }
        active = true;
        startForeground(NOTIFICATION_ID, buildNotification("Waiting for GPS fix…"));
        requestLocationUpdates();
        return START_STICKY;
    }

    private void requestLocationUpdates() {
        if (locationManager == null) return;
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
            checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            updateNotification("Location permission required · open TRACE Motion");
            return;
        }
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1500L, 2.0f, this, Looper.getMainLooper());
                locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 2500L, 5.0f, this, Looper.getMainLooper());
            } else {
                locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1500L, 2.0f, this);
                locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 2500L, 5.0f, this);
            }
        } catch (SecurityException | IllegalArgumentException ex) {
            Log.w(TAG, "Unable to start location updates", ex);
            updateNotification("GPS unavailable · check location settings");
        }
    }

    @Override public void onLocationChanged(Location location) {
        if (!active || !appInBackground || location == null) return;
        if (!location.hasAccuracy() || location.getAccuracy() > 45f) return;
        JSONObject point = new JSONObject();
        try {
            point.put("lat", location.getLatitude());
            point.put("lng", location.getLongitude());
            point.put("time", location.getTime());
            point.put("accuracy", location.getAccuracy());
            if (location.hasSpeed()) point.put("speedMps", location.getSpeed());
        } catch (Exception ignored) { return; }
        diskExecutor.execute(() -> {
            JSONArray points = readPoints();
            // Avoid storing noisy duplicate fixes while the handset is stationary.
            try {
                if (points.length() > 0) {
                    JSONObject last = points.getJSONObject(points.length() - 1);
                    float[] dist = new float[1];
                    Location.distanceBetween(last.optDouble("lat"), last.optDouble("lng"),
                        point.optDouble("lat"), point.optDouble("lng"), dist);
                    if (dist[0] < 3.0f) return;
                }
                points.put(point);
                writePoints(points);
                pointCount = points.length();
                updateNotification("Recording while screen is off · " + pointCount + " fixes");
            } catch (Exception ex) { Log.w(TAG, "Could not save track point", ex); }
        });
    }

    public static String readTrackJson(Context context) {
        File file = new File(context.getFilesDir(), "trace-background-track.json");
        if (!file.exists()) return "{\"points\":[]}";
        try {
            byte[] bytes = java.nio.file.Files.readAllBytes(file.toPath());
            return new String(bytes, StandardCharsets.UTF_8);
        } catch (Exception e) { return "{\"points\":[]}"; }
    }

    public static void clearTrack(Context context) {
        File file = new File(context.getFilesDir(), "trace-background-track.json");
        try (FileOutputStream out = new FileOutputStream(file, false)) {
            out.write("{\"points\":[]}".getBytes(StandardCharsets.UTF_8));
        } catch (Exception ignored) { }
    }

    private JSONArray readPoints() {
        try {
            JSONObject root = new JSONObject(readTrackJson(this));
            JSONArray points = root.optJSONArray("points");
            return points == null ? new JSONArray() : points;
        } catch (Exception e) { return new JSONArray(); }
    }

    private void writePoints(JSONArray points) {
        JSONObject root = new JSONObject();
        try { root.put("points", points); } catch (Exception ignored) { }
        File file = new File(getFilesDir(), "trace-background-track.json");
        try (FileOutputStream out = new FileOutputStream(file, false)) {
            out.write(root.toString().getBytes(StandardCharsets.UTF_8));
            out.getFD().sync();
        } catch (Exception e) { Log.w(TAG, "Track persistence failed", e); }
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "TRACE Live Track", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Shows when TRACE is recording a drive track in the background");
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) manager.createNotificationChannel(channel);
        }
    }

    private Notification buildNotification(String text) {
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent pending = PendingIntent.getActivity(this, 0, open,
            PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));
        Notification.Builder builder = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
            ? new Notification.Builder(this, CHANNEL_ID) : new Notification.Builder(this);
        return builder.setContentTitle("TRACE Motion · Live Track")
            .setContentText(text).setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setContentIntent(pending).setOngoing(active).build();
    }

    private void updateNotification(String text) {
        NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (manager != null && active) manager.notify(NOTIFICATION_ID, buildNotification(text));
    }

    private void acquireWakeLock() {
        try {
            if (wakeLock == null) {
                PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
                if (pm != null) wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "TRACE:LiveTrack");
            }
            if (wakeLock != null && !wakeLock.isHeld()) wakeLock.acquire(10 * 60 * 60 * 1000L);
        } catch (Exception e) { Log.w(TAG, "Wake lock unavailable", e); }
    }

    private void releaseWakeLock() {
        try { if (wakeLock != null && wakeLock.isHeld()) wakeLock.release(); } catch (Exception ignored) { }
    }

    private void removeLocationUpdates() {
        try { if (locationManager != null) locationManager.removeUpdates(this); } catch (SecurityException ignored) { }
    }

    @Override public void onProviderEnabled(String provider) { }
    @Override public void onProviderDisabled(String provider) { }
    @Override public void onStatusChanged(String provider, int status, Bundle extras) { }
    @Override public void onDestroy() {
        active = false;
        removeLocationUpdates();
        releaseWakeLock();
        diskExecutor.shutdown();
        super.onDestroy();
    }
    @Override public IBinder onBind(Intent intent) { return null; }
}
