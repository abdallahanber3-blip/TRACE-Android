package com.trace.motion;

import android.Manifest;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.webkit.GeolocationPermissions;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.JavascriptInterface;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private static final int REQ_LOCATION = 4101;
    private static final int REQ_FILE_CHOOSER = 4102;
    private static final int REQ_NOTIFICATIONS = 4103;
    private static final int REQ_EXPORT_TRACK = 4104;
    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private boolean pageReady = false;
    private boolean pendingStartTrack = false;
    private String pendingExportJson = null;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(android.graphics.Color.rgb(17, 23, 19));
        getWindow().setNavigationBarColor(android.graphics.Color.rgb(17, 23, 19));
        webView = new WebView(this);
        webView.setBackgroundColor(android.graphics.Color.rgb(17, 23, 19));
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setDatabaseEnabled(true);
        webView.getSettings().setGeolocationEnabled(true);
        webView.getSettings().setAllowFileAccess(true);
        webView.getSettings().setAllowContentAccess(true);
        webView.getSettings().setMediaPlaybackRequiresUserGesture(true);
        webView.setOverScrollMode(WebView.OVER_SCROLL_NEVER);
        webView.addJavascriptInterface(new TraceBridge(), "TraceAndroid");
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if ("https".equalsIgnoreCase(uri.getScheme()) && "trace.local".equalsIgnoreCase(uri.getHost())) return false;
                // Keep the JavaScript bridge confined to the bundled TRACE origin.
                try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); } catch (Exception ignored) { }
                return true;
            }
            @Override public void onPageFinished(WebView view, String url) {
                pageReady = true;
                installTraceBridgeHooks();
                webView.postDelayed(() -> renderBackgroundTrack(), 1200);
                webView.postDelayed(() -> renderBackgroundTrack(), 3500);
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                Intent intent = params.createIntent();
                intent.setType("*/*");
                intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{
                    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    "application/vnd.ms-excel", "application/octet-stream", "text/csv"
                });
                try { startActivityForResult(intent, REQ_FILE_CHOOSER); }
                catch (ActivityNotFoundException e) { filePathCallback = null; Toast.makeText(MainActivity.this, "No file picker available", Toast.LENGTH_SHORT).show(); return false; }
                return true;
            }
            @Override public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
                boolean granted = checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
                    checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
                callback.invoke(origin, granted, false);
                if (!granted) requestLocationPermissions(false);
            }
        });
        setContentView(webView);
        try (java.io.InputStream input = getAssets().open("index.html")) {
            byte[] bytes = new byte[input.available()];
            int offset = 0, read;
            while ((read = input.read(bytes, offset, bytes.length - offset)) > 0) offset += read;
            String html = new String(bytes, 0, offset, java.nio.charset.StandardCharsets.UTF_8);
            // A stable HTTPS-like origin enables IndexedDB/localStorage persistence in WebView.
            webView.loadDataWithBaseURL("https://trace.local/", html, "text/html", "UTF-8", null);
        } catch (Exception e) {
            Toast.makeText(this, "Could not load TRACE assets", Toast.LENGTH_LONG).show();
        }
        requestNotificationPermission();
    }

    private void installTraceBridgeHooks() {
        String js = "(function(){if(window.__traceAndroidHooksInstalled)return;window.__traceAndroidHooksInstalled=true;" +
            "function wrap(name,action){var old=window[name];if(typeof old!=='function')return;window[name]=function(){var result=old.apply(this,arguments);try{if(window.TraceAndroid)TraceAndroid[ action ]();}catch(e){}return result;};}" +
            "wrap('startLiveTrack','startBackgroundTrack');wrap('stopLiveTrack','stopBackgroundTrack');wrap('clearLiveTrack','clearBackgroundTrack');" +
            "function addExport(){var actions=document.querySelector('.trace-live-track .lt-actions');if(!actions||document.getElementById('traceNativeExportBtn'))return;var b=document.createElement('button');b.id='traceNativeExportBtn';b.type='button';b.textContent='EXPORT BACKGROUND GEOJSON';b.style.cssText='min-height:40px;padding:8px 12px;border-radius:10px;border:1px solid #B5C9A8;background:#18251b;color:#E1E8DF;font-weight:700;width:100%;margin-top:7px';b.onclick=function(){try{TraceAndroid.exportBackgroundTrack();}catch(e){}};actions.parentNode.appendChild(b);}addExport();setTimeout(addExport,1500);" +
            "window.traceRenderAndroidBackgroundTrack=function(raw){try{var d=JSON.parse(raw||'{\\\"points\\\":[]}');var pts=(d.points||[]).map(function(p){return [Number(p.lat),Number(p.lng)];}).filter(function(p){return Number.isFinite(p[0])&&Number.isFinite(p[1]);});var m=(typeof map!=='undefined'?map:window.map);if(!window.L||!m||pts.length<2)return; if(!window.__traceAndroidBgLine){window.__traceAndroidBgLine=L.polyline(pts,{color:'#B5C9A8',weight:4,opacity:.86,dashArray:'7 5',interactive:false}).addTo(m);}else{window.__traceAndroidBgLine.setLatLngs(pts);} }catch(e){console.warn('TRACE background track display',e);}};" +
            "try{if(window.TraceAndroid)window.traceRenderAndroidBackgroundTrack(TraceAndroid.getBackgroundTrackJson());}catch(e){}" +
            "})();";
        webView.evaluateJavascript(js, null);
    }

    private void renderBackgroundTrack() {
        if (!pageReady || webView == null) return;
        webView.evaluateJavascript("try{if(window.traceRenderAndroidBackgroundTrack&&window.TraceAndroid)window.traceRenderAndroidBackgroundTrack(TraceAndroid.getBackgroundTrackJson());}catch(e){}", null);
    }

    private void requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIFICATIONS);
        }
    }

    private void requestLocationPermissions(boolean startAfter) {
        boolean fine = checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
        boolean coarse = checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
        if (fine || coarse) {
            if (startAfter) startTrackService();
            return;
        }
        pendingStartTrack = startAfter;
        requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_LOCATION);
    }

    private void startTrackService() {
        Intent intent = new Intent(this, BackgroundTrackService.class).setAction(BackgroundTrackService.ACTION_START);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent); else startService(intent);
        getPreferences(MODE_PRIVATE).edit().putBoolean("trace_track_active", true).apply();
    }

    private void stopTrackService() {
        startService(new Intent(this, BackgroundTrackService.class).setAction(BackgroundTrackService.ACTION_STOP));
        getPreferences(MODE_PRIVATE).edit().putBoolean("trace_track_active", false).apply();
        renderBackgroundTrack();
    }

    @Override protected void onStart() {
        super.onStart();
        if (getPreferences(MODE_PRIVATE).getBoolean("trace_track_active", false)) {
            startService(new Intent(this, BackgroundTrackService.class).setAction(BackgroundTrackService.ACTION_FOREGROUND));
            renderBackgroundTrack();
        }
    }

    @Override protected void onStop() {
        if (getPreferences(MODE_PRIVATE).getBoolean("trace_track_active", false)) {
            // The service is already foreground; this action switches it into background-recording mode.
            startService(new Intent(this, BackgroundTrackService.class).setAction(BackgroundTrackService.ACTION_BACKGROUND));
        }
        super.onStop();
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_LOCATION) {
            boolean ok = false;
            for (int result : grantResults) if (result == PackageManager.PERMISSION_GRANTED) ok = true;
            if (ok && pendingStartTrack) startTrackService();
            else if (!ok) Toast.makeText(this, "Location permission is needed for Live Track", Toast.LENGTH_LONG).show();
            pendingStartTrack = false;
            if (pageReady) webView.evaluateJavascript("try{if(window.locateUserGPS)window.locateUserGPS();}catch(e){}", null);
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_EXPORT_TRACK) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null && pendingExportJson != null) {
                try (java.io.OutputStream out = getContentResolver().openOutputStream(data.getData())) {
                    if (out != null) out.write(pendingExportJson.getBytes(java.nio.charset.StandardCharsets.UTF_8));
                    Toast.makeText(this, "Background track exported", Toast.LENGTH_LONG).show();
                } catch (Exception e) { Toast.makeText(this, "Export failed", Toast.LENGTH_LONG).show(); }
            }
            pendingExportJson = null;
        } else if (requestCode == REQ_FILE_CHOOSER) {
            Uri[] results = null;
            if (resultCode == RESULT_OK && data != null) {
                Uri uri = data.getData();
                if (uri != null) results = new Uri[]{uri};
            }
            if (filePathCallback != null) filePathCallback.onReceiveValue(results);
            filePathCallback = null;
        }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override protected void onResume() {
        super.onResume();
        if (webView != null) webView.onResume();
        renderBackgroundTrack();
    }

    @Override protected void onPause() {
        if (webView != null) webView.onPause();
        super.onPause();
    }

    @Override protected void onDestroy() {
        if (webView != null) { webView.removeJavascriptInterface("TraceAndroid"); webView.destroy(); }
        super.onDestroy();
    }

    private class TraceBridge {
        @JavascriptInterface public void startBackgroundTrack() {
            runOnUiThread(() -> requestLocationPermissions(true));
        }
        @JavascriptInterface public void stopBackgroundTrack() {
            runOnUiThread(() -> stopTrackService());
        }
        @JavascriptInterface public String getBackgroundTrackJson() {
            return BackgroundTrackService.readTrackJson(MainActivity.this);
        }
        @JavascriptInterface public void exportBackgroundTrack() {
            runOnUiThread(() -> {
                try {
                    org.json.JSONObject raw = new org.json.JSONObject(BackgroundTrackService.readTrackJson(MainActivity.this));
                    org.json.JSONArray src = raw.optJSONArray("points");
                    org.json.JSONArray coordinates = new org.json.JSONArray();
                    if (src != null) for (int i = 0; i < src.length(); i++) {
                        org.json.JSONObject p = src.optJSONObject(i);
                        if (p == null) continue;
                        org.json.JSONArray c = new org.json.JSONArray();
                        c.put(p.optDouble("lng")); c.put(p.optDouble("lat")); coordinates.put(c);
                    }
                    org.json.JSONObject geometry = new org.json.JSONObject().put("type", "LineString").put("coordinates", coordinates);
                    org.json.JSONObject feature = new org.json.JSONObject().put("type", "Feature").put("properties", new org.json.JSONObject().put("source", "TRACE Motion background GPS").put("exportedAt", System.currentTimeMillis())).put("geometry", geometry);
                    pendingExportJson = new org.json.JSONObject().put("type", "FeatureCollection").put("features", new org.json.JSONArray().put(feature)).toString(2);
                    Intent save = new Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("application/geo+json").putExtra(Intent.EXTRA_TITLE, "TRACE-background-track.geojson");
                    startActivityForResult(save, REQ_EXPORT_TRACK);
                } catch (Exception e) { Toast.makeText(MainActivity.this, "Could not prepare track export", Toast.LENGTH_LONG).show(); }
            });
        }
        @JavascriptInterface public void clearBackgroundTrack() {
            BackgroundTrackService.clearTrack(MainActivity.this);
            runOnUiThread(() -> {
                if (pageReady && webView != null) webView.evaluateJavascript("try{if(window.__traceAndroidBgLine&&window.map){(typeof map!=='undefined'?map:window.map).removeLayer(window.__traceAndroidBgLine);window.__traceAndroidBgLine=null;}}catch(e){}", null);
            });
        }
        @JavascriptInterface public String getAppVersion() { return "TRACE Motion Android 1.0.0"; }
    }
}
