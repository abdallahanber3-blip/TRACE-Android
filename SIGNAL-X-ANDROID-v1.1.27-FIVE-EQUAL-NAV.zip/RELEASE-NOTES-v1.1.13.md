# SIGNAL X v1.1.13 — Field Layout Refinement

## What changed
- Reworked spacing and content hierarchy from the v1.1.12 mobile screenshots.
- Reduced excessive vertical gaps in Settings and tightened content rhythm across pages.
- Removed nested visual card treatment inside Site Information: technology switches, sector rows and metrics now read as one continuous technical panel.
- Reworked SITE PLANNER groups into wider two-column site rows, smaller inline copy actions, compact count strip, readable group metrics and cleaner To-do rows.
- Adjusted text wrapping: normal paragraph wrapping, stable site IDs/technical values, and fewer awkward narrow columns.
- Increased safe bottom scroll space so the fixed navigation does not cover the final content.
- Kept translucent glass surfaces, restrained amber glow and short entrance animations while reducing repeated heavy shadows.
- Preserved dark/light themes, RTL/LTR, map, GPS, Excel imports, search, drive-test, Planner logic, copy, completion and Show in Map handlers.

## Code structure
- Replaced the complete v1.1.12 unified visual style block with one canonical v1.1.13 design layer.
- Updated the canonical CSS copies and removed the stale v1.1.12 duplicate CSS asset.
- Kept core behavior and feature JavaScript unchanged.

## Validation
- CSS parsed in Chromium.
- Rendered Home, Map, Sites, Planner and Settings at 360, 390, 412 and 768 CSS-pixel widths.
- Checked horizontal overflow, page visibility, bottom navigation overlap, and card/content dimensions.
- Verified the five-page navigation still switches exactly one active workspace.
- The Leaflet CDN is blocked in the offline preview environment; real map tiles require device/network verification.
- No APK build or physical-device test was performed in this environment.
