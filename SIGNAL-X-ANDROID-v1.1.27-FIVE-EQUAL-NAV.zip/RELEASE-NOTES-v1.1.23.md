# SIGNAL X v1.1.23 — Route Page & Manual Site Selection

## What changed

- Added **Route Planner** as a dedicated page in the main navigation, separate from the existing Site Planner page.
- Route destinations are now sourced from the complete uploaded 4G/5G site database (with valid coordinates), plus any saved pending Planner items that are not currently in the database.
- Nothing is selected automatically. The user must check each site manually; search filters the full candidate list.
- “Select shown” selects only the visible, filtered results (up to 80 at a time), while “Clear selection” clears the manual route selection.
- The manual start-site selector can use any site in the database; GPS remains the default start point.
- Completed Site Planner entries are excluded from destination selection. When a route stop is marked Complete, a corresponding Completed entry is created in Site Planner if it did not exist, and the visit is recorded in Daily Field Log.
- Route selections and route progress remain locally saved. Clearing the route does not delete the base 4G/5G database or Daily Field Log.
- Updated PWA cache version to v123 and Android `versionCode` to 23 / `versionName` to 1.1.23.

## Important behavior

- Route ordering uses straight-line coordinate distances as an initial estimate; it is not a road-network optimizer.
- The Navigate action opens Google Maps for road directions.
- GPS permission is requested only when the user chooses GPS as the start point or confirms a visit. A manual start site is available as an alternative.
- Route Planner is independent from Site Planner UI. The two share only the intended completion state and saved visit history.

## Validation performed

- JavaScript syntax check on all 33 inline script blocks: passed.
- Confirmed a single independent `route` page and navigation target.
- Confirmed the route picker source is the uploaded 4G/5G database and that selection is manual.
- Confirmed completed Planner sites are filtered from route destinations.
- Confirmed Android asset HTML and web `index.html` match the standalone HTML output.
- Confirmed Android and Web archives pass ZIP integrity checks.

## Not verified in this environment

- No Android APK build or physical-device test was performed.
- Real device GPS permission, external Google Maps navigation, and actual Leaflet tile/marker rendering still need confirmation on the target phone.
