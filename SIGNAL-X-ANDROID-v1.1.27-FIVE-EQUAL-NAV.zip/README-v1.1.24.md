# SIGNAL X v1.1.24

Route Planner is a separate page available from More, with manual destination selection from the uploaded 4G/5G database, GPS start, Google Maps driving directions and completion sync to SITE PLANNER / Daily Field Log. Nearby Groups now paginate four groups at a time.

See `RELEASE-NOTES-v1.1.24.md` for the Google Maps integration scope, known limitations and validation details.
