# SIGNAL X v1.1.18 — Spacing & Excel Status Polish

## Fixes
- Corrected the page-banner bottom spacing using a selector with sufficient specificity. The previous final rule set the margin to 1px, overriding the intended rhythm.
- Standardized banner-to-content separation at 14px (12px on extra-narrow screens) for Home, Map, Sites and Settings.
- Made NR 5G and LTE 4G upload checkmarks explicitly visible only after a valid workbook has been restored from local storage or successfully parsed.
- Added robust synchronization after IndexedDB restore, upload-status changes, database-ready events and page restore.
- Added accessible labels and title text describing whether each workbook is uploaded.

## Preserved
- Existing workbook parsing, IndexedDB stores, search, map, GPS, Drive Test, Sites and Site Planner logic were not edited.
- No permanent map markers or database behavior were changed by this UI update.

## Validation
- HTML/CSS/JavaScript parsing checks and ZIP integrity checks are included in the delivery.
- An Android device/APK build test was not performed in this environment.
