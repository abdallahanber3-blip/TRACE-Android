# SIGNAL X v1.1.24 — Route Planner, Google Maps Road Directions & Nearby Groups Pagination

## Changes
- Bottom navigation now keeps five items: Home, Map, Sites, Planner and More. Route Planner, Daily Field Log and Settings open from the More sheet.
- Route Planner remains a dedicated page separate from SITE PLANNER.
- Route destinations are manually selected from the uploaded 4G/5G app database. Nothing is preselected. Search, Select Shown and Clear Selection are available.
- GPS is the default route origin. A saved database site can be selected as a manual origin if GPS permission/location is unavailable.
- SIGNAL X orders the selected destinations with a straight-line nearest-neighbor plus local improvement heuristic.
- Google Maps opens multi-stop driving directions along roads. Android opens the installed Google Maps app through a validated native bridge with browser fallback. Web/PWA opens Google Maps in a new tab or current tab fallback.
- Longer routes are split into segments: up to 10 destinations per Android segment and 4 per Web/PWA segment. Each later segment begins at the previous segment's last stop. After consecutive visit completion, subsequent segments resume from the last consecutively completed stop.
- Completing a route stop updates the same SITE PLANNER record to Completed (creating the record there if it was selected directly from the database), removes it from future route selections/grouping and records it in Daily Field Log.
- Nearby Groups display a maximum of four groups per page with Previous/Next controls and a page/range indicator. Original group indices are retained for Show in Map.
- SIGNAL X in-app map preview displays the route origin and numbered stop markers only; it does not draw a straight-line connection that could be mistaken for a road route.
- Android version metadata updated to versionCode 24 / versionName 1.1.24. PWA cache updated to v124.

## Google Maps integration scope
- This release hands the driving route to the external Google Maps app/browser. The route's road geometry is computed by Google Maps, not drawn as Google road tiles inside SIGNAL X.
- Embedding Google Maps directly inside SIGNAL X with route geometry and live road ETA requires a Google Maps Platform key, enabled Maps/Routes services and billing. No key was supplied for this build.
- Stop ordering within SIGNAL X is based on straight-line distances; Google Maps then calculates road directions in that fixed stop order. It is not a traffic-aware road-time optimization.
- Large routes are segmented. Complete a segment and open the next segment when ready.

## Validation
- 33 inline JavaScript blocks passed `node --check`.
- 9 inline stylesheets parsed with no CSS syntax errors.
- Browser harness with mock database/GPS verified: five visible bottom-nav items; More opens; Route Planner opens as a distinct page; manual selection of 12 destinations; three Web/PWA Google Maps segments; constructed Directions URL includes origin, destination, waypoints and `travelmode=driving`; completing a stop adds it to Completed and Daily Field Log.
- Pagination test with 17 sample sites and group size 2 verified four groups on page 1 and four groups (5–8) on page 2, with remaining groups on page 3.
- Browser harness intentionally omitted external Leaflet scripts; map rendering itself was not tested in that harness. The two `L is not defined` events are expected in this external-library-free harness and do not indicate a production Leaflet failure.
- Android APK was not built and the native Google Maps/GPS bridge was not exercised on a physical device in this environment.
