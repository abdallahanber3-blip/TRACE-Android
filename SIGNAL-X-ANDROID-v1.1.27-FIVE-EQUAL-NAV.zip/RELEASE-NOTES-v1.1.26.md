# SIGNAL X v1.1.26 — Bottom Navigation Refinement

- Removed the Settings shortcut button from all page banners. Settings remains available from More.
- Rebuilt the bottom dock as five equal, fixed-height destinations: Home, Map, Sites, Planner, More.
- Replaced the unsupported More icon with the supported Font Awesome ellipsis icon.
- Kept Route Planner and Settings as More-menu destinations rather than hidden navigation tracks.
- Increased safe bottom content space so the dock does not cover the last card.
- No site database, route calculation, map, Planner, or Daily Field Log data logic was intentionally changed.

Validation: source inspection and JavaScript/CSS syntax checks; Android APK build and real-device testing were not performed.
