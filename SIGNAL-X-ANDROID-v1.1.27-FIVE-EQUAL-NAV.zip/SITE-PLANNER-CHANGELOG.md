# SIGNAL X v1.1.5 — Approved Brand + Show in Map

- Added an explicit **Show in Map** action to each Site Planner group. It opens the Map page only when tapped and draws numbered amber pins in a dedicated temporary Leaflet layer.
- The Planner map preview is isolated: it does not edit `activeSiteQueries`, Home search selections, 4G/5G records, ordinary map marker layers, or Drive Test state. A separate **Clear** control removes only the temporary Planner preview.
- Applied the approved SIGNAL X Tower Motion identity: Obsidian `#101316`, Graphite `#272D33`, Electric Amber `#FFB84D`, Warm Ivory `#F4F1EA`, Success `#22C55E`, Error `#EF4444`.
- Updated typography tokens to Sora, Inter, IBM Plex Sans Arabic, and IBM Plex Mono, and applied Amber-active states and the new card/navigation surfaces across the existing app.
- Replaced the old cyan/blue/violet X artwork with the approved telecom tower + radio waves + coverage beam mark in the app header, launch screen, PWA icons, touch icon, and Android launcher densities.
- Updated PWA manifests, service-worker cache version, Android status/window colors, and app version to 1.1.5.

## Validation
- Run inline JavaScript syntax checks and CSS parsing on the final HTML.
- Verify Android Gradle project metadata and ZIP integrity.
- A physical-device install/GPS/map/Excel run is still required after a debug APK build.
