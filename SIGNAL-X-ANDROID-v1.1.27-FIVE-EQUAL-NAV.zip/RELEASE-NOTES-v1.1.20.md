# SIGNAL X v1.1.20 — Search Theme Identity Fix

## What changed
- Replaced the legacy forest-green/black theme tokens with the approved Obsidian `#101316`, Graphite `#272D33`, Electric Amber `#FFB84D`, and Warm Ivory `#F4F1EA` palette.
- Rebuilt the Network Explorer search surface so Light mode uses warm ivory/white translucent glass, dark text, and amber accents.
- Dark mode now uses translucent Graphite rather than pure black or green-black, with Warm Ivory text and Electric Amber accents.
- Updated suggested-site rows, technology chips, counters, queue chips, and Show on Map action to follow the same theme.
- Kept suggested results in normal flow below the search field so they do not cover the input when Android keyboard is open.
- Preserved search matching, selection, and navigation JavaScript.

## Validation
- Parsed the new CSS block: no CSS syntax errors.
- Confirmed all 34 existing JavaScript blocks are byte-for-byte unchanged from v1.1.19.
- Verified Android and Web ZIP archive integrity.
- Chromium visual/computed-style testing was blocked in this environment; APK was not built and no physical Android device test was performed.
