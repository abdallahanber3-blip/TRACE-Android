# SIGNAL X v1.1.27 — Five Equal Navigation Tabs

## Changes
- Fixed the bottom navigation grid at its actual document location (the navigation is a direct child of `body`, outside `#appContainer`).
- Removed the stale six-column grid rule that left an empty sixth track after Route and Settings were hidden.
- The five visible tabs (Home, Map, Sites, Planner, More) now fill the dock evenly with identical widths and aligned icon/label stacks.
- Kept Route Planner, Daily Field Log and Settings inside the More sheet.
- More receives the active state while its sheet is open and remains active on secondary pages.
- Kept the dock compact, with safe-area spacing and reduced blur on small screens.

## Validation
- Verified nav markup has seven source buttons, with Route and Settings hidden and five visible destinations.
- Verified the final CSS selector targets `body > nav.trace-bottom-nav` rather than incorrectly scoping to `#appContainer`.
- JavaScript syntax and ZIP integrity checks are run on the delivered files.
- APK build and physical Android device testing were not performed in this environment.
