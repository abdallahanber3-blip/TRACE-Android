# SIGNAL X v1.1.25

Daily Field Log now has its own page; Settings is reachable from the top of page banners; bottom navigation is compact and remains five items. Idle save/render polling has been reduced to improve responsiveness. See RELEASE-NOTES-v1.1.25.md.
