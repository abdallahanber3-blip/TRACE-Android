# SIGNAL X v1.1.15 — Field Experience Reorganization

## Purpose
A full mobile-first layout pass based on the device screenshots. The goal is clearer content hierarchy and a consistent field-work interface, not smaller cards or additional nested surfaces.

## Layout and visual system
- Removed the extra app-container frame so the page canvas has one consistent background and the content uses more of the available mobile width.
- Rebalanced page banners, content widths, spacing and typography across Home, Map, Sites, Site Planner and Settings.
- Rebuilt the visual rhythm around a single parent glass surface per section. Inner information is displayed as flat rows, dividers, segmented controls and compact chips rather than repeated card-within-card shells.
- Standardized the warm Amber action color, neutral Obsidian/Graphite surfaces, Warm Ivory light theme, and green/red semantic status colors.
- Simplified the bottom navigation into one translucent dock with flat tabs and a clear Amber active state.
- Improved text wrapping, touch target sizes, sector metrics, planner rows, settings options and small-screen spacing.
- Retained short page entrance and interaction motion; reduced-motion preference is respected.
- Updated service-worker cache identifiers to avoid serving the previous layout.

## Behavior preservation
- Feature JavaScript and application handlers are preserved from v1.1.14.
- Map/Leaflet, GPS, search, Excel import, Drive Test, Site Information, Site Planner storage/grouping, copy actions and Show in Map behavior are not intentionally changed.
- The Android and PWA packages contain the same new embedded design system.

## Validation
- Chromium layout checks at 360, 390, 412 and 768 CSS px.
- Checked single-page navigation visibility and horizontal overflow.
- Checked theme tokens, active navigation and app-container surface/spacing.
- The browser test environment blocks external Leaflet/Font Awesome resources; full map tiles/icons require device/network verification.
- No APK build or physical Android device test was performed.
