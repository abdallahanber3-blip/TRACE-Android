# SIGNAL X v1.1.16 — Field UI Reorganization

## Screenshot-driven fixes
- Corrected Planner To-do layout to match its two direct children: a full-width checkbox/name label and a copy button. Site IDs no longer collapse into a 25px column or wrap character-by-character.
- Increased To-do touch targets, input area, site chips and pair-distance readability.
- Removed the extra background rectangle behind Home database upload tiles; the two upload tiles now sit directly on the page surface.
- Reduced excess nested surfaces in the Sites page; sector rows are flat and metric values are easier to scan.
- Map page retains three primary actions (Quick Fly, Nearest Site, Drive Test) in the action row; duplicate My GPS and GPS Lock toolbar buttons are hidden because their floating map controls remain available.
- Map height is balanced for mobile and extra bottom safe space prevents fixed navigation from covering the final map actions.
- Settings groups and sound status use the approved Amber palette; cyan/mint sound badge styling is replaced.
- Splash screen button and SIGNAL X wordmark accent are restored to Electric Amber rather than teal/violet.
- Bottom navigation labels and icons are more readable, with a consistent glass dock and safe-area spacing.
- Kept banner structure and no in-page brand wordmark.

## Preservation
- All feature JavaScript blocks are byte-for-byte unchanged from the v1.1.15 source.
- Existing network database parsing, Excel import, search, Leaflet map, GPS, Drive Test, Sites, Planner grouping, checklist persistence, copy and Show in Map handlers are retained.
- Android WebView and PWA use the same updated HTML and matching design system CSS.

## Validation
- Embedded CSS parsed successfully in Chromium.
- Tested mobile viewports at 360, 390, 412 and 492 CSS pixels in light and dark themes.
- Verified exactly one current page, no horizontal overflow, and corrected Planner To-do row grid/name width.
- Verified Home upload wrapper transparency, map toolbar has three visible primary actions, Amber sound status and Amber splash button.
- External tile / CDN access may be blocked in automated browser; verify map tiles and GPS behavior on a device.
- No APK build or physical device test was performed.
