# SIGNAL X Brand Guidelines — v1.1.6 update

## Approved core identity
- Obsidian `#101316` and Graphite `#272D33` are the primary dark surfaces.
- Electric Amber `#FFB84D` is the primary UI accent.
- Warm Ivory `#F4F1EA` is the primary light text/surface reference.
- Success `#22C55E` and Error `#EF4444` are semantic status colors only.
- Typography: Sora for headings, Inter for English UI, IBM Plex Sans Arabic for Arabic UI, and IBM Plex Mono for technical values.

## Internal page identity
The app wordmark and tower logo are not repeated inside application pages. Each page uses a descriptive banner with a short kicker, page title, one-line description, and a functional page icon. The approved page labels are:
- Home: `OPERATIONS` / `COMMAND CENTER`
- Map: `FIELD NAVIGATION` / `NETWORK MAP`
- Sites: `NETWORK DATA` / `SITE DATABASE`
- Planner: `FIELD WORKSPACE` / `SITE PLANNER`
- Settings: `CONFIGURATION` / `SYSTEM SETTINGS`

The app launcher icon and startup identity remain separate from internal page headers.

## Component color rules
- Primary actions, selected controls, navigation selection, focus and page banners use Amber.
- Neutral content surfaces use Obsidian and Graphite.
- Green is reserved for success, connected/live states, and network coverage/sector overlays.
- Red is reserved for errors and destructive warnings.
- Avoid unrelated cyan, blue, violet, or magenta as UI brand accents.

## Site Planner additions
Each site displayed in a group or To-do row has an individual copy action. Copying does not alter the checklist state or grouping calculations.
