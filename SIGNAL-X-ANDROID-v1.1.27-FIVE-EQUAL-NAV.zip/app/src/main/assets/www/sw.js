/* SIGNAL X PWA shell worker. External map tiles/CDNs are deliberately not cached. */
const CACHE_NAME = 'signal-x-shell-brand-2026-v127';
const SHELL = ['index.html', 'css/signalx-core.css', 'css/signalx-design-system.css', 'manifest.webmanifest', 'SIGNAL-X-2026-Motion-Sound.webmanifest', 'icons/signal-x-192.png', 'icons/signal-x-512.png', 'icons/signal-x-icon.svg', 'icons/signal-x-maskable.svg', 'SIGNAL-X-2026-Motion-Sound-Icon.svg'];
self.addEventListener('install', event => {
  event.waitUntil((async () => {
    const cache = await caches.open(CACHE_NAME);
    const urls = SHELL.map(path => new URL(path, self.registration.scope).href);
    await cache.addAll(urls);
    await self.skipWaiting();
  })());
});
self.addEventListener('activate', event => {
  event.waitUntil((async () => {
    const names = await caches.keys();
    await Promise.all(names.filter(name => name.startsWith('signal-x-shell-') && name !== CACHE_NAME).map(name => caches.delete(name)));
    await self.clients.claim();
  })());
});
self.addEventListener('fetch', event => {
  const request = event.request;
  if (request.method !== 'GET') return;
  const url = new URL(request.url);
  // Never intercept OpenStreetMap tiles, map layers, external libraries or other origins.
  if (url.origin !== self.location.origin) return;
  if (request.mode === 'navigate') {
    event.respondWith((async () => {
      const cache = await caches.open(CACHE_NAME);
      try {
        const response = await fetch(request);
        if (response && response.ok) cache.put(new URL('index.html', self.registration.scope).href, response.clone());
        return response;
      } catch (_) {
        return (await cache.match(new URL('index.html', self.registration.scope).href)) || Response.error();
      }
    })());
    return;
  }
  event.respondWith((async () => {
    const cache = await caches.open(CACHE_NAME);
    const cached = await cache.match(request);
    if (cached) return cached;
    try { return await fetch(request); } catch (_) { return cached || Response.error(); }
  })());
});
