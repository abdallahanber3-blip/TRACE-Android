# SIGNAL X — Brand Guidelines

**Version:** 1.1.5 · **Brand:** Tower Motion · **Tagline:** NETWORK INTELLIGENCE

## Brand idea

SIGNAL X is a field-focused telecom network intelligence workspace. The Tower Motion mark combines a radio tower, transmission waves and a coverage beam to communicate network visibility, precision and movement.

## Logo system

- **Primary mark:** tower + amber signal waves + coverage beam.
- **Wordmark:** SIGNAL in Warm Ivory or Obsidian; the X is Electric Amber.
- **Tagline:** NETWORK INTELLIGENCE in uppercase tracking.
- Use the horizontal lockup for headers and documents, the vertical lockup for centered/splash layouts, and the tower-only icon for the app launcher.
- Keep the logo proportional. Do not stretch, recolor the amber X, remove signal waves, rotate the tower, or place the dark-background lockup on a light background.
- Preserve clear space around the logo at least equal to the width of the tower mast. Do not place text or UI controls inside that space.

## Color palette

| Token | Hex | Role |
|---|---|---|
| Obsidian | `#101316` | Primary dark background |
| Graphite | `#272D33` | Cards, surfaces and containers |
| Electric Amber | `#FFB84D` | Primary accent, active controls and focus |
| Warm Ivory | `#F4F1EA` | Text on dark surfaces and light-theme canvas |
| Success Green | `#22C55E` | Success, connected and positive status |
| Error Red | `#EF4444` | Error and critical alert status |

Use amber for emphasis, not every element. Green and red are semantic status colors, not competing brand accents. The Light theme may use a darker amber tint for text contrast while retaining Electric Amber for key fills and brand artwork.

## Typography

| Typeface | Usage |
|---|---|
| Sora | English page titles and major headings |
| Inter | English UI, body text, buttons, lists and labels |
| IBM Plex Sans Arabic | Arabic interface and body text |
| IBM Plex Mono | PCI, EARFCN, NR-ARFCN, coordinates, identifiers and engineering values |

Arabic layouts use RTL. Numeric identifiers, coordinates, PCI and frequency values stay LTR and use tabular/monospaced presentation where appropriate.

## Iconography

- Unified outline family with consistent geometry and roughly 2–2.5 px stroke weight.
- Standard sizes: 24, 32 and 48 px.
- Neutral icons use Warm Ivory on dark surfaces; active/selected icons use Electric Amber.
- Success and error icons use their semantic status colors.
- Avoid mixing filled, thin-outline and heavy-outline icon families in one view.

## Interface language

- Mobile-first layouts; desktop may expand the composition without changing the underlying visual language.
- Core spacing: 8 px base grid; 12 px component gaps; 16 px screen padding; 24 px section spacing.
- Common dimensions: 48 px buttons and search fields, 56 px app bar and 64 px bottom navigation.
- Card radius: 16 px; buttons: 12 px; compact controls: 10 px.
- Surfaces use restrained borders and subtle elevation. Avoid excessive glass, glow or gradients that reduce data readability.
- Maintain consistent Dark, Light and System theme behavior.

## Motion

- Logo reveal target: 1.2 seconds, non-blocking.
- Page transition target: 200 ms, adaptive to RTL/LTR.
- Button and selection feedback: approximately 100–200 ms.
- Charts may animate progressively, but must not delay interaction.
- GPS/live-drive motion is subtle and contextual. No heavy or continuously decorative motion.
- Respect reduced-motion preferences and prioritize battery life, responsiveness and field readability.

## Product-specific principles

- Readability of site IDs, PCI, bands, ARFCN and coordinates takes priority over decoration.
- The map should remain visually calm; selected sites and sectors use clear, distinct semantic colors.
- SITE PLANNER is a separate workspace. It uses the existing 4G/5G database, keeps its checklist private to that page and only previews a group on the map after the user explicitly taps **Show in Map**.
- The temporary SITE PLANNER map layer must remain isolated from normal markers, imported database records and Drive Test layers.

## Avoid

- Legacy cyan/blue/purple neon as primary brand accents.
- Overly strong bloom, continuously animated backgrounds or unnecessary motion.
- Mixing unrelated font and icon families.
- Crowding screens or reducing engineering values below readable sizes.
- Altering the shape, proportions or color roles of the Tower Motion logo.

## Asset files

- `brand/SIGNAL-X-Logo-Horizontal-Dark.svg/.png`
- `brand/SIGNAL-X-Logo-Horizontal-Light.svg/.png`
- `brand/SIGNAL-X-Logo-Vertical-Dark.svg/.png`
- `brand/SIGNAL-X-Logo-Vertical-Light.svg/.png`
- `icons/signal-x-icon.svg`, `icons/signal-x-192.png`, `icons/signal-x-512.png`, `icons/signal-x-maskable.svg`
- Android launcher densities: `app/src/main/res/mipmap-*/ic_launcher*.png`
