# SIGNAL X v1.1.7 — Entry Screen & Planner Search

## Entry screen
- Reworked the initial workspace-entry screen with the approved Obsidian, Graphite, Electric Amber, Warm Ivory and Success Green palette.
- Removed the large tower-logo graphic from the in-app entry screen. The SIGNAL X name remains as text only; app launcher artwork remains separate.
- Replaced the old “Skip intro / auto-enter” behavior with an explicit **Open Workspace** action. The entry screen now remains visible until the user taps the button.
- Added Arabic/English text switching for the entry screen, aligned with the selected app language.
- Kept the decorative motion light and provided reduced-motion styling.

## Site Planner
- Added a search field above the To-do checklist.
- Search filters both pending and completed sites by normalized site ID/name, including the existing CAI/NCAI canonicalization.
- Checkboxes remain available in filtered results. Marking a pending site completed moves it to the completed section while preserving the active search; unchecking returns it to pending.
- Added a clear-search control and match counts.
- Planner data remains in the existing local storage key and the 4G/5G database is not modified.

## Package notes
- Android project versionName: `1.1.7`; versionCode: `9`.
- PWA cache name bumped to `signal-x-shell-brand-2026-v5` to avoid serving the previous UI shell.
- Active Android/PWA entry file: `index.html`.
- The project was syntax-checked (30 inline JavaScript blocks, no syntax errors) and the added CSS was parsed (46 rules, no parse errors). Search renderer was exercised in a Node harness for pending, completed, NCAI alias and no-results cases.
- An APK was not built and no physical Android device test was performed in this environment.
