# SIGNAL X v1.1.19 — Planner Map Preview Fix

## Fixes
- Restored the missing visual styling for the temporary Site Planner map-preview banner. The title, group count, helper text, and Clear button now render as a compact glass/Amber panel.
- Restored visible numbered markers on the map. The map previously created Leaflet markers, but their styles were in a stylesheet that was not loaded by the active app HTML, leaving only plain numbers visible.
- Updated the numbered pin shape, contrast, shadow, entry animation, popup typography, and marker stacking priority.
- Kept the Planner map preview isolated: Clear removes only the temporary Planner overlay and hides its banner; it does not clear normal site markers, search selection, Excel databases, or Drive Test state.
- Updated Android `versionCode` to `20`, `versionName` to `1.1.19`, and PWA cache key to `signal-x-shell-brand-2026-v119`.

## Validation performed
- All 32 inline JavaScript blocks passed Node syntax checks.
- Browser CSS smoke test confirmed: banner uses flex layout, banner text is stacked cleanly, Clear button is styled, and numbered pins render at 34px with a visible pin shape.
- Browser preview generated for a three-site group.
- Android and PWA archives passed ZIP integrity checks.

## Not claimed
- No APK build or physical Android device test was performed in this environment.
- Actual external map tile availability still depends on the device's internet connection.
