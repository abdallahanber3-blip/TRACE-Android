# SIGNAL X v1.1.21 — Route Optimizer & Daily Field Log

## Added
- Route Optimizer inside Site Planner.
- GPS is the default route start; a saved Planner site can be selected as a manual starting point.
- Route scope can use all pending sites or one of the generated nearby groups.
- Route order uses nearest-neighbour selection with a 2-opt refinement over straight-line coordinate distances.
- Per-stop Google Maps navigation handoff (Android bridge where available; Maps URL for web/PWA).
- Explicit Complete action per stop. Confirmed stops are marked Completed in Site Planner and excluded from future groups.
- Daily Field Log on Home, storing visit time, site, coordinate source, coordinates, source and optional field notes locally.
- Issue logging is separate from completion and does not mark a Planner site completed.
- Route session and Daily Field Log persist locally across app restarts.

## Notes / limitations
- Optimizer distance is straight-line (Haversine) approximation, not road distance. Google Maps provides road navigation one stop at a time.
- GPS access requires location permission and an available device location fix. Manual site start is provided as fallback.
- GPS sampling is foreground / one-shot for route start and visit completion. This release does not add continuous background tracking or a background location service.
- Daily Field Log photos are not included in this release; text notes and coordinates are supported.
- Existing Planner storage key and 4G/5G database are unchanged. Clearing Site Planner does not clear Daily Field Log.
