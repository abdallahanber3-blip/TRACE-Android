# SIGNAL X v1.1.14 — Field UI Reorganization

## Why this release
Reorganized the mobile page layouts after reviewing the actual device screenshots. The goal is consistent hierarchy and readable content, not smaller tiles or more nested cards.

## UI refinements
- Replaced oversized vertical gaps with a consistent 10–14 px spacing rhythm.
- Rebalanced banner title, subtitle and icon alignment.
- Fixed page visibility so exactly one workspace is rendered at a time; inactive Home/Settings pages no longer override navigation visibility.
- Reworked Home upload tiles to prevent text clipping and give titles/descriptions a stable readable column.
- Simplified Home search, selected-site queue and site-location details into clear sections.
- Expanded the map canvas and standardized the action toolbar.
- Reorganized Sites into one main technical surface: active-site selector, site summary, actions, technology switch and flat sector rows.
- Reworked Planner database input, count strip, group sizing, group site chips, pair distances and To-do list rows to remove card-within-card styling.
- Compactified Settings options into consistent segmented controls and reduced vertical gaps.
- Standardized typography, radii, control heights, glass surfaces, borders and shadows for dark and light themes.
- Added short page/card entrance motion and restrained banner sheen; honors `prefers-reduced-motion`.
- Added safe bottom spacing so the fixed navigation does not cover the end of the page.

## Behavior preservation
- Core feature JavaScript was not modified from v1.1.13.
- Existing map, GPS, site search, Excel import, Drive Test, Site Planner storage, group calculations, copy actions, and Show in Map handlers are retained.
- Service-worker cache name was bumped to avoid serving stale CSS/app shell.

## Validation
- HTML, embedded CSS, and JavaScript syntax checks passed.
- Chromium render checks were run for Home, Map, Sites, Planner and Settings at 412 px width in light theme.
- Verified exactly one `.trace-page.is-current` is visible after each navigation action.
- Checked horizontal overflow and bottom-navigation placement.
- Leaflet CDN/tiles are unavailable in this offline render environment; map visuals and GPS require device/network verification.
- No APK build or physical Android device test was performed.
