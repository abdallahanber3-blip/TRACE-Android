# SIGNAL X v1.1.5 — Release Notes

## Site Planner: Show in Map

- Added a per-group **Show in Map** button to SITE PLANNER.
- The action is opt-in. The map does not show planner pins until the user taps the button.
- The selected group appears as numbered amber pins with site-name and coordinate popups.
- Pins live in a dedicated temporary Leaflet layer. The planner banner's Clear control removes only this layer; normal map markers, imported records, search selections and Drive Test layers remain separate.

## Approved Tower Motion identity

- Applied the approved Obsidian / Graphite / Electric Amber / Warm Ivory palette with semantic green and red status colors.
- Standardized the interface typography on Sora, Inter, IBM Plex Sans Arabic and IBM Plex Mono.
- Replaced the previous X graphic mark with the Tower Motion telecommunications tower, signal waves and coverage beam in the header, splash screen, PWA icons and Android launcher assets.
- Added horizontal and vertical logo lockups for dark and light backgrounds, as SVG and PNG.
- Updated Android theme colors, PWA manifest colors and service-worker cache version.

## Carried-forward SITE PLANNER behavior

- Uses existing 4G/5G records and stored coordinates.
- Accepts one site name or bulk input of 50–60 names.
- Groups pending sites by selected group size (2–7), computes straight-line distances and excludes completed items.
- Persists the checklist locally; duplicate or completed names are not re-added. Clear affects only the planner list.

## Validation performed

- 30 inline JavaScript blocks passed `node --check`.
- Inline CSS parsed with zero top-level parse errors (2,377 parsed rules).
- Both PWA manifests parsed as JSON; Android manifest and styles XML parsed successfully.
- Clustering test exercised complete and partial groups.
- Show in Map mock test verified numbered markers, map navigation, popup data, and isolated cleanup that preserves a pre-existing ordinary map layer.
- A compiled APK and physical-device run are **not** included: this workspace does not have Gradle or the Android SDK installed. The archive includes a GitHub Actions workflow to build a debug APK on GitHub.
