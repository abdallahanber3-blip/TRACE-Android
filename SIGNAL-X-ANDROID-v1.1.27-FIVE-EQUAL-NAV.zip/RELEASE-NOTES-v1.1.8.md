# SIGNAL X v1.1.8 — Legacy Header & CSS Cleanup

## Changes
- Removed the duplicate in-app SIGNAL X / DRIVE TEST INTELLIGENCE card from the Map page.
- Removed the old map pseudo-header wordmark and the JavaScript that recreated the retired brand card.
- Removed the obsolete inline logo SVG painter used only by that card. The Android launcher icon and PWA icon remain.
- Kept only an empty, hidden `.app-header` hook required by the existing page-navigation initializer; it contains no logo, text, or visible UI.
- Replaced 18 embedded style blocks with two ordered local stylesheets: `css/signalx-core.css` (compatibility/layout/map behavior) and `css/signalx-design-system.css` (current approved palette, page banners, entry and planner appearance).
- Pruned legacy `.sx-map-brand`, TRACE emblem and duplicate map-header wordmark selectors from active CSS.
- Removed 981 unreferenced legacy CSS selector branches from the core compatibility sheet (including the obsolete language splash, old search/GPS controls, old site detail cards and old bottom site switcher). Preserved selectors referenced by active HTML/JavaScript and external Leaflet/Font Awesome-generated components.
- Removed unused internal logo assets and an unused v1.1.3 HTML snapshot from the active web roots.
- Removed unused legacy app-title/subtitle translation entries, the old header class hook, and one duplicate Google Fonts stylesheet request.
- Kept a zero-content hidden `.app-header` sentinel solely because the existing navigation initializer checks for it; no visual header or branding is rendered.
- Corrected Light Mode token aliases: Electric Amber remains `#FFB84D`; Success remains green; Error remains red; former blue/purple aliases are neutralized.
- Preserved map tiles, Leaflet marker geometry, GPS, Drive Test, Excel data loading, SITE PLANNER, search and navigation logic.
- Android versionName `1.1.8`; versionCode `10`.

## Verification
- HTML parsing and 30 inline JavaScript syntax checks.
- CSS parser checks for both extracted stylesheets.
- No active `.sx-map-brand` selectors or JavaScript brand reinsertion remain.
- Service worker cache version advanced and both CSS assets added to the offline shell.
- ZIP integrity checks passed for Android and Web/PWA packages.
- APK build and physical-device testing were not performed in this environment.
