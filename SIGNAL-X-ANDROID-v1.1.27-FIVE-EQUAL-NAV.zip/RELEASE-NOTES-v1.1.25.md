# SIGNAL X v1.1.25 — Navigation, Daily Field Log & Performance Polish

## Changes
- Daily Field Log is now a dedicated standalone page, not appended to Home. It remains accessible from More and keeps the existing local history and notes.
- Added a compact Settings shortcut in the top row of every page banner (except the Settings page itself).
- Kept the bottom navigation to five items: Home, Map, Sites, Planner and More. Corrected its five-column layout, reduced dock height/padding and reduced blur cost on mobile.
- Utility pages (Route Planner, Daily Field Log and Settings) correctly highlight More in the bottom navigation.
- Page switching now jumps directly to the top instead of running a smooth full-page scroll animation.
- Reduced expensive idle state serialization: form changes are debounced; periodic full snapshots happen only while a drive recording is active.
- Removed continuous 650ms Site Information polling; replaced it with event-driven refresh and a bounded startup hook retry.
- Reduced mobile banner/dock blur and disabled the continuously sweeping banner sheen on small screens to improve responsiveness.

## Preserved behavior
- Existing search, Selected Sites, map, Excel import/restore, Site Planner, Route Planner and Google Maps handoff remain in place.
- Daily Field Log storage key and note-editing flow are unchanged.
- Completing a route stop still syncs to Site Planner and Daily Field Log.

## Validation
- HTML structure and JavaScript syntax checks run on the updated app source.
- Navigation/page wiring and More menu targets inspected.
- Full Android APK build and physical-device performance profiling were not performed in this environment.
