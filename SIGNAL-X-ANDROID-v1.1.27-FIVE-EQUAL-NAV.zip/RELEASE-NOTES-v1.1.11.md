# SIGNAL X v1.1.11 — Unified Glass UI

## What changed
- Established one shared UI design system across Home, Map, Sites, Site Planner and Settings.
- Standardized the main geometry: 28px app shell, 22px page banners, 20px outer cards, 15px inner cards and 12px controls; pill geometry is reserved for chips and compact status tags.
- Unified borders, glass surfaces, shadows, spacing, focus states, component typography and active navigation treatment.
- Unified action semantics: Electric Amber for primary actions, green for success/live states, and red for errors/destructive actions.
- Improved bottom-navigation readability on compact Android phones.
- Kept the premium glass entry screen and its existing motion treatment.
- Replaced the embedded visual design layer with one canonical v1.1.11 stylesheet while preserving the application's functional core and event handlers.
- Updated Android version metadata to 1.1.11 and bumped the PWA shell cache to v8.

## Preserved
- Existing map, GPS, drive-test, database, Excel/GeoJSON, search, Site Planner and language/theme handlers are carried forward from v1.1.10.
- Page-specific layouts remain distinct where the task requires it; shared component rules provide a consistent overall system.

## Validation
- Visual layout rendered at 390px, 412px and 768px widths.
- No horizontal document overflow detected at those widths in the local browser harness.
- Dark and light themes rendered for key workspaces.
- Inline CSS was parsed by Chromium; the harness reported only the expected `L is not defined` errors because external Leaflet/CDN requests were intentionally blocked during offline rendering.
- Android APK was not built and no physical-device test was performed in this environment. Build the provided Android project with Android Studio/Gradle and verify it on the target device before production use.
