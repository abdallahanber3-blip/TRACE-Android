# SIGNAL X v1.1.23

This package contains the Android Studio project and the synchronized app web assets for SIGNAL X.

### Main change
Route Planner now runs as its own navigation page. Users manually select destinations from the loaded 4G/5G site database, search the list, select only visible results when desired, and choose GPS or a manual site as the starting point. Completing a route stop updates Site Planner and Daily Field Log.

See `RELEASE-NOTES-v1.1.23.md` for details and validation limits.
