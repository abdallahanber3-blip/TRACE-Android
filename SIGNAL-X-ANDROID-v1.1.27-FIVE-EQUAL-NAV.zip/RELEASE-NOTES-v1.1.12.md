# SIGNAL X v1.1.12 — Wide Premium Glass UI

## Visual refinement
- Rebalanced the visual hierarchy for wider, more spacious cards across Home, Map, Sites, Site Planner and Settings.
- Removed the decorative outer app-card frame so workspace sections use the available screen width.
- Reduced nested card treatments: Planner stats and checklist rows are now flat rows; Sites sections are consolidated into one primary glass surface; Settings actions and Home filters no longer create card-within-card framing.
- Increased glass transparency and blur in both dark and light themes while retaining readable text and contrast.
- Increased primary component padding, touch target sizes, banner height and body text scale.
- Added a restrained entrance cascade, animated banner sheen, soft amber glow, button feedback and active-navigation motion.
- Retained reduced-motion support and avoided continuous high-cost effects across all cards.

## Preserved
- v1.1.11 functional HTML/JavaScript and all existing page, Excel, database, GPS, map, drive-test and Site Planner handlers.
- Existing page-specific layouts and the separate premium entry screen.
- Dark/Light themes, Arabic/English switching, planner search, copy, completion and Show in Map behavior.

## Validation
- Rendered Home, Map, Sites, Planner and Settings at 390px, 412px and 768px viewport widths.
- Checked document overflow, major card dimensions, dark/light surfaces and bottom-nav readability.
- Inline CSS parsed in Chromium. Expected external Leaflet/CDN requests were blocked in the offline visual harness; the real map requires device/network testing.
- No APK build or physical-device test was performed in this environment. Use the included Android Studio project to build and test on the target device before replacing the stable release.
