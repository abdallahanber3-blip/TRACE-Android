# SIGNAL X v1.1.6 — Release Notes

## Page identity and visual consistency
- Removed the repeated SIGNAL X tower/wordmark header from internal Home, Map, and Sites pages.
- Added page-specific banners to Home, Map, Sites, and Settings; Site Planner uses the matching Field Workspace banner.
- Banners localize with the app language and adapt to dark/light themes.
- The launcher icon and startup identity remain unchanged.
- Expanded the approved Obsidian / Graphite / Electric Amber / Warm Ivory system across page surfaces, map controls, Site Information components, navigation selection and Settings. Semantic green/red indicators remain reserved for status/coverage and errors.
- Kept the existing page handlers, map actions, site database, and navigation flow in place.

## Site Planner copy actions
- Added a small Copy action beside each site chip in nearby groups.
- Added a Copy action beside each pending/completed To-do row.
- Copy uses the Clipboard API when available and falls back to a hidden textarea copy method for Android WebView compatibility.
- Copying a site does not toggle its completion checkbox, change its group, or touch the database.

## Version
- Android versionCode: 8
- Android versionName: 1.1.6
- PWA service-worker cache bumped to `signal-x-shell-brand-2026-v4`.

## Validation
- 30 inline JavaScript blocks passed `node --check`.
- 17 CSS blocks parsed successfully with PostCSS.
- HTML source was parsed and key page-banner/copy-button insertion points were checked.
- A debug APK and physical Android handset run were not produced in this environment.
