# SIGNAL X v1.1.17 — Selected Sites & Banner Polish

## Visual corrections
- Removed the inherited surface background from the Selected Sites chip-list container; only the selected-site pills carry a surface, eliminating the large empty white strip.
- Kept selected-site queue content compact, wrapping naturally and preserving Clear / Show All on Map actions.
- Standardized Site Location title rail, equal two-column site/location data, full-width coordinates and aligned Copy/Directions actions.
- Matched page-banner padding, minimum height, icon size, title and subtitle rhythm across pages and responsive widths.

## Functional safety
- No JavaScript logic was edited. Search, selected-site state, copy actions, map actions, database parsing, Excel import and Planner persistence remain as in v1.1.16.
- PWA shell cache name advanced to v117. Android versionName advanced to 1.1.17 (versionCode 18).

## Validation
- HTML/CSS structural checks and archive integrity checks performed.
- Visual target: Selected Sites queue list transparent with only site pills surfaced; Site Location fields align in two columns with coordinates full width.
- Android APK was not built or device-tested in this environment.
