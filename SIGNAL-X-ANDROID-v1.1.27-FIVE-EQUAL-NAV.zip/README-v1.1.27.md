SIGNAL X v1.1.27 — Five Equal Navigation Tabs. Open app/src/main/assets/www/index.html in Android WebView or build the project with Android Studio/Gradle. See SIGNAL-X-Release-Notes-v1.1.27.md.
