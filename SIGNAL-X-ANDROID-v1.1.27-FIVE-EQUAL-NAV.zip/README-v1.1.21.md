# SIGNAL X v1.1.21

This Android Studio project adds the Route Optimizer and Daily Field Log to the v1.1.20 application source.

- Open the `android/` Gradle project in Android Studio or run the included GitHub Actions workflow to build a Debug APK.
- The WebView geolocation permission and Google Maps navigation bridge are already part of MainActivity and are reused by this release.
- Test GPS permission, current-location fix, stop completion sync, local persistence and external Maps handoff on a physical Android device before production use.

See `RELEASE-NOTES-v1.1.21.md` for scope and limitations.
